import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
rows=[("Stator field (T)",20.1,"TFMC 20 K",5,"v8 booked"),("Field ceiling (T)",20.1,"TFMC 20 K",20,"v8 ceiling, 77 K"),
("Machine power (MW)",36.5,"AMSC HTS motor",99.55,"v8 module"),("MHD output (MW)",32,"Avco Mark V gross",99.55,"v8 module"),
("Plasma σ (S/m)",100,"closed-cycle nonequilibrium",14000,"v8 design σ"),("Power density (MW/m³)",140,"noble-gas MHD",212955,"v8 ring (derived)"),
("HTS-bearing rotor speed (krpm)",15,"Boeing HTS bearing",150.938,"v8 booked"),("Composite rotor speed (krpm)",60,"NASA G2 design",150.938,"v8 booked"),
("Bearing pressure (N/cm²)",41,"melt-textured YBCO",41,"v8 used"),("LN₂ specific work (kJ/kg)",174,"Dearman/CCP engine",242.5,"v8 w_exp")]
fig,ax=plt.subplots(figsize=(8,5.2)); y=range(len(rows))
ax.barh([i+0.2 for i in y],[r[1] for r in rows],0.4,label="Demonstrated publicly (A)",color="#3060c0")
ax.barh([i-0.2 for i in y],[r[3] for r in rows],0.4,label="SCG-HMH v8 paper value (B)",color="#e08030")
ax.set_xscale('log'); ax.set_yticks(list(y)); ax.set_yticklabels([r[0] for r in rows],fontsize=8); ax.invert_yaxis()
for i,r in enumerate(rows): ax.text(r[3]*1.1,i-0.2,f"×{r[3]/r[1]:.3g}",va='center',fontsize=7)
ax.set_xlabel("value (log scale; units per row)"); ax.legend(fontsize=8,loc='lower right'); ax.set_title("Demonstrated vs v8 design (not like for like)",fontsize=10)
plt.tight_layout(); plt.savefig('figs/demonstrated_vs_design.png',dpi=160)
