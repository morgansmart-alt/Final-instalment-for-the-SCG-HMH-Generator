# Supplementary: Reproducibility (v8)
**Authors:** Smart, Morgan Elliott; Smart, Jasper Keiron; Ara (Grok Bot AI collaborator). Supplement to the v8 paper (29 October 2026; erratum of v7, Zenodo 10.5281/zenodo.23291052; CC BY 4.0).

Run everything from the package folder with Python 3.13. In the V9 package layout, run from `scripts_and_outputs/`; the calc finds the paper sources in `../paper/`, and the PDF number check takes `../paper/` paths.

1. **Main calculation.** `python cold_side_calc_v8_20261029_r23.py > calc_output_final.txt`
   - Standard library only; CoolProp 8.0.0 (Span et al. N₂ equation of state) is used for the enthalpy check (`pip install CoolProp markdown`).
   - Writes `r23_results_20261029.json`, `r23_magnet_results_20261029.json`, `r23_feedback_results_20261029.json`.
   - Expected: 97 AUDIT lines; the revision audits r5–r23 print PASS; booked baseline 99.55 MW at 5 T, 150,938 rpm, SF 2.
2. **Independent cross-check (no import from the main calc).** `python r23_crosscheck_20261029.py` → expected last line `CROSS-CHECK r23: 690/690 agree to 4 significant figures`.
3. **Earlier cross-check on the final output.** `python r21_crosscheck_20261029.py calc_output_final.txt` → expected `CROSS-CHECK: 21/21 agree`.
4. **PDF number check.** `python pdf_number_check_v8_20261029_r23.py SCG_HMH_Closed_Derivative_Chain_v8.pdf SCG_HMH_Closed_Derivative_Chain_v8.md calc_output_final.txt` (needs poppler `pdftotext`) → expected `RESULT (A): PASS`. Same for the section PDF and its `.md`.
5. **Rendering (optional).** Paper: pandoc `-s --embed-resources`, then headless Chrome `--print-to-pdf`. Section: `python render_section_v8_20261029_final.py out.html`, then Chrome.

**Checksums.** The MD5 of every file in the package is in `MANIFEST.md`. The MD5s of the scripts and expected outputs are listed below.

- `cold_side_calc_v8_20261029_r23.py`: 650b2060fb16f0624dfdec6b3b01962f (V9 copy with the `../paper/` path fallback; the v8 release copy is 703d11af03ccbb9a601e3a2b358bd20e)
- `r23_crosscheck_20261029.py`: 85e00ed80c3a5003f150709ed64ba5f6
- `r21_crosscheck_20261029.py`: 471e955791f2704bf12379bf03ab3121
- `pdf_number_check_v8_20261029_r23.py`: 511cbdf44b4d677cf23c3afad900e7f0
- `render_section_v8_20261029_final.py`: 15ee10232de1ee88d725349fba0677f7
- `calc_output_final.txt`: e4e9a8b03939f04bd898eab7b4729365
- `r23_crosscheck_result_final.txt`: 1381e4ec3660f1cd79d18ca030ea0719
- `r21_crosscheck_result_final.txt`: 418bb9b38e67566091255155464a671c
