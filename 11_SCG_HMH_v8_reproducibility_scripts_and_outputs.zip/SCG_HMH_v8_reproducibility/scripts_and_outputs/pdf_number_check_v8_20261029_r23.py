"""r19 PDF number check (same check as r14) (Morgan's review 23:18, point 2).
(A) Every numeric token in the PDF text layer (pdftotext, reading order and -layout) must occur as a whole token in the
    section source (.md). A number broken across a line inside a cell ('140,392.8' + '1') or two cells run together
    ('3,062188.0') fails this check.
(B) Every numeric token with 3+ significant figures in the tables of the section is looked up in the calc output.
    Tokens not printed by the script in that form are listed for review (published inputs, citations, record ids).
Usage: python pdf_number_check_v8_20261029_r21.py <pdf> <md> <calc_output>"""
import re, subprocess, sys, collections
pdf, md, out = sys.argv[1:4]
TOK = re.compile(r'(?<![\w.])\d[\d,]*(?:\.\d+)?')
def toks(s):
    s = s.replace('\u00ad', '').replace('\u2009', ' ').replace('\u202f', ' ')
    return [t.rstrip(',.') for t in TOK.findall(s)]
src = open(md, encoding='utf-8').read()
src_t = set(toks(src))
res = {}
for mode in ('reading', 'layout'):
    args = ['pdftotext'] + (['-layout'] if mode == 'layout' else []) + [pdf, '-']
    txt = subprocess.run(args, capture_output=True, text=True, check=True).stdout
    pt = toks(txt)
    bad = collections.Counter(t for t in pt if t not in src_t)
    res[mode] = (len(pt), bad)
    print(f"(A) {mode:7s}: {len(pt)} numeric tokens in the PDF text; not in the source: {sum(bad.values())} {dict(bad) if bad else ''}")
calc = open(out, encoding='utf-8').read()
calc_t = set(t.rstrip(',.') for t in re.findall(r'(?<![\d.])\d[\d,]*(?:\.\d+)?', calc))   # calc text: numbers may follow a letter (x1.2506, m3)
rows = [l for l in src.splitlines() if l.startswith('|') and not l.startswith('|---')]
tab_t = collections.Counter(t for l in rows for t in toks(l) if len(re.sub(r'[^\d]', '', t).lstrip('0')) >= 3)
exact = [t for t in tab_t if t in calc_t]
# numeric match at the printed precision, allowing the unit steps W/kW/MW and fraction/percent
calc_v = [float(c.replace(',', '')) for c in calc_t]
def num_match(t):
    v = float(t.replace(',', '')); d = len(t.split('.')[1]) if '.' in t else 0
    for k in (1, 1e3, 1e-3, 1e6, 1e-6, 100, 0.01):
        for c in calc_v:
            if abs(round(c*k, d) - v) < 0.5*10**-d + 1e-12:
                return True
    return False
rest = [t for t in tab_t if t not in calc_t]
numeric = [t for t in rest if num_match(t)]
miss = sorted(t for t in rest if t not in numeric)
print(f"(B) table tokens with >= 3 significant figures: {len(tab_t)} distinct; printed verbatim in the calc output: {len(exact)}; "
      f"matching a calc value at the printed precision (unit step W/kW/MW or %): {len(numeric)}; no calc value: {len(miss)}")
print("    no calc value (review: published inputs, citations, section numbers):", ' '.join(miss))
# (C) the same lookup over the whole text (prose and tables), excluding the reference list and record ids
body = src.split('### References added in v8')[0]
body = re.sub(r'(Zenodo|record|doi\.org/)[^;)\]]*', ' ', body)
all_t = collections.Counter(t for t in toks(body) if len(re.sub(r'[^\d]', '', t).lstrip('0')) >= 3)
rest_c = [t for t in all_t if t not in calc_t]
miss_c = sorted(t for t in rest_c if not num_match(t))
print(f"(C) whole text, tokens with >= 3 significant figures: {len(all_t)} distinct; verbatim in the calc output: {len(all_t) - len(rest_c)}; "
      f"at printed precision: {len(rest_c) - len(miss_c)}; no calc value: {len(miss_c)}")
print("    no calc value (review list):", ' '.join(miss_c))
ok = all(not b for _, b in res.values())
print("RESULT (A):", "PASS - every number in the PDF text matches the section source" if ok else "FAIL")
