"""Render cold_side_section_v8_20261029_final.md to HTML (r19 renderer, unchanged from r14). Print to PDF afterwards with:
   google-chrome --headless=new --disable-gpu --no-pdf-header-footer --print-to-pdf=<pdf> file://<html>
r14 changes (Morgan's review 23:18): table captions kept with their tables (<caption>); numbers never broken inside a
cell (each numeric token is a no-wrap span, table layout sized to content); equation labels 6.6a-6.6o in a monospaced
face so the letter o cannot be read as a zero. Needs the 'markdown' package (.venv_cold)."""
import markdown, re, sys, os
here = os.path.dirname(os.path.abspath(__file__))
src = os.path.join(here, 'cold_side_section_v8_20261029_final.md')
html_out = sys.argv[1] if len(sys.argv) > 1 else '/tmp/r16/r23.html'
t = open(src, encoding='utf-8').read()
m = re.match(r'---\n(.*?)\n---\n', t, re.S)
fm = dict(re.findall(r'(\w+): "(.*)"', m.group(1))); body = t[m.end():]
css = """<html><head><meta charset='utf-8'><style>@page{size:A4;margin:14mm 12mm}
body{font-family:'DejaVu Serif',Georgia,serif;font-size:10pt;line-height:1.42;margin:0 4mm}
h1{font-size:15pt}h2{font-size:13.5pt;border-bottom:1px solid #999}h3{font-size:11.5pt;margin-top:1.2em;break-after:avoid}
table{border-collapse:collapse;width:100%;table-layout:auto;font-size:7.4pt;margin:.6em 0}
th,td{overflow-wrap:normal;word-break:normal;hyphens:none;border:1px solid #aaa;padding:2px 3px;vertical-align:top}
th{background:#eee}tr{break-inside:avoid}thead{display:table-header-group}
caption{caption-side:top;text-align:left;font-size:9pt;line-height:1.35;padding:0 0 .35em 0;break-after:avoid}
.n{white-space:nowrap}.eq{font-family:'DejaVu Sans Mono',monospace;font-size:.92em}
blockquote{background:#eef4ff;border-left:4px solid #3060c0;margin:.5em 0;padding:.4em .8em}code{font-size:8.5pt}.meta{color:#555}
"""
h = markdown.markdown(body, extensions=['tables'])
h = re.sub(r'<p>(Table 13[a-z]?\..*?)</p>\s*<table>', lambda mm: '<table><caption>' + mm.group(1) + '</caption>', h, flags=re.S)
NUM = re.compile(r'(?<![\w.,])[−+-]?\d[\d,]*(?:\.\d+)?(?:(?![\w])(?: (?:MW|kW|W|kg/s|K|bar|kJ/kg|%)(?![\w/])))?(?![\w])')
def cellfix(mm):
    parts = re.split(r'(<[^>]+>)', mm.group(2))
    parts = [p if p.startswith('<') else NUM.sub(lambda q: '<span class="n">' + q.group(0) + '</span>', p) for p in parts]
    return mm.group(1) + ''.join(parts) + mm.group(3)
h = re.sub(r'(<t[dh][^>]*>)(.*?)(</t[dh]>)', cellfix, h, flags=re.S)
parts = re.split(r'(<[^>]+>)', h)
parts = [p if p.startswith('<') else re.sub(r'(?<![\d.])6\.6([a-o])(?![\w.])', r'<span class="eq">6.6\1</span>', p) for p in parts]
h = ''.join(parts).replace('<img alt=', '<img style="max-width:100%;height:auto" alt=')  # r20: figures fit the page
i = h.rfind('<ol>'); h = h[:i] + '<ol start="16">' + h[i+4:]
open(html_out, 'w', encoding='utf-8').write(css.replace("<head>", "<head><title>" + fm['title'] + "</title>", 1) + "</style></head><body>" + f"<h1>{fm['title']}</h1><p class='meta'>{fm['author']}<br>{fm['date']}</p>" + h + "</body></html>")
print('html', html_out)
