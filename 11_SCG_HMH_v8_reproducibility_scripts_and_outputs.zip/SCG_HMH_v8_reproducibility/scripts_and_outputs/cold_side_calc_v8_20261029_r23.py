import math
"""SCG-HMH Closed Derivative Chain v8 (revision r23) (file lineage from r9) - Earth cold side (regenerative chain, hybrid lift, single vent fleet, inter-module reset).
Reproduces every number in cold_side_section_v8_20261029_final.md.
Standard library only, except the optional NIST-equivalent N2 enthalpy check (CoolProp),
whose values are also hard-coded below so the script runs without it.
Prepared 28 Oct 2026 (Europe/London). Final v8 (29 Oct 2026).
"""
from math import pi

# ---- v7 worked point (published / v7-derived) ----
sig, rpm, r, h, d, B, K = 14000.0, 200000, 0.093, 0.4, 0.002, 5.0, 0.65
w_exp, eta_reg, hfg = 242500.0, 0.996, 200e3
om = 2*pi*rpm/60
P = sig*(om*r*B)**2*K*(1-K)*2*pi*r*h*d          # v7 Eq. 4
md = P/w_exp                                    # v7 Eq. 6
mmu = (1-eta_reg)*md                            # v7 Eq. 7
Qrej_v7 = eta_reg*md*hfg                        # v7 Eq. 8a
Q_v7 = P + mmu*w_exp + Qrej_v7                  # v7 Eq. 8
P_liq_v7 = mmu*3600*0.55*1000                   # v7 Book 2, W

# ---- temperatures ----
Th, Tc, Ta = 453.15, 77.35, 300.0               # 180 C feed; N2 NBP (LN2 paper 77.355 K); ambient (v7 assumption)
Th7, Tc7 = 453.0, 77.0                          # v7's rounded values, for comparison

def block(Th, Tc, Ta, label):
    Qc_min = P*Tc/(Th-Tc)                       # Carnot floor: heat that must leave at Tc
    Qin_eng = P + Qc_min                        # heat in to the ring engine at the floor
    lift_W = Qc_min*(Ta/Tc - 1)                 # ideal electric lift Tc -> Ta
    net_elec = P - lift_W
    Qbe = P/(Ta/Tc - 1)                         # break-even 77 K rejection with ideal electric lift
    COP_heat = (1 - Ta/Th)*Tc/(Ta - Tc)         # ideal heat-driven (absorption-type) lift
    Qlift_heat = Qc_min/COP_heat
    Qtot = Qin_eng + Qlift_heat
    Qtot_closed = P*Th/(Th - Ta)                # same thing in closed form = v7 case F
    print(f"--- {label}: Th={Th} Tc={Tc} Ta={Ta}")
    print(f"Carnot 453/77: {1-Tc/Th:.4f}; 453/300: {1-Ta/Th:.4f}")
    print(f"Floor rejection at Tc        {Qc_min/1e6:8.2f} MW")
    print(f"Ring heat in at floor        {Qin_eng/1e6:8.2f} MW")
    print(f"Electric lift to ambient     {lift_W/1e6:8.2f} MW  (W per W lifted {Ta/Tc-1:.4f})")
    print(f"Net with electric lift       {net_elec/1e6:8.2f} MW")
    print(f"Break-even Tc rejection      {Qbe/1e6:8.2f} MW")
    print(f"Heat-driven lift COP         {COP_heat:8.4f}  (1/COP {1/COP_heat:.3f})")
    print(f"Heat for lift                {Qlift_heat/1e6:8.2f} MW")
    print(f"Total waste heat (sum)       {Qtot/1e6:8.2f} MW; closed form {Qtot_closed/1e6:.2f} MW")
    print(f"Heat per unit electricity    {Qtot/P:.4f}")
    print(f"Heat rejected to ambient     {(Qtot-P)/1e6:8.2f} MW")
    return dict(Qc=Qc_min, Qin=Qin_eng, lift=lift_W, net=net_elec, Qbe=Qbe,
                COP=COP_heat, Qlh=Qlift_heat, Qtot=Qtot)

print(f"P = {P:,.0f} W; mdot = {md:.3f} kg/s; m_mu = {mmu:.4f} kg/s = {mmu*3600:,.1f} kg/h")
print(f"v7 Q_rej = {Qrej_v7/1e6:.3f} MW; v7 Q = {Q_v7/1e6:.3f} MW; v7 Book 2 = {P_liq_v7/1e6:.3f} MW")
print(f"v7 electric lift of 116 MW (77/300): {Qrej_v7*(300/77-1)/1e6:.1f} MW")
main = block(Th, Tc, Ta, "v8 basis")
alt = block(Th7, Tc7, Ta, "v7 rounded temps")

# reduction of 77 K rejection by recycling
print(f"Recycling cut: {Qrej_v7/1e6:.1f} -> {main['Qc']/1e6:.1f} MW ({1-main['Qc']/Qrej_v7:.1%} lower; "
      f"x{Qrej_v7/main['Qc']:.2f})")

# ---- sensitivity: real machines at a fraction of ideal (assumed) ----
for f in (1.0, 0.7, 0.5):
    Qbe_f = P/((Ta/Tc - 1)/f)
    Qlh_f = main['Qc']/(main['COP']*f)
    print(f"lift at {f:.0%} of ideal COP: electric break-even {Qbe_f/1e6:6.2f} MW; "
          f"heat-driven lift needs {Qlh_f/1e6:6.1f} MW, total heat {(main['Qin']+Qlh_f)/1e6:6.1f} MW")

# ---- makeup (0.4 %) ----
rho_L = 806.6                                   # kg/m3, LN2 paper Table 1 (NIST 806.08)
Lps = mmu/rho_L*1000
Lph = Lps*3600
print(f"Makeup {mmu:.4f} kg/s = {Lps:.3f} L/s = {Lph:,.0f} L/h")
for lab, sec in [("w_min", 0.167), ("v7 0.55 kWh/kg", 0.55*rho_L/1000), ("alloc 0.65", 0.65),
                 ("alloc 0.90", 0.90), ("ambient 1.05", 1.05), ("ambient 1.40", 1.40),
                 ("small plant 1.75", 1.75)]:
    print(f"  {lab:18s} {sec:.3f} kWh/L -> {Lph*sec/1e3:6.2f} MW ({Lph*sec/1e3/(P/1e6):.2%} of P)")
print(f"v7 4.61 MW implies {P_liq_v7/1e3/Lph:.3f} kWh/L")
print(f"Net after v7 makeup (case F) {(P-P_liq_v7)/1e6:.2f} MW")

# ---- Mode L pump (LN2 paper, liquid only) ----
w_pump = 20.1e3; w_exp_credit = 23.1e3          # J/kg shaft, projected
print(f"Mode L 0.0045 kWh/L on makeup volume: {0.0045*Lph/1e3*1e3:.1f} kW")
print(f"Mode L on full circulating stream (illustrative): gross {w_pump*md/1e6:.2f} MW, "
      f"paired net {(w_pump-w_exp_credit)*md/1e6:+.2f} MW")

# ---- what the 0.4 % vent carries away (enthalpy above saturated liquid) ----
h_liq = -122.018e3                              # J/kg sat. liquid 1 atm (CoolProp/NIST EoS)
h_vent = {293.15: 304.060e3, 300.0: 311.193e3, 453.15: 471.116e3}
for T, hv in h_vent.items():
    print(f"Vent at {T} K carries {mmu*(hv-h_liq)/1e6:.3f} MW (latent+sensible); "
          f"sensible part alone {mmu*(hv-h_liq-199.2e3)/1e6:.3f} MW")
print(f"Vent as share of floor: {mmu*(h_vent[293.15]-h_liq)/main['Qc']:.1%} - {mmu*(h_vent[453.15]-h_liq)/main['Qc']:.1%}")

try:
    import CoolProp.CoolProp as C
    print("CoolProp check h(453.15 K,1 atm) kJ/kg:", C.PropsSI('H','T',453.15,'P',101325,'N2')/1e3)
except Exception:
    print("CoolProp not available; hard-coded NIST-EoS enthalpies used")

# residual check for the regenerative boundary at the floor
R = main['Qin'] - P - main['Qc']
print(f"Residual at floor: {R:.3e} W")

# ==== r2 (28 Oct 2026): HYBRID cold side - small electricity + large waste heat ====
# The lift of the floor needs work W_lift = Qc_min (Ta/Tc - 1). Part E is supplied as electricity,
# the rest by a heat engine 453 K -> 300 K (efficiency eta_h = 1 - Ta/Th). Machine fraction f is applied once,
# to the overall lift (same convention as the r1 sensitivity: f=0.7, E=0 gives 353.7 MW of lift heat).
print("\n=== r2 hybrid: electric share E of the lift work, rest from 453 K waste heat ===")
eta_h = 1 - Ta/Th
Wl = main['Qc']*(Ta/Tc - 1)
P_mu = P_liq_v7
print(f"Ideal lift work {Wl/1e6:.2f} MW; heat engine 453->300 eff {eta_h:.4f}; "
      f"1 MW electricity replaces {1/eta_h:.3f} MW of waste heat")
for f in (1.0, 0.7):
    Wl_f = Wl/f; eta_f = eta_h
    print(f"-- machines at {f:.0%} of ideal: lift work {Wl_f/1e6:.2f} MW, 1 MW elec saves {1/eta_f:.2f} MW heat")
    for E in (0.0, 1e6, 2.5e6, 5e6, 10e6):
        Qlift = (Wl_f - E)/eta_f
        Qtot = main['Qin'] + Qlift
        net = P - E - P_mu
        print(f"   E={E/1e6:5.1f} MW ({E/Wl_f:5.1%} of lift work, {E/P:5.2%} of P): lift heat {Qlift/1e6:7.2f} MW, "
              f"total heat {Qtot/1e6:7.2f} MW (saved {(main['Qin']+Wl_f/eta_f-Qtot)/1e6:5.2f}), "
              f"plant net {net/1e6:7.2f} MW, heat/net {Qtot/net:.3f}")

# ==== r4 (28 Oct 2026): Carnot checks, single vent / shared tank fleet, leak threshold, heat supply ====
print("\n=== r4 Carnot checks (453.15 / 77.35 / 300 K) ===")
eta_C_cold = 1 - Tc/Th; eta_C_amb = 1 - Ta/Th
print(f"Carnot 453.15/77.35 {eta_C_cold:.4f}; 453.15/300 {eta_C_amb:.4f}")
print(f"v7 boundary P/Q = {P/Q_v7:.4f}")
print(f"Ring at floor P/(P+Qc) = {P/main['Qin']:.4f}")
print(f"Plant ideal P/Q_total = {P/main['Qtot']:.4f}")
for f in (0.7, 0.5):
    Qt = main['Qin'] + Wl/f/eta_h
    print(f"Plant at {f:.0%} machines: Q_total {Qt/1e6:.2f} MW, P/Q {P/Qt:.4f}")

print("\n=== r4 fleet: ONE vent, ONE shared tank (makeup, vent, shared controls, AI fixed; heat, floor per module) ===")
SEC_v7_kWh_per_kg = 0.55
def fleet(N, eta, E_lo=1e6, E_hi=5e6, SEC=SEC_v7_kWh_per_kg):
    mmu_f = (1-eta)*md                       # one module's leak, single vent
    Pmu = mmu_f*3600*SEC*1000                # W, fixed with N
    gross = N*P
    heat_bound = N*main['Qtot']
    heat_lo = N*(main['Qin'] + (Wl-E_hi)/eta_h)  # E = 5 MW per module
    heat_hi = N*(main['Qin'] + (Wl-E_lo)/eta_h)  # E = 1 MW per module
    net_hi = gross - Pmu - N*E_lo
    net_lo = gross - Pmu - N*E_hi
    R2 = gross/Pmu
    Rel_lo = gross/(Pmu + N*E_hi); Rel_hi = gross/(Pmu + N*E_lo)
    return dict(N=N, eta=eta, mmu=mmu_f, Pmu=Pmu, gross=gross, E_lo=N*E_lo, E_hi=N*E_hi,
                heat_bound=heat_bound, heat_lo=heat_lo, heat_hi=heat_hi,
                net_lo=net_lo, net_hi=net_hi, net_bound=gross-Pmu, R2=R2, Rel_lo=Rel_lo, Rel_hi=Rel_hi)
FLEET = []
for eta in (0.996, 0.999):
    for N in (1, 10, 100, 1000):
        r = fleet(N, eta); FLEET.append(r)
        print(f"eta {eta} N {N:5d}: makeup {r['mmu']:.4f} kg/s {r['Pmu']/1e6:.3f} MW fixed | gross {r['gross']/1e6:,.1f} MW | "
              f"E {r['E_lo']/1e6:,.0f}-{r['E_hi']/1e6:,.0f} MW | heat bound {r['heat_bound']/1e6:,.1f}, hybrid {r['heat_lo']/1e6:,.1f}-{r['heat_hi']/1e6:,.1f} MW | "
              f"net {r['net_lo']/1e6:,.1f}-{r['net_hi']/1e6:,.1f} MW (E=0: {r['net_bound']/1e6:,.1f}) | R2,N {r['R2']:,.1f} | "
              f"P/(makeup+E) {r['Rel_lo']:.1f}-{r['Rel_hi']:.1f}")
r = fleet(100, 0.999)
print(f"v7 Table 8 check, 100 modules eta 0.999: makeup {r['Pmu']/1e6:.3f} MW, gross {r['gross']/1e9:.2f} GW, R2,N {r['R2']:,.0f}")
Pfill = (1-0.999)*md*3600*0.05*1000
print(f"v7 Table 8 check, cold-side fill 0.05 kWh/kg (space): {Pfill/1e3:.1f} kW, R2,N {100*P/Pfill:,.0f}")
print(f"Vent heat fixed with N (eta 0.996): {mmu*(h_vent[293.15]-h_liq)/1e6:.3f}-{mmu*(h_vent[453.15]-h_liq)/1e6:.3f} MW; "
      f"eta 0.999: {(1-0.999)*md*(h_vent[293.15]-h_liq)/1e6:.3f}-{(1-0.999)*md*(h_vent[453.15]-h_liq)/1e6:.3f} MW")
print("Shared controls < 0.8 kW [3] fixed; AI line one fleet instance 2.82-14.12 MW fixed:",
      f"{0.02*P/1e6:.2f}-{0.10*P/1e6:.2f} MW; share of gross at N=100: {0.02*P/(100*P):.3%}-{0.10*P/(100*P):.3%}")

print("\n=== r4 leak threshold: makeup ratio P/P_liq = 1 when leak fraction = w_exp / (3600 * SEC_kg) ===")
LEAK = {}
for lab, secL in [("w_min 0.167", 0.167), ("v7 0.444", 0.55*rho_L/1000), ("0.90", 0.90), ("1.40", 1.40)]:
    sec_kg = secL/(rho_L/1000)
    f1 = w_exp/(3600*sec_kg*1000)            # R2 = 1, single module
    f_net = (P - 5e6)/(md*3600*sec_kg*1000)  # plant net > 0 with E = 5 MW, single module
    LEAK[lab] = (f1, f_net)
    print(f"  SEC {secL:.3f} kWh/L ({sec_kg:.4f} kWh/kg): R2=1 at leak {f1:.2%} ({f1/0.004:.1f}x design); "
          f"net>0 with E=5 MW up to {f_net:.2%}; N=100 shared vent R2=1 at {min(100*f1,1):.0%} (capped)")
for f in (0.01, 0.02):
    Pl = f*md*3600*0.55*1000
    print(f"  leak {f:.0%} at v7 SEC: makeup {Pl/1e6:.2f} MW, R2 {P/Pl:.2f}; at 1.40 kWh/L: {f*md*3600*1.40/0.8066*1000/1e6:.2f} MW")

print("\n=== r4 heat supply (Papapetrou et al. 2018, EU industrial waste heat 2015) ===")
TWh = 1e12*3600  # J
for lab, twh in [("200-500 C", 78.0), (">500 C", 124.0), (">=200 C", 202.0), ("total", 304.13)]:
    GW = twh*1e12/8760/1e9
    print(f"  {lab:10s} {twh:7.2f} TWh/yr = {GW:6.2f} GW avg -> modules at 417.84 MW: {GW*1e9/main['Qtot']:6.1f}; "
          f"at 523.94 MW: {GW*1e9/523.94e6:6.1f}; one module = {main['Qtot']/(GW*1e9):.2%}")

# ==== r4 audit: every key number string must appear in the section ====
import os, re
md_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "cold_side_section_v8_20261029_final.md")
if not os.path.exists(md_path):  # V9 layout: paper sources in ../paper
    md_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "paper", "cold_side_section_v8_20261029_final.md")
if os.path.exists(md_path):
    txt = open(md_path, encoding="utf-8").read()
    def fm(x, nd=2): return f"{x:,.{nd}f}"
    checks = {
        "P": fm(P/1e6), "floor": fm(main['Qc']/1e6), "ring heat": fm(main['Qin']/1e6),
        "lift W": fm(main['lift']/1e6), "net elec": fm(main['net']/1e6), "break-even": fm(main['Qbe']/1e6),
        "COP": f"{main['COP']:.4f}", "lift heat": fm(main['Qlh']/1e6), "Q total": fm(main['Qtot']/1e6),
        "ambient": fm((main['Qtot']-P)/1e6), "Carnot cold": f"{eta_C_cold:.1%}".replace('%',' %'),
        "Carnot amb": f"{eta_C_amb:.1%}".replace('%',' %'), "v7 P/Q": f"{P/Q_v7:.1%}".replace('%',' %'),
        "makeup kg/s": f"{mmu:.3f}", "makeup L/s": f"{Lps:.3f}", "makeup L/h": f"{Lph:,.0f}",
        "R2 v7 table 8": f"{fleet(100,0.999)['R2']:,.0f}",
        "70% total": fm((main['Qin'] + Wl/0.7/eta_h)/1e6), "50% total": f"{(main['Qin'] + Wl/0.5/eta_h)/1e6:.1f}",
        "leak 1.40": f"{LEAK['1.40'][0]:.2%}".replace('%',' %'), "leak v7": f"{LEAK['v7 0.444'][0]:.2%}".replace('%',' %'),
    }
    for r in FLEET:
        checks[f"gross N{r['N']}"] = fm(r['gross']/1e6, 1 if r['N'] < 1000 else 0) if False else f"{r['gross']/1e6:,.0f}" if r['N']>=100 else fm(r['gross']/1e6)
        checks[f"R2 N{r['N']} eta{r['eta']}"] = f"{r['R2']:,.0f}" if r['R2'] >= 1000 else f"{r['R2']:,.1f}"
    bad = [k for k, v in checks.items() if v not in txt]
    print("\nAUDIT:", "PASS - all key numbers present" if not bad else f"MISSING {[(k, checks[k]) for k in bad]}")
    for t in ("Kieron",):
        n = txt.count(t); print(f"AUDIT spelling '{t}' occurrences (only allowed inside the v7 note): {n}")
    stray = re.findall(r"\b(453|77) K\b", txt)
    print("AUDIT bare 453 K / 77 K occurrences (allowed only when quoting v7):", len(stray))
    eqs_def = set(re.findall(r"\((6\.6[a-z])\)\s*$", txt, re.M)); eqs_ref = set(re.findall(r"Eq\. (6\.6[a-z])", txt))
    print("AUDIT equations referenced but not defined:", sorted(eqs_ref - eqs_def) or "none")
    secs_def = set(re.findall(r"^### (6\.6\.\d+)", txt, re.M)); secs_ref = set(re.findall(r"\b(6\.6\.\d+)", txt))
    print("AUDIT sections referenced but not defined:", sorted(secs_ref - secs_def) or "none")
    tabs_def = set(re.findall(r"^Table (13[a-z]?)\.", txt, re.M)); tabs_ref = set(re.findall(r"Table (13[a-z]?)\b", txt))
    print("AUDIT tables referenced but not defined:", sorted(tabs_ref - tabs_def) or "none")

print("\n=== r4 extra derived values quoted in the section ===")
print(f"Tc/(Ta-Tc) = {Tc/(Ta-Tc):.4f}; Th-Tc = {Th-Tc:.2f} K")
print(f"Removed from cold-end stream by recycling: {(Qrej_v7-main['Qc'])/1e6:.2f} MW")
print(f"Per watt of harvest: break-even {main['Qbe']/P:.3f} W/W; floor {main['Qc']/P:.3f} W/W")
print(f"Returned flow {eta_reg*md:.2f} kg/s; P {P/1e6:.2f} MW; 10 P {10*P/1e6:.2f} MW")
for N in (10, 100):
    print(f"Makeup at 1.40 kWh/L as share of N={N} gross: {Lph*1.40/1e3/(N*P/1e6):.2%}")
r = fleet(1, 0.999); print(f"N=1 eta 0.999 net: {r['net_lo']/1e6:.2f}-{r['net_hi']/1e6:.2f} MW")
print(f"P/Q as percent: v7 {P/Q_v7:.1%}, Carnot cold {eta_C_cold:.1%}, plant {P/main['Qtot']:.1%}, "
      f"70% {P/(main['Qin']+Wl/0.7/eta_h):.1%}, 50% {P/(main['Qin']+Wl/0.5/eta_h):.1%}")

# ==== r5 (28 Oct 2026): inter-module reset exchangers on the LN2 supply + isolated main J-T exchanger ====
# Layout (Morgan, 12:21): N modules in series. Between consecutive modules (N-1 exchangers) the LN2 supply re-cools
# the N2 and resets its expansion -> LN2 boil-off. The final-stage exit goes to the MAIN J-T heat exchanger, which is
# isolated from the LN2 supply. The LN2 generator ([9] + v8 waste-heat drive, hybrid) re-makes the boiled-off LN2.
# Mass makeup: fixed 0.4 % (single vent).
print("\n=== r5 inter-module reset (LN2 supply) + main J-T exchanger (isolated) ===")
try:
    import CoolProp.CoolProp as C
    hfg_77 = C.PropsSI('H','T',Tc,'Q',1,'N2') - C.PropsSI('H','T',Tc,'Q',0,'N2')
    src = "CoolProp (Span et al. EoS) at 77.35 K"
except Exception:
    hfg_77 = 199182.49; src = "hard-coded Span et al. EoS value at 77.35 K"
print(f"h_fg(77.35 K) = {hfg_77/1e3:.2f} kJ/kg [{src}]")
bo_per_MW = 1e6/hfg_77
bo_mod = main['Qc']/hfg_77                      # boil-off per inter-module reset at the floor
print(f"Boil-off per MW of reset heat: {bo_per_MW:.3f} kg/s per MW ({bo_per_MW/(rho_L/1000):.3f} L/s of LN2 per MW)")
print(f"Per inter-module reset (floor {main['Qc']/1e6:.2f} MW): boil-off {bo_mod:.2f} kg/s "
      f"({bo_mod/(rho_L/1000):.1f} L/s LN2; {bo_mod/md:.1%} of the 582.336 kg/s module flow)")
# specific cost of re-making boiled-off LN2 (saturated vapour at 77.35 K -> liquid, heat lifted to 300 K)
w_bo = hfg_77*(Ta/Tc - 1)                       # J/kg, ideal work
q_bo = w_bo/eta_h                               # J/kg of 453.15 K heat, heat-only bound
print(f"Re-making boil-off: ideal work {w_bo/1e3:.1f} kJ/kg = {w_bo/3.6e6:.4f} kWh/kg = {w_bo/3.6e6*rho_L/1000:.4f} kWh/L "
      f"(vs w_min from ambient 0.167 kWh/L); heat-only bound {q_bo/1e3:.1f} kJ/kg of 453.15 K heat")
print(f"Check: {bo_mod:.2f} kg/s x {q_bo/1e3:.1f} kJ/kg = {bo_mod*q_bo/1e6:.2f} MW = lift heat per floor {main['Qlh']/1e6:.2f} MW")
RESET = {}
for N in (1, 10, 100, 1000):
    nres = N - 1
    bo = nres*bo_mod; gen_duty = bo*hfg_77; jt = main['Qc']
    tot = gen_duty + jt
    RESET[N] = dict(nres=nres, bo=bo, gen=gen_duty, jt=jt, tot=tot)
    print(f"  N {N:5d}: resets {nres:4d} | LN2 production for boil-off recovery {bo:,.2f} kg/s ({bo/(rho_L/1000):,.1f} L/s) | "
          f"LN2-generator duty {gen_duty/1e6:,.2f} MW | main J-T exchanger {jt/1e6:.2f} MW | total {tot/1e6:,.2f} MW = N x floor {N*main['Qc']/1e6:,.2f} MW "
          f"(diff {tot - N*main['Qc']:.1e} W) | lift heat ideal: generator {nres*main['Qlh']/1e6:,.2f} + main J-T {main['Qlh']/1e6:.2f} = {N*main['Qlh']/1e6:,.2f} MW | "
          f"mass makeup fixed {mmu:.3f} kg/s")
print("Mass balance: boil-off leaves the LN2 store as vapour inside the closed loop and returns as LN2 from the generator -> "
      "net boundary mass change 0; only the single vent (0.4 %) leaves.")
for N in (100,):
    print(f"  N {N}: LN2-generator lift heat at 70 % margin {(N-1)*Wl/0.7/eta_h/1e6:,.2f} MW; whole fleet at 70 % {N*Wl/0.7/eta_h/1e6:,.2f} MW")
for k in (2, 3):
    print(f"  cascade comparison: margin factor compounded over {k} stages = {0.7**k:.3f} of ideal vs 0.700 applied once")

# ---- r5 audit additions ----
if os.path.exists(md_path):
    txt = open(md_path, encoding="utf-8").read()
    c5 = {"h_fg": f"{hfg_77/1e3:.2f}", "bo per MW": f"{bo_per_MW:.3f}", "bo per reset": f"{bo_mod:.2f}",
          "bo L/s": f"{bo_mod/(rho_L/1000):.1f}", "bo share": f"{bo_mod/md:.1%}".replace('%',' %'),
          "w_bo kJ": f"{w_bo/1e3:.1f}", "w_bo kWh/L": f"{w_bo/3.6e6*rho_L/1000:.4f}", "q_bo": f"{q_bo/1e3:,.1f}",
          "N10 bo": f"{RESET[10]['bo']:,.2f}", "N100 bo": f"{RESET[100]['bo']:,.2f}", "N1000 bo": f"{RESET[1000]['bo']:,.2f}",
          "N100 gen": f"{RESET[100]['gen']/1e6:,.2f}", "N100 tot": f"{RESET[100]['tot']/1e6:,.2f}",
          "N1000 gen": f"{RESET[1000]['gen']/1e6:,.2f}", "cascade 3": f"{0.7**3:.3f}"}
    bad = [k for k, v in c5.items() if v not in txt]
    print("AUDIT r5:", "PASS - all reset numbers present" if not bad else f"MISSING {[(k, c5[k]) for k in bad]}")

# =====================================================================================================
# ==== r6 (28 Oct 2026): "derive everything". Each former r5 assumption is derived here or listed  ====
# ==== as a design input. Sources: v7 [8], LN2 generator [9], Amplifiers by Role v4 (Morgan, = [A]),===
# ==== Strobridge 1974 [18], Green 2008 [19], Wang et al. 2019 [20].                                ===
# =====================================================================================================
print("\n=================== r6 DERIVATIONS ===================")
R_N2 = 8.314462618/0.0280134                   # J/(kg K), CODATA R / N2 molar mass
Qc = main['Qc']; Qlh_ideal = main['Qlh']; Qin = main['Qin']
Hleak = mmu*w_exp                               # v7 Eq. 8 leak term

# ---- (0) w_exp cross-check: isothermal expansion at T_h over the published 6:1 pressure ratio ----
w_iso6 = R_N2*Th*__import__('math').log(6.0)
print(f"(0) w_exp check: R_N2 {R_N2:.2f} J/kgK; isothermal 6:1 at {Th} K = {w_iso6/1e3:.2f} kJ/kg vs v7 242.5 "
      f"({w_exp/w_iso6-1:+.2%}); published band [A #25] 300-415 kJ/kg")

# ---- (a) reset heat from the module energy balance ----
# First law, per module (v7 Eq. 8 form): Q_in = P + m_mu*w_exp + Q_reset  ->  Q_reset = Q_in - P - m_mu*w_exp.
# The returned stream's latent load, booked with zero internal recovery, is v7's Q_rej = eta_reg*mdot*h_fg (116.0 MW).
# Internal regeneration returns a fraction eps of it to the vaporizer [A #1: 90-99.6 % of losses, re-condenser included]:
#     Q_reset(eps) = (1 - eps) * Q_rej
# Second law (Carnot, ring between Th and Tc): Q_reset >= Qc_min  ->  eps <= eps_max = 1 - Qc_min/Q_rej.
eps_max = 1 - Qc/Qrej_v7
eps_be = 1 - main['Qbe']/Qrej_v7
print(f"(a) Q_rej (v7, eps=0) {Qrej_v7/1e6:.2f} MW; second-law cap eps_max = {eps_max:.4f}; "
      f"published recovery 0.90-0.996 [A #1] >= eps_max -> Q_reset = max((1-eps)Q_rej, Qc_min) = {Qc/1e6:.2f} MW")
EPS = {}
for eps in (0.0, 0.25, 0.50, eps_be, 0.70, eps_max, 0.90, 0.996):
    Qr = max((1-eps)*Qrej_v7, Qc)
    EPS[round(eps, 4)] = Qr
    print(f"    eps {eps:6.4f}: Q_reset {Qr/1e6:7.2f} MW {'(capped at the second-law floor)' if (1-eps)*Qrej_v7 < Qc else ''}")
Qin_mod = P + Hleak + Qc
print(f"    module heat in at the cap (v7 Eq. 8 form) = {P/1e6:.2f} + {Hleak/1e6:.3f} + {Qc/1e6:.2f} = {Qin_mod/1e6:.2f} MW "
      f"(ring alone {Qin/1e6:.2f} MW; leak term {Hleak/1e6:.3f} MW = {Hleak/main['Qtot']:.2%} of the heat line, leaves through the vent)")
print(f"    break-even recovery for an ideal electric lift eps_be = {eps_be:.4f}; EoS h_fg variant Q_rej = {eta_reg*md*hfg_77/1e6:.2f} MW, "
      f"eps_max {1-Qc/(eta_reg*md*hfg_77):.4f}")

# ---- (b) does the extra (boil-off) flow add output? ----
# Ring equation: P = sigma (omega r B)^2 K(1-K) V. No mass-flow term. mdot = P / w_exp follows P (v7 Eq. 6; [A] #13 'identity').
print("(b) dP/dmdot at fixed sigma, omega, B, K, V = 0 (no mdot in Eq. 4)")
f_bo = bo_mod/md
print(f"    boil-off per reset {bo_mod:.2f} kg/s = {f_bo:.4f} of one ring's flow; one extra ring's flow per {1/f_bo:.2f} resets")
print(f"    if extra rings convert it: +{f_bo*P/1e6:.2f} MW per reset's flow (= {bo_mod:.2f} kg/s x {w_exp/1e3:.1f} kJ/kg), "
      f"heat needed scales identically (output/heat unchanged)")
w_eff = P/(md+bo_mod)
print(f"    without extra rings: specific work per kg falls to {w_eff/1e3:.1f} kJ/kg (P unchanged at {P/1e6:.2f} MW)")
q_avail = h_vent[453.15]-h_liq
print(f"    [A #13] '+1.2 kW per kg/h' = {1.2e3*3600/1e3:,.0f} kJ/kg, vs the most enthalpy 1 kg of N2 can take between sat. liquid "
      f"at 77.35 K and gas at 453.15 K: {q_avail/1e3:.1f} kJ/kg (x{1.2e3*3600/q_avail:.1f}) -> not a flow-alone law")
for x in (0.24, 0.56):
    up = (1+f_bo)**x
    print(f"    [A #20] sigma ~ R^{x}: R x{1+f_bo:.4f} -> sigma, P x{up:.4f} (+{(up-1)*P/1e6:.2f} MW) RECORDED, NOT APPLIED "
          f"(inside sigma_b, write-once lock [A 12.1.1])")
s4x = 640.055e3/200e3*3600
print(f"    S4X recycled flow (640.055 kW / 200 kJ/kg) = {s4x:,.0f} kg/h ([A] 11,510 via the 13,520 ratio): heat side, not added to P")

# ---- (c) itemised electricity ----
etaB = 16.08/20.1                               # [9]: incompressible v dP 16.08 kJ/kg vs 20.1 kJ/kg shaft (Mode L)
dP_loop = 6.0e5                                 # Pa: working chamber pressure ~5.5-6 bar gauge [A #33, M19]
w_pump_loop = dP_loop/rho_L                     # J/kg, v dP
E_loop = md*w_pump_loop/etaB
E_ret = bo_mod*w_pump_loop/etaB                 # returning re-made LN2 to the shared tank, per reset
E_ctrl = 0.8e3                                  # W, < 0.8 kW liquefaction + controls (MWH) [A]
E_strip = 11.7                                  # W, Book 1 strip (bearings 9.7 + stator 1.0 + Marx 1.0) [8]
E_aux = E_loop + E_ctrl + E_strip
E_code = (4.0 + 0.5*md*3600/100)*1e3            # [A] code bundle law extrapolated to the worked flow (not adopted)
P_psa = 0.18*mmu*3600*1e3                       # [A L7] PSA 0.18 kWh/kg x makeup, if separate from the SEC
print(f"(c) eta_B = {etaB:.3f} [9]; v dP at 6 bar = {w_pump_loop:.1f} J/kg; loop pump ideal {md*w_pump_loop/1e6:.4f} MW, "
      f"shaft {E_loop/1e6:.4f} MW; return pump per reset {E_ret/1e6:.4f} MW")
print(f"    controls {E_ctrl/1e3:.1f} kW; strip {E_strip} W; E_aux per module = {E_aux/1e6:.4f} MW ({E_aux/P:.3%} of P)")
print(f"    code bundle law 4.0 kW + 0.5 kW per 100 kg/h at {md*3600:,.0f} kg/h = {E_code/1e6:.2f} MW (extrapolated "
      f"x{md*3600/500:,.0f} beyond its 500 kg/h point; not adopted)")
print(f"    PSA if separate from the SEC: {P_psa/1e6:.3f} MW (v4: may sit inside the SEC)")
print(f"    tank-head option [A #87]: 6 bar head -> loop pump 0, E_aux = {(E_ctrl+E_strip)/1e3:.2f} kW")

# ---- (d) machine factors from published second-law efficiencies ----
w_min_kg = 0.207                                # kWh/kg [9] Sec. 3.5
eII_ref_hi = w_min_kg/0.40; eII_ref_lo = w_min_kg/0.60   # [9]: large industrial liquefiers 0.4-0.6 kWh/kg
eII_ref_green = 0.30                            # [19] large refrigerators ~30 % of Carnot; [18] same relative losses 30-90 K
eII_eng = 0.40                                  # [20] measured 300 kW ORC: gross efficiency ~40 % of Carnot
f_des = eII_eng*eII_ref_hi; f_siz = eII_eng*eII_ref_lo; f_grn = eII_eng*eII_ref_green
print(f"(d) refrigeration/liquefaction second-law fraction: [9] {eII_ref_lo:.4f}-{eII_ref_hi:.4f}; [19] ~{eII_ref_green:.2f}")
print(f"    heat engine 453.15->300 K: {eII_eng:.2f} of Carnot -> real engine efficiency {eII_eng*eta_h:.4f}")
print(f"    combined heat-driven lift factor: design {f_des:.4f}, sizing {f_siz:.4f}, [19] check {f_grn:.4f} (r5 used 0.70)")
print(f"    1 MW of electricity into the lift replaces {1/(eII_eng*eta_h):.2f} MW of heat (real engine) vs {1/eta_h:.2f} (ideal)")
LIFT = {}
for lab, er in (("design", eII_ref_hi), ("sizing", eII_ref_lo), ("Green30", eII_ref_green)):
    W_real = Wl/er
    Qlh_r = W_real/(eII_eng*eta_h)
    Qt_r = Qin + Qlh_r
    be_el = main['Qbe']*er
    LIFT[lab] = dict(er=er, W=W_real, Qlh=Qlh_r, Qt=Qt_r, be=be_el, net_el=P - W_real)
    print(f"    {lab:7s}: lift work {W_real/1e6:7.2f} MW; electric-only net {(P-W_real)/1e6:+8.2f} MW (before makeup); "
          f"electric break-even {be_el/1e6:6.2f} MW vs floor {Qc/1e6:.2f}; heat for lift {Qlh_r/1e6:8.2f} MW; "
          f"total heat {Qt_r/1e6:8.2f} MW ({Qt_r/P:.2f} P); P/Q {P/Qt_r:.1%}; ambient {(Qt_r-P)/1e6:,.2f} MW")
# electric fraction of lift needed for the electric route to close (net > 0 after makeup), design factor
print(f"    electric route needs lift second-law fraction >= {Wl/(P-P_liq_v7):.4f} to net > 0 after makeup")

# ---- (e) AI draw ----
AI_lo, AI_hi = 0.02*P, 0.10*P
print(f"(e) AI 2-10 % of one module's P: {AI_lo/1e6:.2f}-{AI_hi/1e6:.2f} MW; controls < 0.8 kW per module")
for N in (1, 10, 100, 1000):
    print(f"    N {N:5d}: per-module AI {N*AI_lo/1e6:,.2f}-{N*AI_hi/1e6:,.2f} MW | one fleet instance {AI_lo/1e6:.2f}-{AI_hi/1e6:.2f} MW | "
          f"controls {N*E_ctrl/1e3:,.1f} kW")

# ---- r6 headline: hybrid (heat-led) at the derived design point ----
print("\n--- r6 headline (one module, N = 1; fleet AI instance at 2 % booked) ---")
Lt = LIFT['design']; Ls = LIFT['sizing']
net_mod = P - P_liq_v7 - E_aux
net_mod_ai = net_mod - AI_lo
print(f"net before AI {net_mod/1e6:.2f} MW; with fleet AI at 2 % {net_mod_ai/1e6:.2f} MW; with AI 10 % {(net_mod-AI_hi)/1e6:.2f} MW")
print(f"heat (design) {Lt['Qt']/1e6:,.2f} MW; (sizing) {Ls['Qt']/1e6:,.2f} MW")
TAB13A = []
eng_real = eII_eng*eta_h
for El in (0.0, 5e6, 10e6, 20e6, 40e6):
    row = [El]
    for L in (Lt, Ls):
        Qlh_E = (L['W'] - El)/eng_real
        row.append(Qin + Qlh_E)
    net = P - P_liq_v7 - E_aux - El
    row.append(net)
    TAB13A.append(row)
    print(f"  E_lift {El/1e6:5.1f} MW ({El/Lt['W']:.1%} of design lift work, {El/P:.2%} of P): total heat design {row[1]/1e6:,.2f} MW, "
          f"sizing {row[2]/1e6:,.2f} MW; plant net (before AI) {net/1e6:.2f} MW")

# ---- r6 fleet ----
print("\n--- r6 fleet (single vent; E_aux per module + return pumps per reset; one AI instance at 2-10 %) ---")
FLEET6 = {}
for eta in (0.996, 0.999):
    for N in (1, 10, 100, 1000):
        Pmu_f = (1-eta)*md*3600*0.55*1000
        Eel = N*E_aux + (N-1)*E_ret
        gross = N*P
        nAI = -(-N//100)                       # r10: one AI-oracle instance per 100-module chain/cluster [2, 3]
        net_lo = gross - Pmu_f - Eel - nAI*AI_hi; net_hi = gross - Pmu_f - Eel - nAI*AI_lo
        heat_d = N*Lt['Qt']; heat_s = N*Ls['Qt']
        FLEET6[(N, eta)] = dict(Pmu=Pmu_f, Eel=Eel, gross=gross, net_lo=net_lo, net_hi=net_hi, heat_d=heat_d, heat_s=heat_s,
                                R2=gross/Pmu_f, Rall=gross/(Pmu_f+Eel+nAI*AI_lo), nAI=nAI)
        print(f"  eta {eta} N {N:5d}: makeup {Pmu_f/1e6:.2f} MW | E_aux+return {Eel/1e6:,.2f} MW | gross {gross/1e6:,.2f} | "
              f"net {net_lo/1e6:,.2f}-{net_hi/1e6:,.2f} MW | heat design {heat_d/1e6:,.0f} sizing {heat_s/1e6:,.0f} MW | "
              f"R2,N {gross/Pmu_f:,.1f} | gross/(makeup+E+AI2%) {gross/(Pmu_f+Eel+nAI*AI_lo):.1f} | AI instances {nAI}")
for N in (100,):
    print(f"  N {N}: generator lift heat (N-1 floors) design {(N-1)*Lt['Qlh']/1e6:,.2f} MW, sizing {(N-1)*Ls['Qlh']/1e6:,.2f} MW")
for k in (2, 3):
    print(f"  cascade: factor compounded over {k} stages = {f_des**k:.4f} of ideal vs {f_des:.4f} once")

# ---- r6 supply and leak (derived E) ----
GW_eu = 202.0*1e12/8760/1e9
print(f"\nEU >=200 C heat {GW_eu:.2f} GW -> modules: design {GW_eu*1e9/Lt['Qt']:.1f}, sizing {GW_eu*1e9/Ls['Qt']:.1f}, "
      f"ideal {GW_eu*1e9/main['Qtot']:.1f}; one design module = {Lt['Qt']/(GW_eu*1e9):.2%}")
LEAK6 = {}
for lab, secL in [("w_min 0.167", 0.167), ("v7 0.444", 0.55*rho_L/1000), ("0.90", 0.90), ("1.40", 1.40)]:
    sec_kg = secL/(rho_L/1000)
    f_net = (P - E_aux - AI_lo)/(md*3600*sec_kg*1000)
    LEAK6[lab] = f_net
    print(f"  leak for net > 0 (E_aux + AI 2 %) at {secL:.3f} kWh/L: {f_net:.2%}")
print(f"P/Q (design) {P/Lt['Qt']:.1%}, (sizing) {P/Ls['Qt']:.1%}; Carnot plant {eta_C_amb:.1%}")

# ---- r6 audit ----
if os.path.exists(md_path):
    txt = open(md_path, encoding="utf-8").read()
    fm2 = lambda x: f"{x:,.2f}"
    c6 = {"w_iso6": f"{w_iso6/1e3:.1f}", "eps_max": f"{eps_max:.3f}", "eps_be": f"{eps_be:.3f}", "Qin_mod": fm2(Qin_mod/1e6),
          "Hleak": f"{Hleak/1e6:.3f}", "f_bo": f"{f_bo:.4f}", "rings per": f"{1/f_bo:.2f}", "extra ring MW": fm2(f_bo*P/1e6),
          "w_eff": f"{w_eff/1e3:.1f}", "4320": "4,320", "q_avail": f"{q_avail/1e3:.1f}",
          "sig lo": f"{(1+f_bo)**0.24:.3f}", "sig hi": f"{(1+f_bo)**0.56:.3f}",
          "etaB": f"{etaB:.2f}", "vdP": f"{w_pump_loop/1e3:.3f}", "E_loop": f"{E_loop/1e6:.3f}", "E_ret": f"{E_ret/1e6:.3f}",
          "E_aux": f"{E_aux/1e6:.3f}", "E_code": f"{E_code/1e6:.2f}", "PSA": f"{P_psa/1e6:.2f}",
          "eII lo": f"{eII_ref_lo:.3f}", "eII hi": f"{eII_ref_hi:.3f}", "f_des": f"{f_des:.3f}", "f_siz": f"{f_siz:.3f}",
          "heat per E": f"{1/(eII_eng*eta_h):.2f}", "eng real": f"{eII_eng*eta_h:.3f}",
          "Qt des": fm2(Lt['Qt']/1e6), "Qt siz": fm2(Ls['Qt']/1e6), "Qlh des": fm2(Lt['Qlh']/1e6), "Qlh siz": fm2(Ls['Qlh']/1e6),
          "W des": fm2(Lt['W']/1e6), "W siz": fm2(Ls['W']/1e6), "be des": fm2(Lt['be']/1e6), "be siz": fm2(Ls['be']/1e6),
          "net_mod": fm2(net_mod/1e6), "net_mod_ai": fm2(net_mod_ai/1e6),
          "AI lo": f"{AI_lo/1e6:.2f}", "AI hi": f"{AI_hi/1e6:.2f}",
          "mods des": f"{GW_eu*1e9/Lt['Qt']:.1f}", "mods siz": f"{GW_eu*1e9/Ls['Qt']:.1f}",
          "PQ des": f"{P/Lt['Qt']:.1%}".replace('%', ' %'), "PQ siz": f"{P/Ls['Qt']:.1%}".replace('%', ' %'),
          "N100 net hi": fm2(FLEET6[(100, 0.996)]['net_hi']/1e6), "N100 heat d": f"{FLEET6[(100, 0.996)]['heat_d']/1e6:,.0f}",
          "N100 gen lift": fm2(99*Lt['Qlh']/1e6), "elec need": f"{Wl/(P-P_liq_v7):.3f}"}
    bad = [k for k, v in c6.items() if v not in txt]
    print("AUDIT r6:", "PASS - all r6 derived numbers present" if not bad else f"MISSING {[(k, c6[k]) for k in bad]}")
    left = re.findall(r"\[assumption[^\]]*\]", txt)
    print("AUDIT r6 remaining [assumption] tags in the text:", len(left), left)

# ---- r6 extra values quoted in the section (Table 13c lift heat, boil-off re-making cost, checks) ----
print("\n=== r6 extra values quoted ===")
for N in (1, 10, 100, 1000):
    print(f"  Table 13c N {N}: generator {(N-1)*Lt['Qlh']/1e6:,.2f} + main J-T {Lt['Qlh']/1e6:,.2f} = {N*Lt['Qlh']/1e6:,.2f} MW (design)")
print(f"  re-making boil-off at design: work {w_bo/eII_ref_hi/1e3:,.1f} kJ/kg ({w_bo/eII_ref_hi/3.6e6*rho_L/1000:.4f} kWh/L); "
      f"heat {q_bo/f_des/1e3:,.1f} kJ/kg; x {bo_mod:.2f} kg/s = {bo_mod*q_bo/f_des/1e6:,.2f} MW")
print(f"  loop vdP {w_pump_loop/1e3:.3f} kJ/kg; return pump {E_ret/1e6:.3f} MW; controls {E_ctrl/1e6:.4f} MW; strip {E_strip/1e6:.5f} MW")
print(f"  real engine efficiency {eII_eng*eta_h:.1%}; Green check vs sizing {LIFT['Green30']['Qt']/Ls['Qt']-1:.1%}; "
      f"design heat {Lt['Qt']/1e9:.2f} GW; PSA {P_psa/1e6:.2f} MW; w_iso6 {w_iso6/1e3:.1f} kJ/kg")
print(f"  all-electricity ratio limit P/(E_aux+E_ret) = {P/(E_aux+E_ret):.0f}")

# =====================================================================================================
# ==== r7 (28 Oct 2026, Morgan 12:52): main J-T heat exchanger INSIDE the shared LN2 tank, ABOVE   ====
# ==== the liquid level (cold N2 vapour space / ullage); not immersed, not on the LN2 liquid circuit. =
# =====================================================================================================
print("\n=================== r7 ULLAGE PLACEMENT OF THE MAIN J-T EXCHANGER ===================")
SB = 5.670374419e-8
p_t = 101325.0                                  # tank pressure on the 77.35 K basis (N2 NBP)
h_g = 77153.925                                 # J/kg sat. vapour at 77.35 K (Span et al. EoS / CoolProp)
# superheated N2 vapour at 1 atm: (T K, h J/kg, k W/m K)  [Span et al. EoS via CoolProp 8.0.0, hard-coded]
VAP = [(77.36, 77163.348, 0.007188), (78, 77881.732, 0.007250), (79, 79000.701, 0.007348), (80, 80115.679, 0.007445),
       (82, 82334.802, 0.007640), (85, 85639.996, 0.007932), (90, 91098.410, 0.008418), (95, 96508.709, 0.008901),
       (100, 101882.819, 0.009382), (110, 112553.384, 0.010335), (120, 123152.805, 0.011274), (140, 144224.082, 0.013109),
       (160, 165196.855, 0.014887), (200, 206996.722, 0.018280), (250, 259120.798, 0.022251), (270, 279952.458, 0.023766),
       (300, 311193.446, 0.025969)]
try:
    import CoolProp.CoolProp as C
    VAP = [(T, C.PropsSI('H','T',T,'P',p_t,'N2'), C.PropsSI('L','T',T,'P',p_t,'N2')) for T, _, _ in VAP]
    h_g = C.PropsSI('H','T',Tc,'Q',1,'N2')
except Exception:
    pass
def h_of_T(T):
    for (T1, h1, _), (T2, h2, _) in zip(VAP, VAP[1:]):
        if T1 <= T <= T2: return h1 + (h2-h1)*(T-T1)/(T2-T1)
    raise ValueError(T)
def T_of_dh(dh):
    h = h_g + dh
    for (T1, h1, _), (T2, h2, _) in zip(VAP, VAP[1:]):
        if h1 <= h <= h2: return T1 + (T2-T1)*(h-h1)/(h2-h1)
    return float('nan')
def k_of_T(T):
    for (T1, _, k1), (T2, _, k2) in zip(VAP, VAP[1:]):
        if T1 <= T <= T2: return k1 + (k2-k1)*(T-T1)/(T2-T1)
Q_JT = Qc                                       # main J-T duty = final module's reset heat (Eq. 6.6b)
T_lim = 140.0                                   # r10: ullage vapour outlet limit = top of the generator's Input C band, 80-140 K [9, 4.1, Fig. 2]
T_des = 80.0                                    # top of Morgan's 77-80 K ullage band
dh = lambda T: h_of_T(T) - h_g
print(f"(j) vapour sensible capacity dh(T_u) = h(T_u, 1 atm) - h_g(77.35 K): 80 K {dh(80)/1e3:.3f}, 100 K {dh(100)/1e3:.2f}, "
      f"140 K {dh(140)/1e3:.2f}, 300 K {dh(300)/1e3:.2f} kJ/kg")
for T in (80.0, 100.0, 140.0):
    print(f"    vapour flow needed to carry {Q_JT/1e6:.2f} MW with outlet {T:.0f} K: {Q_JT/dh(T):,.1f} kg/s")
# (1) the vent alone
vent_max = mmu*dh(300.0)
print(f"    vent alone ({mmu:.3f} kg/s) carries at most {vent_max/1e6:.3f} MW even at 300 K ({vent_max/Q_JT:.1%} of the duty) -> not the path")
# (2) boil-off vapour from the N-1 resets routed through the ullage: required superheat dh = Q_JT/((N-1) m_bo) = h_fg/(N-1)
print("(k) boil-off vapour through the ullage: dh_req = Q_JT / ((N-1) m_bo) = h_fg / (N-1)")
N80 = __import__('math').ceil(1 + Q_JT/(bo_mod*dh(T_des)))
N160 = __import__('math').ceil(1 + Q_JT/(bo_mod*dh(T_lim)))
print(f"    ullage outlet <= 80 K from boil-off vapour alone for N >= {N80}; <= 140 K for N >= {N160}")
# r8 (Morgan 13:01/13:02): the generator's own suction draws the ullage vapour (D14). The exchanger's < 0.05 bar drop
# [A] sits inside the generator duty already booked; no separate line is added.
ULL = {}
for N in (1, 2, 4, 10, 69, 100, 1000):
    m_bo_N = (N-1)*bo_mod
    if m_bo_N >= Q_JT/dh(T_des):                # enough boil-off vapour: route only what holds the ullage at 80 K
        Tu = T_des; m_u = Q_JT/dh(T_des); m_x = 0.0
    elif m_bo_N > 0 and Q_JT/m_bo_N <= dh(T_lim):
        Tu = T_of_dh(Q_JT/m_bo_N); m_u = m_bo_N; m_x = 0.0
    else:
        Tu = T_lim; m_u = Q_JT/dh(T_lim); m_x = m_u - m_bo_N
    ULL[N] = dict(Tu=Tu, m_u=m_u, m_x=m_x)
    print(f"    N {N:5d}: boil-off vapour {m_bo_N:,.2f} kg/s; ullage outlet {Tu:6.2f} K; ullage vapour flow {m_u:,.2f} kg/s "
          f"(cold-gas recirculation drawn by the generator suction {m_x:,.2f} kg/s); drawn by the generator's own suction (D14), inside its booked duty")
# (3) heat to the liquid surface across the stably stratified vapour (warm over cold: no free convection)
print("(l) heat reaching the liquid surface from the exchanger, per 1,000 m2 of exchanger face (black-body bound, eps = 1):")
for Tx in (80.0, 100.0, 160.0, 300.0):
    q_rad = SB*(Tx**4 - Tc**4)
    k_m = k_of_T((Tx+Tc)/2)
    q_cond = k_m*(Tx - Tc)/1.0                  # W/m2 across a 1 m vapour gap (scales as 1/gap)
    Qs = 1000*(q_rad+q_cond)
    print(f"    surface {Tx:5.0f} K: radiation {q_rad:8.2f} W/m2, conduction (1 m gap, k {k_m:.4f}) {q_cond:5.2f} W/m2 -> "
          f"{Qs/1e3:7.2f} kW per 1,000 m2 = {Qs/Q_JT:.3%} of the duty, boils {Qs/hfg_77:.3f} kg/s")
# (4) ledger: where the main J-T heat ends up
print("(m) ledger: the main J-T heat leaves the tank as vapour superheat to the LN2 generator; generator duty = latent (N-1) floors "
      "+ sensible 1 floor = N x floor")
for N in (1, 10, 100, 1000):
    lat = (N-1)*bo_mod*hfg_77; sen = Q_JT
    print(f"    N {N:5d}: generator latent {lat/1e6:,.2f} MW + sensible {sen/1e6:.2f} MW = {(lat+sen)/1e6:,.2f} MW = N x floor "
          f"{N*Qc/1e6:,.2f} MW; lift heat at design {N*Lt['Qlh']/1e6:,.2f} MW (unchanged; lifting from T_u > 77.35 K is no dearer)")
vent_u = mmu*(h_of_T(T_des) - h_liq)
print(f"    single vent on the ullage at {T_des:.0f} K carries {vent_u/1e6:.3f} MW (r6 range 0.99-1.38 MW at 293.15-453.15 K)")

for N in (4, 10):
    print(f"    dh_req N {N}: {hfg_77/(N-1)/1e3:.1f} kJ/kg -> outlet {T_of_dh(hfg_77/(N-1)):.1f} K")
print(f"    radiation 300 K {SB*(300**4-Tc**4):.1f} W/m2")
# ---- r7 audit ----
if os.path.exists(md_path):
    txt = open(md_path, encoding="utf-8").read()
    c7 = {"dh80": f"{dh(80)/1e3:.2f}", "dh140": f"{dh(140)/1e3:.2f}", "dh300": f"{dh(300)/1e3:.2f}",
          "vent max": f"{vent_max/1e6:.3f}", "vent share": f"{vent_max/Q_JT:.1%}".replace('%', ' %'),
          "vent ullage": f"{vent_u/1e6:.2f}",   # r9: flows, outlet temperatures and N thresholds are audited in c9 (vent + J-T share)
          }   # r9: the liquid-path radiation figures are withdrawn from the text (D1, Morgan 13:16/13:18)
    bad = [k for k, v in c7.items() if v not in txt]
    print("AUDIT r7:", "PASS - all ullage numbers present" if not bad else f"MISSING {[(k, c7[k]) for k in bad]}")
    # design choices <-> Table 13d cross-reference
    sec = txt.split("### 6.6.2 Design choices")[1].split("### 6.6.3")[0] if "### 6.6.2 Design choices" in txt else ""
    t13d = txt.split("\nTable 13d. Inputs")[1].split("###")[0] if "\nTable 13d. Inputs" in txt else ""
    d_sec = set(re.findall(r"\*\*(D\d+)\b", sec)); d_tab = set(re.findall(r"\b(D\d+)\b", t13d))
    print("AUDIT r7 design choices in 6.6.2:", sorted(d_sec, key=lambda s: int(s[1:])),
          "| missing from Table 13d:", sorted(d_sec - d_tab) or "none", "| in Table 13d but not 6.6.2:", sorted(d_tab - d_sec) or "none")
    for must in ("inside the shared LN₂ tank", "above the liquid level", "ullage", "not immersed"):
        print(f"AUDIT r7 phrase '{must}':", txt.count(must))
    print("AUDIT r7 stale 'takes it directly' (r6 main J-T routing) occurrences:", txt.count("takes it directly"))

# =====================================================================================================
# ==== r8 (Morgan 13:01 / 13:02): one continuous high-to-low pressure system; the generator's own  ====
# ==== suction draws the ullage vapour (D14); credit for vapour pressure remaining at the generator ====
# ==== inlet above its baseline (D15).                                                             ====
# =====================================================================================================
print("\n=================== r8 SHARED PRESSURE CHANNEL: GENERATOR INLET CREDIT ===================")
from math import log
p_base = 101325.0                               # [9]: LN2 product at NBP 1.01 bar; ambient makeup 1.00 bar; r6 re-making basis
# Span et al. EoS (CoolProp 8.0.0), hard-coded; live values used when CoolProp is present
hl0, sl0 = -122028.567, 2834.0440                # sat. liquid 77.35 K
hA, sA = 311193.446, 6841.7344                   # dead state 300 K, 1 atm
SATV = {0.0: (77.3550, 77157.722, 5409.0066)}    # gauge bar -> (T_sat K, h_v J/kg, s_v J/kg K)
p_w = (5.5e5, 6.0e5)                             # working chamber pressure, bar gauge [A #33]
p_res = [((p_t + pw)/6.0 - p_t) for pw in p_w]   # head left after the 6:1 ring expansion (w_exp basis, r6 check)
CASES = [("tank pressure (77.35 K basis)", 0.0), ("residual after 6:1 from 5.5 bar g", p_res[0]),
         ("residual after 6:1 from 6.0 bar g", p_res[1]), ("pressurised tank, 5.5 bar g [A #33]", 5.5e5),
         ("pressurised tank, 6 bar g head [A #87]", 6.0e5), ("top of the 3-8 bar g band [A #33]", 8.0e5)]
HARD = {round(p_res[0]/1e5, 4): (77.9437, 77601.918, 5395.2006), round(p_res[1]/1e5, 4): (78.5877, 78080.058, 5380.3604),
        5.5: (97.4942, 87423.220, 5026.2778), 6.0: (98.5199, 87596.135, 5009.6625), 8.0: (102.1618, 87833.727, 4951.1746)}
SATV.update(HARD)
try:
    import CoolProp.CoolProp as C
    hl0 = C.PropsSI('H','T',Tc,'Q',0,'N2'); sl0 = C.PropsSI('S','T',Tc,'Q',0,'N2')
    hA = C.PropsSI('H','T',Ta,'P',p_base,'N2'); sA = C.PropsSI('S','T',Ta,'P',p_base,'N2')
    def satv(pg):
        p = p_base + pg
        return (C.PropsSI('T','P',p,'Q',1,'N2'), C.PropsSI('H','P',p,'Q',1,'N2'), C.PropsSI('S','P',p,'Q',1,'N2'))
except Exception:
    def satv(pg): return SATV[round(pg/1e5, 4)]
ex = lambda h, s: (h - hA) - Ta*(s - sA)         # flow exergy, dead state 300 K / 1 atm
print("(n) naive per-kg credit, isothermal at T_a (exergy basis): dw = R T_a ln(p_in/p_base)  [cold compression at T plus lifting "
      "its heat to T_a gives the same R T_a ln]")
print("(o) consistent chain: the vapour carries p_in only because the reset LN2 boils at p_in, i.e. at T_sat(p_in). The ring's cold end "
      "is then T_sat, so floor, boil-off and re-making work all move together:")
print("    Q_c(T) = P T/(T_h - T); m_bo = Q_c/(h_v - h_l0); W_gen = m_bo (ex_l0 - ex_v)")
CR = {}
base = None
for lab, pg in CASES:
    Ts, hv, sv = satv(pg)
    p_in = p_base + pg
    naive = R_N2*Ta*log(p_in/p_base)
    q = hv - hl0
    w = ex(hl0, sl0) - ex(hv, sv)
    Qcs = P*Ts/(Th - Ts)
    mbs = Qcs/q
    W = mbs*w
    lift_heat = W/eII_ref_hi/(eII_eng*eta_h)
    tot = P + Qcs + lift_heat
    Wf = P*(Ta - Ts)/(Th - Ts)                    # final module: its floor goes to the ullage vapour at T_sat and is lifted from T_sat
    tot_f = P + Qcs + Wf/eII_ref_hi/(eII_eng*eta_h)
    if base is None: base = dict(w=w, W=W, lh=lift_heat, tot=tot, mbo=mbs, Wf=Wf, tot_f=tot_f)
    CR[lab] = dict(pg=pg, p=p_in, Ts=Ts, naive=naive, w=w, Qc=Qcs, mbo=mbs, W=W, load=W/base['W'], lh=lift_heat, tot=tot,
                   d_tot=tot-base['tot'], d_W=W-base['W'], naive_frac=naive/base['w'],
                   mbo_a=bo_mod + (mbs - base['mbo']), tot_a=Lt['Qt'] + (tot - base['tot']),   # anchored on the r6 headline basis
                   d_f=tot_f-base['tot_f'], d_Wf=Wf-base['Wf'])
    print(f"  {lab:40s}: p_in {p_in/1e5:.4f} bar a, T_sat {Ts:6.2f} K | naive credit {naive/1e3:6.1f} kJ/kg = {naive/base['w']:5.1%} of "
          f"{base['w']/1e3:.1f} -> naive load {1-naive/base['w']:.1%} | consistent: w {w/1e3:6.1f} kJ/kg, floor {Qcs/1e6:6.2f} MW, "
          f"boil-off {mbs:7.2f} kg/s, generator work {W/1e6:6.2f} MW, load {W/base['W']:.2%}, lift heat {lift_heat/1e6:8.2f} MW, "
          f"module heat {tot/1e6:8.2f} MW ({(tot-base['tot'])/1e6:+.2f}), lift work saved {-(W-base['W'])/1e6:+.2f} MW")
print("  anchored on the 77.35 K headline (removes the 0.01 offset of saturation at 1.013 bar, 77.355 K, against the 77.35 K basis):")
for lab, c in CR.items():
    print(f"    {lab:40s}: boil-off {c['mbo_a']:.2f} kg/s, reset-module heat {c['tot_a']/1e6:,.2f} MW ({c['d_tot']/1e6:+.2f}); "
          f"final module (main J-T at T_sat) {c['d_f']/1e6:+.2f} MW heat, {-c['d_Wf']/1e6:+.2f} MW lift work saved; "
          f"consistent per-kg cut {1-c['w']/base['w']:.1%}")
best = min(CR.values(), key=lambda c: c['d_tot'])
print(f"  best consistent case: p_in {best['p']/1e5:.4f} bar, load {best['load']:.2%}, heat saved {-best['d_tot']/1e6:.2f} MW per reset module "
      f"({-best['d_tot']/base['tot']:.2%}), lift work saved {-best['d_W']/1e6:.2f} MW (electricity saved only if E_lift > 0; design E_lift = 0)")
print("  fleet, case A (reset LN2 pumped to p_in, vapour kept at p_in in a closed passage to the generator; tank at 1.013 bar):")
for N in (1, 10, 100):
    print(f"    N {N}: reset modules {N-1}; heat saved <= {(N-1)*-best['d_tot']/1e6:,.2f} MW ({(N-1)*-best['d_tot']/(N*Lt['Qt']):.2%}); "
          f"lift work saved <= {(N-1)*-best['d_W']/1e6:,.2f} MW")
bB = min(CR.values(), key=lambda c: c['d_f'])
print("  case B (whole tank held at p_in: every module's cold end at T_sat = a warmer T_c, not a pressure credit; NOT booked):")
for lab, c in CR.items():
    print(f"    {lab:40s}: per module {c['d_f']/1e6:+.2f} MW heat; ring heat in {(P + c['Qc'])/1e6:.2f} MW")
for N in (1, 100):
    print(f"    N {N}: up to {N*-bB['d_f']/1e6:,.2f} MW heat ({-bB['d_f']/Lt['Qt']:.2%}) at T_sat {bB['Ts']:.2f} K, valid only if P is unchanged at that T_c")
# review finding: final-module rejection temperature with the ullage outlet above 77.35 K (entropic mean T_m = dh/ds of the vapour)
TM = {140.0: 105.31236, 139.36: 105.05059, 97.58: 87.05798, 80.0: 79.01714}   # r10: 140 K cap (Input C [9])
try:
    hg = C.PropsSI('H','T',Tc,'Q',1,'N2'); sg = C.PropsSI('S','T',Tc,'Q',1,'N2')
    TM = {Tu: (C.PropsSI('H','T',Tu,'P',p_base,'N2')-hg)/(C.PropsSI('S','T',Tu,'P',p_base,'N2')-sg) for Tu in TM}
except Exception: pass
print("  review: final module rejects into vapour warming 77.35 K -> T_u; entropic-mean rejection T_m sets its floor:")
FM = {}
for Tu, Tm in TM.items():
    Qm = P*Tm/(Th - Tm); Wm = P*(Ta - Tm)/(Th - Tm)
    dHt = (Qm - main['Qc']) + (Wm - P*(Ta-Tc)/(Th-Tc))/eII_ref_hi/(eII_eng*eta_h)
    FM[Tu] = (Tm, Qm, dHt)
    print(f"    T_u {Tu:6.2f} K: T_m {Tm:6.2f} K, final-module floor {Qm/1e6:5.2f} MW ({(Qm-main['Qc'])/1e6:+.2f}), ring heat in {(P+Qm)/1e6:.2f} MW, "
          f"module heat {dHt/1e6:+.2f} MW vs the 77.35 K booking")
r6c = CR["residual after 6:1 from 6.0 bar g"]
print(f"  naive booking check (floor held at 29.07 MW, boil-off at {bo_mod:.2f} kg/s, credit R T_a ln on the 6 bar g head): "
      f"{bo_mod*CR['pressurised tank, 6 bar g head [A #87]']['naive']/1e6:.2f} MW of lift work per reset -> double counts the warmer boil")

# ---- r8 audit ----
if os.path.exists(md_path):
    txt = open(md_path, encoding="utf-8").read()
    t6 = CR['pressurised tank, 6 bar g head [A #87]']; tr = CR['residual after 6:1 from 6.0 bar g']
    c8 = {"res6 bar": f"{tr['p']/1e5:.3f}", "res55 bar": f"{CR['residual after 6:1 from 5.5 bar g']['p']/1e5:.3f}",
          "naive6": f"{t6['naive']/1e3:.1f}", "naive6 frac": f"{t6['naive_frac']:.1%}".replace('%', ' %'),
          "naive res": f"{tr['naive']/1e3:.1f}", "Ts6": f"{t6['Ts']:.1f}", "w6": f"{t6['w']/1e3:.1f}", "floor6": f"{t6['Qc']/1e6:.2f}",
          "mbo6": f"{t6['mbo_a']:.2f}", "W6": f"{t6['W']/1e6:.2f}", "load6": f"{t6['load']:.2%}".replace('%', ' %'),
          "loadres": f"{tr['load']:.2%}".replace('%', ' %'), "dtot res": f"{-tr['d_tot']/1e6:.2f}", "dtot6": f"{-t6['d_tot']/1e6:.2f}",
          "best saved": f"{-best['d_tot']/1e6:.2f}", "N100 saved": f"{99*-best['d_tot']/1e6:,.1f}",
          "N100 work": f"{99*-best['d_W']/1e6:,.2f}", "N10 saved": f"{9*-best['d_tot']/1e6:.2f}",
          "B8": f"{-bB['d_f']/1e6:.2f}", "B55": f"{-CR['pressurised tank, 5.5 bar g [A #33]']['d_f']/1e6:.2f}",
          "B6": f"{-t6['d_f']/1e6:.2f}", "cut8": f"{1-CR['top of the 3-8 bar g band [A #33]']['w']/base['w']:.1%}".replace('%',' %'),
          "w8": f"{CR['top of the 3-8 bar g band [A #33]']['w']/1e3:.1f}",
          "Tm140": f"{FM[140.0][0]:.1f}", "Qm140": f"{FM[140.0][1]/1e6:.2f}", "dH140": f"{-FM[140.0][2]/1e6:.2f}",
          "Tm80": f"{FM[80.0][0]:.1f}", "Qm80": f"{FM[80.0][1]/1e6:.2f}", "Qm97": f"{FM[97.58][1]/1e6:.2f}", "naive MW": f"{bo_mod*t6['naive']/1e6:.2f}",
          "load8": f"{CR['top of the 3-8 bar g band [A #33]']['load']:.2%}".replace('%', ' %'),
          "dtot8": f"{CR['top of the 3-8 bar g band [A #33]']['d_tot']/1e6:+.2f}"}
    bad = [k for k, v in c8.items() if v not in txt]
    print("AUDIT r8:", "PASS - all pressure-channel numbers present" if not bad else f"MISSING {[(k, c8[k]) for k in bad]}")
    stale = ["uction-drop", "1,374.04", "7.82 MW", "116.30", "push", "upper-bound line"]
    print("AUDIT r8 stale push-cost strings:", {s: txt.count(s) for s in stale if txt.count(s)} or "none")
    print("AUDIT r8 'blower' / 'fan' (every occurrence must be a negation: 'no separate blower'):", txt.count("blower"), txt.count(" fan"))


# =====================================================================================================
# ==== r9 (Morgan 13:16 / 13:18): D1 corrected. The main J-T exchanger sits in the tank above the  ====
# ==== liquid, thermally disconnected from the LIQUID (no conduction or immersion path, no extra    ====
# ==== boil-off). It is cooled by the cold N2 vapour above the liquid plus its own passive J-T      ====
# ==== self-cooling.                                                                                ====
# =====================================================================================================
print("\n=================== r9 MAIN J-T EXCHANGER: J-T SELF-COOLING + VAPOUR PICKUP ===================")
# (a) J-T self-cooling: isothermal enthalpy defect dh_T = h(T, p_low) - h(T, p_high), x the stream flow mdot.
#     p_high: what reaches the exchanger. Booked: the head left after the ring's 6:1 expansion (w_exp already spends the rest).
#     Envelope, NOT booked: the full working 5.5-6 bar g (would spend the same pressure twice, against w_exp).
#     T: 243 K = published final-module exhaust (Parasitic-reduction doc, 6.3.2); 100 K = cold-end envelope.
DHT = {(1.0855, 243.0): 24.5504, (1.1689, 243.0): 52.8886, (1.0855, 100.0): 124.7529, (1.1689, 100.0): 269.2472,
       (6.5133, 243.0): 1866.1834, (7.0133, 243.0): 2035.5355, (6.5133, 100.0): 10959.4289, (7.0133, 100.0): 12161.6177}   # J/kg, CoolProp 8.0.0
try:
    import CoolProp.CoolProp as C
    for (pa, T) in list(DHT):
        DHT[(pa, T)] = C.PropsSI('H','T',T,'P',p_base,'N2') - C.PropsSI('H','T',T,'P',pa*1e5,'N2')
except Exception: pass
JT = {k: md*v for k, v in DHT.items()}
for (pa, T), q in JT.items():
    tag = "booked (head left after 6:1)" if pa < 2 else "envelope, NOT booked (double-counts w_exp)"
    print(f"  p_in {pa:.4f} bar a -> 1.0133 bar a at {T:5.1f} K: dh_T {DHT[(pa,T)]/1e3:6.3f} kJ/kg x {md:.3f} kg/s = {q/1e6:6.3f} MW "
          f"({q/Q_JT:.2%} of 29.07 MW) [{tag}]")
Qjt_b = JT[(1.1689, 243.0)]                  # booked J-T self-cooling share (6 bar g head, published 243 K exhaust)
Qjt_env = JT[(1.1689, 100.0)]                # cold-end envelope of the booked case
Qvap = Q_JT - Qjt_b
print(f"  split (booked): J-T self-cooling {Qjt_b/1e6:.3f} MW ({Qjt_b/Q_JT:.2%}); vapour sensible pickup {Qvap/1e6:.2f} MW ({Qvap/Q_JT:.2%}); "
      f"cold-end envelope of the J-T share {Qjt_env/1e6:.3f} MW ({Qjt_env/Q_JT:.2%})")
# (b) vapour flow and outlet temperature; sources: reset boil-off + vent stream + the generator's own cold-gas draw
m_vent = mmu
print(f"  vapour needed for {Qvap/1e6:.2f} MW: 80 K {Qvap/dh(80):,.1f} kg/s; 100 K {Qvap/dh(100):,.1f} kg/s; 140 K {Qvap/dh(140):,.1f} kg/s")
ULL9 = {}
for N in (1, 2, 3, 4, 10, 69, 100, 1000):
    avail = (N-1)*bo_mod + m_vent
    needcap = Qvap/dh(T_lim); need80 = Qvap/dh(80)
    if avail >= need80:
        Tu, m_u, m_g = 80.0, need80, 0.0
    elif avail >= needcap:
        Tu, m_u, m_g = T_of_dh(Qvap/avail), avail, 0.0
    else:
        Tu, m_u, m_g = T_lim, needcap, needcap - avail
    ULL9[N] = dict(Tu=Tu, m_u=m_u, m_g=m_g, avail=avail)
    print(f"    N {N:5d}: boil-off + vent {avail:,.2f} kg/s; outlet {Tu:6.2f} K; vapour past the exchanger {m_u:,.2f} kg/s; "
          f"generator cold-gas draw {m_g:,.2f} kg/s")
N80_9 = next(N for N in range(1, 500) if (N-1)*bo_mod + m_vent >= Qvap/dh(80))
Ncap_9 = next(N for N in range(1, 500) if (N-1)*bo_mod + m_vent >= Qvap/dh(T_lim))
print(f"    outlet <= 80 K from boil-off + vent alone for N >= {N80_9}; <= {T_lim:.0f} K for N >= {Ncap_9}")
# (c) where the vapour heat goes: sensible heat re-cooled at the generator inlet; the J-T share returns as the
#     enthalpy/pressure defect that the generator's compression restores (D14). Total = 29.07 MW, as booked in r8.
print(f"  (c) generator duty per chain: (N-1) x 29.07 latent + [{Qvap/1e6:.2f} sensible + {Qjt_b/1e6:.3f} J-T defect] = N x 29.07 MW "
      f"-> unchanged from r8 (difference {(Qvap+Qjt_b-Q_JT):.1e} W); no liquid boil-off from the exchanger (D1)")
# (d) final-module floor with the J-T share: the J-T part is rejected inside the stream at its own temperature
#     (>= the exhaust side), the vapour part at the vapour's entropic mean T_m.
FM9 = {}
for Tu in (140.0, 97.58, 80.0):
    Tm = TM[Tu]
    frac = Qvap/Q_JT
    Qm = P*Tm/(Th - Tm)
    FM9[Tu] = (Tm, Qm, frac)
    print(f"  (d) T_u {Tu:6.2f} K: vapour share {frac:.2%} rejected at T_m {Tm:.2f} K -> final-module floor {Qm/1e6:.2f} MW "
          f"(J-T share {1-frac:.2%} changes it by < {(1-frac)*(Qm-main['Qc'])/1e6:.3f} MW)")

# ---- r9 audits ----
if os.path.exists(md_path):
    txt = open(md_path, encoding="utf-8").read()
    c9 = {"jt243": f"{Qjt_b/1e6:.3f}", "jt243 share": f"{Qjt_b/Q_JT:.2%}".replace('%', ' %'),
          "jt55": f"{JT[(1.0855, 243.0)]/1e6:.3f}", "jt100": f"{Qjt_env/1e6:.3f}", "jt100 share": f"{Qjt_env/Q_JT:.2%}".replace('%', ' %'),
          "dhT6": f"{DHT[(1.1689, 243.0)]/1e3:.3f}", "env243": f"{JT[(7.0133, 243.0)]/1e6:.2f}", "env100": f"{JT[(7.0133, 100.0)]/1e6:.2f}",
          "env100 share": f"{JT[(7.0133, 100.0)]/Q_JT:.1%}".replace('%', ' %'), "env55_100": f"{JT[(6.5133, 100.0)]/1e6:.2f}",
          "Qvap": f"{Qvap/1e6:.2f}", "m80": f"{Qvap/dh(80):,.1f}", "m140": f"{Qvap/dh(140):,.1f}",
          "mg1": f"{ULL9[1]['m_g']:,.2f}", "mg2": f"{ULL9[2]['m_g']:,.2f}", "T4": f"{ULL9[4]['Tu']:.2f}", "T10": f"{ULL9[10]['Tu']:.2f}",
          "N80": f"N ≥ {N80_9}", "N140": f"N ≥ {Ncap_9}", "mg3": f"{ULL9[3]['m_g']:,.2f}"}
    bad = [k for k, v in c9.items() if v not in txt]
    print("AUDIT r9:", "PASS - all J-T split and vapour numbers present" if not bad else f"MISSING {[(k, c9[k]) for k in bad]}")
    stale9 = ["q_liq", "liquid surface", "residual leak", "boils 0.181", "36.05 kW", "457.3 W", "radiation and conduction",
              "Radiation and conduction"]
    print("AUDIT r9 stale liquid-path / boil-off strings:", {s: txt.count(s) for s in stale9 if txt.count(s)} or "none")
    # ---- SOURCE CHECK: every design choice traced to a published record or a dated Morgan instruction ----
    t13i = txt.split("\nTable 13i. Source check")[1].split("###")[0] if "\nTable 13i. Source check" in txt else ""
    rows = {}
    for line in t13i.splitlines():
        m = re.match(r"\| (D\d+) \|([^|]*)\|([^|]*)\|([^|]*)\|", line)
        if m: rows[m.group(1)] = [x.strip() for x in m.groups()[1:]]
    Ds = sorted(set(re.findall(r"\*\*(D\d+)\. ", txt)), key=lambda d: int(d[1:]))
    missing = [d for d in Ds if d not in rows]
    unsourced = [d for d, r in rows.items() if not (("Published" in r[0]) or ("Morgan" in r[0])) or "FLAG" in r[2]]
    print(f"AUDIT r9 source check: {len(rows)} of {len(Ds)} design choices traced; missing rows {missing or 'none'}; "
          f"FLAGGED (no published record or dated Morgan instruction): {unsourced or 'none'}")
    for d in Ds:
        if d in rows: print(f"    {d}: {rows[d][0]} | {rows[d][1][:110]}")


# =====================================================================================================
# ==== r10 (Morgan 13:36, "double check everything against my actual designs published"): checks   ====
# ==== against the deposited records. Sources: v7 23291052; [2] 21682741/21033980; [3] 18925333;     ====
# ==== [6] 18665811 (Appendix 1 = A1); [7] 19171590; [8] 20583887; [9] 22150263.                     ====
# =====================================================================================================
print("\n=================== r10 PUBLISHED-RECORD CHECKS ===================")
# (1) ullage outlet cap: Input C of the generator is cold N2 at 80-140 K [9, 4.1 and Fig. 2]; r9's 160 K was the
#     Mode V Side-B intercept (8-12 bar, 140-180 K [9, Table 3]), downstream of the precooler, not the cold inlet.
print(f"(1) Input C cap {T_lim:.0f} K: vapour needed {Qvap/dh(T_lim):,.1f} kg/s; boil-off + vent alone hold <= {T_lim:.0f} K for N >= {Ncap_9}; "
      f"generator draw N=1 {ULL9[1]['m_g']:,.2f}, N=2 {ULL9[2]['m_g']:,.2f}, N=3 {ULL9[3]['m_g']:,.2f} kg/s; outlet N=4 {ULL9[4]['Tu']:.2f} K")
FMc = FM[140.0]
print(f"    final-module review at T_u 140 K: T_m {FMc[0]:.2f} K, floor {FMc[1]/1e6:.2f} MW, module heat {FMc[2]/1e6:+.2f} MW vs 77.35 K booking")
# (2) regeneration: v7 Table 2 eta_reg 0.996 (also [7] 6.3.2 "99.6 % overall regeneration", A1 #1/#14 90-99.6 %);
#     [8] item 6 prints a "96 % closed" loop. Sensitivity only; v8 keeps 0.996 (v7; Morgan 12:21, leak 0.4 %).
m96 = 0.04*md; P96 = m96*3600*0.55*1000
net96 = P - P96 - E_aux
print(f"(2) at [8]'s 96 % closure: leak {m96:.2f} kg/s, makeup {P96/1e6:.2f} MW (0.55 kWh/kg), net before AI {net96/1e6:.2f} MW "
      f"(vs {(P-P_liq_v7-E_aux)/1e6:.2f} MW at 0.996)")
# (3) published tank temperature: "YBCO bearings anchored to 90 K LN2 tank" ([3] V10 4; Safe Operating Temperatures 1).
Ts90, hv90, sv90 = 90.0, 84969.8855, 5152.7253
p90 = 360458.04
try:
    hv90 = C.PropsSI('H','T',Ts90,'Q',1,'N2'); sv90 = C.PropsSI('S','T',Ts90,'Q',1,'N2'); p90 = C.PropsSI('P','T',Ts90,'Q',1,'N2')
except Exception: pass
Wf90 = P*(Ta - Ts90)/(Th - Ts90); Q90 = P*Ts90/(Th - Ts90)
tot_f90 = P + Q90 + Wf90/eII_ref_hi/(eII_eng*eta_h)
dB90 = tot_f90 - base['tot_f']
print(f"(3) published 90 K tank (case B at T_c 90 K, p_sat {p90/1e5:.2f} bar a): floor {Q90/1e6:.2f} MW, module heat {dB90/1e6:+.2f} MW "
      f"({dB90/Lt['Qt']:.2%}); not booked (P is set on the 77.35 K basis in v7)")
# (4) published per-stage pressure ratio PR 1.3 ([3] Safe Operating Temperatures 1) vs the 6:1 reading of w_exp:
DHT13 = {(5.3948, 243.0): 1487.1661, (5.3948, 100.0): 8430.3298}
try:
    for (pa, T) in list(DHT13):
        DHT13[(pa, T)] = C.PropsSI('H','T',T,'P',p_base,'N2') - C.PropsSI('H','T',T,'P',pa*1e5,'N2')
except Exception: pass
w13 = R_N2*Th*log(1.3)
print(f"(4) PR 1.3 per stage: isothermal work at T_h {w13/1e3:.1f} kJ/kg (vs w_exp 242.5); head left 7.013/1.3 = 5.395 bar a; "
      f"J-T share at 243 K {md*DHT13[(5.3948,243.0)]/1e6:.2f} MW ({md*DHT13[(5.3948,243.0)]/Q_JT:.1%}), at 100 K {md*DHT13[(5.3948,100.0)]/1e6:.2f} MW "
      f"({md*DHT13[(5.3948,100.0)]/Q_JT:.1%}); generator duty N x 29.07 MW unchanged either way")
# (5) AI: one instance per 100-module chain/cluster
for N in (100, 1000):
    f6 = FLEET6[(N, 0.996)]
    print(f"(5) N {N}: AI instances {f6['nAI']} -> {f6['nAI']*AI_lo/1e6:,.2f}-{f6['nAI']*AI_hi/1e6:,.2f} MW; net {f6['net_lo']/1e6:,.2f}-{f6['net_hi']/1e6:,.2f} MW; "
          f"gross/all electricity {f6['Rall']:.1f}")
f6b = FLEET6[(1000, 0.999)]
print(f"    N 1000 eta 0.999: net {f6b['net_lo']/1e6:,.2f}-{f6b['net_hi']/1e6:,.2f} MW; gross/all electricity {f6b['Rall']:.1f}")

# ---- r10 audits ----
if os.path.exists(md_path):
    txt = open(md_path, encoding="utf-8").read()
    c10 = {"m140": f"{Qvap/dh(140):,.1f}", "N140": f"N ≥ {Ncap_9}", "mg1": f"{ULL9[1]['m_g']:,.2f}", "mg2": f"{ULL9[2]['m_g']:,.2f}",
           "mg3": f"{ULL9[3]['m_g']:,.2f}", "Tm140": f"{FMc[0]:.1f}", "Qm140": f"{FMc[1]/1e6:.2f}", "dH140": f"{-FMc[2]/1e6:.2f}",
           "m96": f"{m96:.2f}", "P96": f"{P96/1e6:.2f}", "net96": f"{net96/1e6:.2f}", "Q90": f"{Q90/1e6:.2f}", "dB90": f"{-dB90/1e6:.2f}",
           "p90": f"{p90/1e5:.2f}", "w13": f"{w13/1e3:.1f}", "jt13": f"{md*DHT13[(5.3948,243.0)]/1e6:.2f}",
           "N1000 net lo": f"{FLEET6[(1000, 0.996)]['net_lo']/1e6:,.2f}", "N1000 net hi": f"{FLEET6[(1000, 0.996)]['net_hi']/1e6:,.2f}",
           "N1000 Rall": f"{FLEET6[(1000, 0.996)]['Rall']:.1f}", "N1000b net lo": f"{f6b['net_lo']/1e6:,.2f}", "N1000b Rall": f"{f6b['Rall']:.1f}"}
    bad = [k for k, v in c10.items() if v not in txt]
    print("AUDIT r10:", "PASS - all r10 published-check numbers present" if not bad else f"MISSING {[(k, c10[k]) for k in bad]}")
    # citation hygiene: v4 role numbers are [A #n]; published Appendix 1 numbers are A1 #n [6]
    misnum = {t: txt.count(t) for t in ("A #6,", "A #6]", "A #15", "A #25", "A #32", "item 1 summary", "published 8; A #15",
                                         "published [8]; derived check", "≤ 160 K", "160.00 K", "Mode V [9]", "cold-vapour inlet") if txt.count(t)}
    print("AUDIT r10 stale or mis-numbered citations:", misnum or "none")
    for must in ("Input C", "96 %", "A1 #", "90 K", "PR = 1.3", "space only"):
        print(f"AUDIT r10 phrase '{must}':", txt.count(must))


# ---- r11: Morgan 14:41 decisions; pump verification ----
print("\n--- r11: is the MHD self-pump work inside P? ---")
g0 = 9.80665
W_ideal = md*w_pump_loop                         # W, minimum hydraulic work to lift the loop by dP_loop
col = dP_loop/(rho_L*g0)                         # m of LN2 column giving dP_loop by gravity
try:
    import CoolProp.CoolProp as _CP
    Tsat6 = _CP.PropsSI("T", "P", 101325 + dP_loop, "Q", 0, "Nitrogen")
except Exception:
    Tsat6 = 98.52
P_strip_stator = 1.0                             # W, stators in the Book 1 strip [8]
P_mwh = 0.8e3                                    # W, "0.8 kW ... HTS magnets and the initial pump head" [7, Master Derivatives]
print(f"  P = md * w_exp = {md:.3f} kg/s x {w_exp/1e3:.1f} kJ/kg = {md*w_exp/1e6:.2f} MW (v7 Eq. 6): gross expansion work, net only of the {E_strip} W strip")
print(f"  minimum loop pump work md*v*dP at {dP_loop/1e5:.0f} bar = {W_ideal/1e6:.4f} MW; shaft at eta_B {etaB:.2f} = {E_loop/1e6:.4f} MW")
print(f"  published stator line {P_strip_stator:.1f} W covers 1/{W_ideal/P_strip_stator:,.0f} of it; the 0.8 kW pump-head line covers 1/{W_ideal/P_mwh:,.0f}")
print(f"  a {dP_loop/1e5:.0f} bar liquid head by gravity needs a {col:.1f} m LN2 column; by tank pressure it needs a tank at {Tsat6:.2f} K ({(101325+dP_loop)/1e5:.3f} bar), not 77.35 K")
net_r11 = P - P_liq_v7 - E_aux
print(f"  verdict: pump work NOT inside P -> pump stays booked; net before AI {net_r11/1e6:.2f} MW; zero-pump published accounting {(P-P_liq_v7-E_ctrl-E_strip)/1e6:.2f} MW (not adopted)")
eta_C77 = 1 - 77.35/453.15; eta_C90 = 1 - 90.0/453.15
print(f"  Carnot spread 453.15 K feed: {eta_C77:.4f} at 77.35 K vs {eta_C90:.4f} at 90 K")
eta_elec_share = E_aux/P
print(f"  hybrid electricity share (pumps + controls + strip) = {E_aux/1e6:.4f} MW = {eta_elec_share:.3%} of P (unchanged from r10)")

if os.path.exists(md_path):
    txt = open(md_path, encoding="utf-8").read()
    c11 = {"Wideal": f"{W_ideal/1e6:.3f} MW", "col": f"{col:.1f} m", "Tsat6": f"{Tsat6:.1f} K", "net": f"{net_r11/1e6:.2f} MW",
           "zero": f"{(P-P_liq_v7-E_ctrl-E_strip)/1e6:.2f} MW", "C77": f"{eta_C77:.1%}", "C90": f"{eta_C90:.1%}",
           "ratio": f"{W_ideal/P_mwh:,.0f}"}
    bad = [k for k, v in c11.items() if v not in txt]
    print("AUDIT r11:", "PASS - all r11 decision and pump-check numbers present" if not bad else f"MISSING {[(k, c11[k]) for k in bad]}")
    for must in ("design basis", "sensitivity only", "not inside P", "without additional pumping", "re-condenser medium", "no contradiction", "not booked"):
        print(f"AUDIT r11 phrase '{must}':", txt.count(must))
    stale11 = {t: txt.count(t) for t in ("v8 follows those. The loop pump", "Five published items do not match") if txt.count(t)}
    print("AUDIT r11 stale r10 strings:", stale11 or "none")


# ---- r11b: resolved ambiguities (Morgan 14:45) ----
print("\n--- r11b: resolved ambiguities ---")
Hl = mmu*w_exp
QtD = LIFT['design']['Qt'] + Hl; QtS = LIFT['sizing']['Qt'] + Hl
print(f"  leak term {Hl/1e6:.3f} MW; heat incl. leak term: design {QtD/1e6:,.2f} MW ({QtD/P:.2f} P), sizing {QtS/1e6:,.2f} MW ({QtS/P:.2f} P)")
w_needed_038 = P/0.038; w_92 = 92e3/0.038; w_235 = 235e3/0.038
print(f"  0.038 kg/s would need {w_needed_038/1e6:,.0f} MJ/kg for 141.22 MW; {w_92/1e6:.2f} MJ/kg for 92 kW; {w_235/1e6:.2f} MJ/kg for 235 kW; "
      f"N2 can take at most {q_avail/1e3:.1f} kJ/kg between 77.35 K liquid and 453.15 K gas")
P_r100 = P*(100/93)**3
print(f"  P at the published 0.1 m rotor radius (P ~ r^3 delta): {P_r100/1e6:.2f} MW (x{(100/93)**3:.3f}); v7 keeps r = 93 mm, delta = 2 mm")
print(f"  [5] channel d = 50 mm vs delta = 2 mm: ratio {50/2:.0f}")
if os.path.exists(md_path):
    txt = open(md_path, encoding="utf-8").read()
    c11b = {"QtD": f"{QtD/1e6:,.2f} MW", "QtS": f"{QtS/1e6:,.2f} MW", "w038": f"{w_needed_038/1e6:,.0f} MJ/kg", "w92": f"{w_92/1e6:.2f} MJ/kg",
            "qav": f"{q_avail/1e3:.1f} kJ/kg", "Pr100": f"{P_r100/1e6:.2f} MW"}
    bad = [k for k, v in c11b.items() if v not in txt]
    print("AUDIT r11b:", "PASS - all resolved-ambiguity numbers present" if not bad else f"MISSING {[(k, c11b[k]) for k in bad]}")
    sec = txt[txt.find("### Resolved ambiguities in the published record"):txt.find("### 6.6.1 ")]
    nR = len(re.findall(r"^\*\*R\d+\.", sec, re.M))
    print("AUDIT r11b resolved-ambiguity items:", nR, "| each with Records / Resolution / Status:",
          sec.count("*Records.*") == nR and sec.count("*Resolution.*") == nR and sec.count("*Status.*") == nR,
          "| 'What v8 supersedes' present:", "What v8 supersedes" in sec)
    labels = re.findall(r"\((6\.6[a-z])\)\s*$", txt, re.M)
    print("AUDIT r11b equation labels in order:", labels == sorted(labels), labels)
    print("AUDIT r11b overclaim words:", {w: txt.count(w) for w in ("proven", "proved", "experimentally confirmed", "demonstrated") if txt.count(w)} or "none")


# ---- r12: one coupled system (Morgan 14:52, 14:53) ----
print("\n--- r12: coupled system, baseline itemisation and whole-system balance ---")
# published baseline itemisation [7] Master Derivatives sec. 4
P_ind_b, P_mhd_b = 82e3, 21.3e3; P_out_b = P_ind_b + P_mhd_b; P_net_b = 92e3
print(f"  baseline Pout = Pind(stator) {P_ind_b/1e3:.1f} + Pmhd {P_mhd_b/1e3:.1f} = {P_out_b/1e3:.1f} kW; net {P_net_b/1e3:.0f} kW; "
      f"gap {(P_out_b-P_net_b)/1e3:.1f} kW ({(P_out_b-P_net_b)/P_out_b:.1%}); shares {P_ind_b/P_out_b:.1%} / {P_mhd_b/P_out_b:.1%}")
# V6 composite multiplier, one product
shear = (200/120)**2; M = shear*4.0*1.15*4.0*1.5*(200/10)
print(f"  V6 M = {shear:.4f} x 4.0 x 1.15 x 4.0 x 1.5 x 20 = {M:,.1f}; 92 kW x M = {P_net_b*M/1e6:.2f} MW; P / 92 kW = {P/P_net_b:,.1f}")
print(f"  ring route 120k->200k at sigma 70 -> 14,000: x{200*shear:.1f} (sigma x omega^2); double count if M were applied on Eq. 4: {P*M/1e9:,.1f} GW (not used)")
# flow ceilings
Rn2 = 296.8
w_iso_max = Rn2*453.15*log((101325+6e5)/0.1e5)
ceil = q_avail + w_iso_max
print(f"  isothermal 7.013 -> 0.1 bar at 453.15 K: {w_iso_max/1e3:.1f} kJ/kg; generous one-pass heat ceiling {ceil/1e3:,.1f} kJ/kg")
for lab, mf in (("0.038 kg/s", 0.038), ("1000 kg/h", 1000/3600)):
    print(f"   {lab}: carries <= {mf*q_avail/1e3:.1f} kW at 593.1 kJ/kg, <= {mf*ceil/1e3:.1f} kW at the generous ceiling; "
          f"needs {P_out_b/mf/1e3:,.1f} kJ/kg for 103.3 kW, {P_net_b/mf/1e3:,.1f} kJ/kg for 92 kW")
print(f"  min flow for 103.3 kW: {P_out_b/q_avail:.3f} kg/s at 593.1 kJ/kg; {P_out_b/415e3:.3f}-{P_out_b/300e3:.3f} kg/s at A1 #25 300-415 kJ/kg; "
      f"{P_out_b/w_exp:.3f} kg/s at w_exp 242.5")
print(f"  stator drag: shaft power >= {P_ind_b/1e3:.0f} kW -> drive flow >= {P_ind_b/q_avail:.3f} kg/s at 593.1 kJ/kg")
# ionisation loop at design [8] sec. 11.1
N_nuc, E_nuc = 5.92e21, 2.384e-16
P_ion = N_nuc*E_nuc
print(f"  ionisation/recombination loop [8] 11.1: {P_ion/1e6:.2f} MW ({P_ion/P:.2%} of P), internal, net 0")
# whole-system balance at the worked point (design machines)
Qheat = LIFT['design']['Qt']; Hl = mmu*w_exp; Eel = E_aux
amb = Qheat - P
IN = Qheat + Hl + Eel; OUT = P + amb + Hl + Eel
print(f"  IN: heat {Qheat/1e6:,.2f} + leak term {Hl/1e6:.3f} + electricity {Eel/1e6:.3f} = {IN/1e6:,.2f} MW")
print(f"  OUT: P {P/1e6:.2f} + ambient {amb/1e6:,.2f} + vent {Hl/1e6:.3f} + electricity as heat {Eel/1e6:.3f} = {OUT/1e6:,.2f} MW; residual {IN-OUT:.3e} W")
split_ind = P*P_ind_b/P_out_b
print(f"  illustrative split of P at the baseline shares: stators {split_ind/1e6:.2f} MW, MHD channel {(P-split_ind)/1e6:.2f} MW (inside P, not added)")
if os.path.exists(md_path):
    txt = open(md_path, encoding="utf-8").read()
    c12 = {"M": f"{M:,.1f}", "92M": f"{P_net_b*M/1e6:.2f} MW", "PM": f"{P/P_net_b:,.1f}", "ring": f"{200*shear:.1f}",
           "dbl": f"{P*M/1e9:,.1f} GW", "iso": f"{w_iso_max/1e3:.1f} kJ/kg", "ceil": f"{ceil/1e3:,.1f} kJ/kg",
           "c038a": f"{0.038*q_avail/1e3:.1f} kW", "c038b": f"{0.038*ceil/1e3:.1f} kW", "w1000": f"{P_out_b/(1000/3600)/1e3:,.1f} kJ/kg",
           "w1000n": f"{P_net_b/(1000/3600)/1e3:,.1f} kJ/kg", "w038": f"{P_out_b/0.038/1e3:,.1f} kJ/kg", "mmin": f"{P_out_b/q_avail:.3f} kg/s",
           "drag": f"{P_ind_b/q_avail:.3f} kg/s", "ion": f"{P_ion/1e6:.2f} MW", "IN": f"{IN/1e6:,.2f} MW", "amb": f"{amb/1e6:,.2f} MW",
           "gap": f"{(P_out_b-P_net_b)/1e3:.1f} kW", "spl": f"{split_ind/1e6:.2f} MW"}
    bad = [k for k, v in c12.items() if v not in txt]
    print("AUDIT r12:", "PASS - all coupled-system numbers present" if not bad else f"MISSING {[(k, c12[k]) for k in bad]}")
    for must in ("written once", "not Faraday ×4", "Stored, not created", "drag equals delivered power", "derived from harvested environmental waste heat",
                 "Pout = Pind(Stator) + Pmhd = 103.3 kW", "headline is unchanged"):
        print(f"AUDIT r12 quote/phrase '{must}':", txt.count(must))
    print("AUDIT r12 overclaim words:", {w: txt.count(w) for w in ("proven", "proved", "experimentally confirmed", "demonstrated") if txt.count(w)} or "none")


# ---- r13: flow is the variable (Morgan 15:04/15:05); every line scaled; passive ionisation + Marx (15:08);
#      per-module cost sheet (15:09); YBCO bearings (15:10) ----
from math import log as _ln
print("\n--- r13: one coupled flow law through the published anchors ---")
# anchors: [5] 20135631 baseline 1000 kg/h, 120,000 rpm, sigma 80 S/m, Pout 103.3 kW ([7] Master Derivatives);
#          v7 worked point 582.336 kg/s, 200,000 rpm, sigma 14,000 S/m, 141.22 MW
mA, rpmA, sigA, PA = 1000/3600, 120000.0, 80.0, 103.3e3
mB, rpmB, sigB, PB = md, float(rpm), sig, P
LN = _ln(mB/mA)
b_rpm = _ln(rpmB/rpmA)/LN
b_sig = _ln(sigB/sigA)/LN
b_P = _ln(PB/PA)/LN
b_w = b_P - 1
print(f"  exponents vs m_dot: rpm {b_rpm:.4f}, sigma {b_sig:.4f}, P {b_P:.4f}, w = P/m {b_w:.4f}; pressure 0 (6 bar at both anchors [3; A #33])")
def rpm_of(m): return rpmB*(m/mB)**b_rpm
def sig_of(m): return sigB*(m/mB)**b_sig
def P_of(m):   return PB*(m/mB)**b_P
E_marx, E_stat = 1.0, 1.0                          # W: V6 sec. 8 "Marx generator: 1.0 W (fixed)"; "4x stator circuit losses: 1.0 W (bounded)"
def E_bear(m): return 5.8*(rpm_of(m)/120000.0)     # W, YBCO bearing drag, linear law (v4 E3), 9.67 W at 200k (published 9.7 W)
SEC_kg = 0.55*3600e3
lift_per_W = (Ta/Tc - 1)/(f_des*(1 - Ta/Th))        # W of 180 C heat per W lifted from 77.35 K, design machines
def closed(m):
    Pm = P_of(m); wm = Pm/m
    Qr = Pm*Tc/(Th - Tc)
    L = {"rpm": rpm_of(m), "sig": sig_of(m), "w": wm, "P": Pm}
    L["mmu"] = (1 - eta_reg)*m
    L["Pliq"] = (1 - eta_reg)*m*SEC_kg
    L["leak"] = (1 - eta_reg)*m*wm
    L["vent_lo"] = (1 - eta_reg)*m*(h_vent[293.15] - h_liq)
    L["vent_hi"] = (1 - eta_reg)*m*(h_vent[453.15] - h_liq)
    L["Qr"] = Qr; L["bo"] = Qr/hfg_77; L["gen"] = Qr
    L["Qlift"] = Qr*lift_per_W
    L["Qheat"] = Pm + Qr + L["Qlift"]
    L["pump"] = m*dP_loop/(rho_L*etaB)
    L["ret"] = (Qr/hfg_77)*dP_loop/(rho_L*etaB)
    L["ctrl"] = E_ctrl; L["marx"] = E_marx; L["stat"] = E_stat; L["bear"] = E_bear(m)
    L["cryo"] = (L["bear"] + E_stat)*lift_per_W     # YBCO bearing + stator loss at 77.35 K, lifted (heat)
    L["AIlo"], L["AIhi"] = 0.02*Pm, 0.10*Pm
    L["ion"] = Pm*(N_nuc*E_nuc/P)                  # internal ionisation/recombination loop (V6 rate ~ alpha P / E_ion); net 0
    L["eaux"] = L["pump"] + L["ctrl"] + L["marx"] + L["stat"] + L["bear"]
    L["net0"] = Pm - L["Pliq"] - L["eaux"]
    L["netlo"] = L["net0"] - L["AIhi"]; L["nethi"] = L["net0"] - L["AIlo"]
    L["R2"] = Pm/L["Pliq"]
    L["Rall"] = Pm/(L["Pliq"] + L["eaux"] + L["AIlo"])
    L["heatratio"] = L["Qheat"]/Pm
    return L
EXP = {"rpm": b_rpm, "sig": b_sig, "w": b_w, "P": b_P, "mmu": 1, "Pliq": 1, "leak": b_P, "vent_lo": 1, "vent_hi": 1,
       "Qr": b_P, "bo": b_P, "gen": b_P, "Qlift": b_P, "Qheat": b_P, "pump": 1, "ret": b_P, "ctrl": 0, "marx": 0, "stat": 0,
       "bear": b_rpm, "AIlo": b_P, "AIhi": b_P, "ion": b_P}
L0 = closed(md)
print(f"  anchor check: P(582.336) = {L0['P']/1e6:.2f} MW; P(1000 kg/h) = {closed(mA)['P']/1e3:.2f} kW; "
      f"bearing at 120k {E_bear(mA):.2f} W, at 200k {L0['bear']:.2f} W")
def by_exponent(m):
    s_ = m/md
    return {k: L0[k]*s_**e for k, e in EXP.items()}
PTS = [("0.038 kg/s (Giga Factory lock [3])", 0.038), ("1000 kg/h (four-stator baseline [5])", 1000/3600),
       ("1 % of worked flow", 0.01*md), ("10 %", 0.10*md), ("50 %", 0.50*md), ("worked point", md)]
TAB13 = []; worst = 0.0
for lab, m in PTS:
    Lc = closed(m); Le = by_exponent(m)
    for k in EXP:
        worst = max(worst, abs(Lc[k] - Le[k])/max(abs(Lc[k]), 1e-30))
    TAB13.append((lab, m, Lc))
    print(f"  {lab:38s} m {m:10.4f} | rpm {Lc['rpm']:9,.0f} | sigma {Lc['sig']:8,.1f} | w {Lc['w']/1e3:6.1f} kJ/kg | P {Lc['P']/1e3:13,.2f} kW | "
          f"liq {Lc['Pliq']/1e3:11,.3f} | pump {Lc['pump']/1e3:9,.3f} | bear {Lc['bear']:.2f} W | net {Lc['net0']/1e3:13,.2f} kW | "
          f"R2 {Lc['R2']:.1f} | gross/all {Lc['Rall']:.2f}")
print(f"  AUDIT r13 closed-form vs exponent-law recomputation, worst relative difference over {len(PTS)} points x {len(EXP)} lines: {worst:.2e}")
leak582 = [(lab, k) for lab, m, Lc in TAB13 if m != md for k, e in EXP.items() if e and abs(Lc[k] - L0[k]) < 1e-6*abs(L0[k])]
print("  AUDIT r13 lines left at the 582 kg/s value at other points:", leak582 or "none")
netcheck = max(abs(Lc['net0'] - (Lc['P'] - Lc['Pliq'] - Lc['pump'] - Lc['ctrl'] - Lc['marx'] - Lc['stat'] - Lc['bear'])) for _, _, Lc in TAB13)
print(f"  AUDIT r13 net recomputed from the scaled lines, worst residual: {netcheck:.2e} W")
w038 = closed(0.038)
print(f"  0.038 kg/s on the law: {w038['P']/1e3:.2f} kW (published 92 kW there would need {92e3/0.038/1e3:,.1f} kJ/kg; ceiling {0.038*q_avail/1e3:.1f} kW)")
marx_code = 2.5e3*(md*3600/100)**0.75*0.35*(1 - 0.65)
print(f"  Marx booked 1.0 W fixed; code law 2.5 kW (m/100 kg/h)^0.75 x 0.35 x 0.35 at the worked flow = {marx_code/1e6:.3f} MW (not adopted)")
# YBCO
Tc_YBCO = 92.0
tau_b = L0['bear']/(2*pi*rpm/60)
P_hyst_max = 1e-4*(2*pi*rpm/60)
print(f"  YBCO: margin {Tc_YBCO - Tc:.2f} K at 77.35 K, {Tc_YBCO - 90:.2f} K at a 90 K tank; drag torque {tau_b:.3e} N m at 200k; "
      f"hysteresis bound (<1e-4 N m, 20031552) {P_hyst_max:.2f} W; remainder eddy + aero {L0['bear']-P_hyst_max:.2f} W; "
      f"cryo lift {lift_per_W:.2f} W heat per W -> {L0['cryo']/1e3:.3f} kW heat; drag share of P {L0['bear']/P:.2e}")
# ---- per-module cost sheet and fleet totals ----
def fleet(N, m=md):
    Lc = closed(m); nAI = -(-N//100)
    el_mod = N*(Lc['pump'] + Lc['ctrl'] + Lc['marx'] + Lc['stat'] + Lc['bear']) + (N - 1)*Lc['ret']
    el_sh = Lc['Pliq']
    el_lo = el_mod + el_sh + nAI*Lc['AIlo']; el_hi = el_mod + el_sh + nAI*Lc['AIhi']
    heat = N*(Lc['Qheat'] + Lc['cryo']) + Lc['leak']
    gross = N*Lc['P']
    return dict(el_mod=el_mod, el_sh=el_sh, el_lo=el_lo, el_hi=el_hi, heat=heat, gross=gross, net_lo=gross - el_hi, net_hi=gross - el_lo,
                gen=N*Lc['gen'], lift=N*Lc['Qlift'], vent_lo=Lc['vent_lo'], vent_hi=Lc['vent_hi'], nAI=nAI)
FL13 = {N: fleet(N) for N in (1, 10, 100)}
for N, F in FL13.items():
    print(f"  fleet N {N:3d}: electricity per-module {F['el_mod']/1e6:,.3f} + shared makeup {F['el_sh']/1e6:.3f} + AI x{F['nAI']} -> "
          f"{F['el_lo']/1e6:,.3f}-{F['el_hi']/1e6:,.3f} MW_e | waste heat {F['heat']/1e6:,.2f} MW_th | gross {F['gross']/1e6:,.2f} | "
          f"net {F['net_lo']/1e6:,.2f}-{F['net_hi']/1e6:,.2f} MW")
# cross-check against the r6/r10 fleet booking (bearing 9.67 W linear vs 9.7 W published differs by 0.03 W per module)
for N in (1, 10, 100):
    d_ = abs(FL13[N]['net_hi'] - FLEET6[(N, 0.996)]['net_hi'])
    print(f"  AUDIT r13 fleet N {N} net vs Table 13b: difference {d_:.3f} W")
if os.path.exists(md_path):
    txt = open(md_path, encoding="utf-8").read()
    need = {}
    for lab, m, Lc in TAB13:
        need[f"{lab} rpm"] = f"{Lc['rpm']:,.0f}"; need[f"{lab} sig"] = f"{Lc['sig']:,.1f}"; need[f"{lab} w"] = f"{Lc['w']/1e3:,.1f}"
        need[f"{lab} P"] = f"{Lc['P']/1e3:,.2f}"; need[f"{lab} liq"] = f"{Lc['Pliq']/1e3:,.3f}"; need[f"{lab} pump"] = f"{Lc['pump']/1e3:,.3f}"
        need[f"{lab} bear"] = f"{Lc['bear']:.2f}"; need[f"{lab} Qr"] = f"{Lc['Qr']/1e3:,.2f}"; need[f"{lab} lift"] = f"{Lc['Qlift']/1e3:,.2f}"
        need[f"{lab} AI"] = f"{Lc['AIlo']/1e3:,.2f}–{Lc['AIhi']/1e3:,.2f}"; need[f"{lab} ion"] = f"{Lc['ion']/1e3:,.2f}"
        need[f"{lab} net"] = f"{Lc['net0']/1e3:,.2f}"; need[f"{lab} R2"] = f"{Lc['R2']:.1f}"; need[f"{lab} Rall"] = f"{Lc['Rall']:.2f}"
    for k, v in (("b_rpm", f"{b_rpm:.4f}"), ("b_sig", f"{b_sig:.4f}"), ("b_P", f"{b_P:.4f}"), ("b_w", f"{b_w:.4f}"),
                 ("marx", f"{marx_code/1e6:.3f} MW"), ("tau", f"{tau_b:.2e}"), ("hyst", f"{P_hyst_max:.2f} W"), ("cryo", f"{L0['cryo']/1e3:.3f} kW"),
                 ("lpw", f"{lift_per_W:.2f}"), ("p038", f"{w038['P']/1e3:.2f} kW")):
        need[k] = v
    for N, F in FL13.items():
        need[f"F{N} el"] = f"{F['el_lo']/1e6:,.3f}–{F['el_hi']/1e6:,.3f}"; need[f"F{N} heat"] = f"{F['heat']/1e6:,.2f}"
        need[f"F{N} net"] = f"{F['net_lo']/1e6:,.2f}–{F['net_hi']/1e6:,.2f}"; need[f"F{N} elmod"] = f"{F['el_mod']/1e6:,.3f}"
    bad = [k for k, v in need.items() if v not in txt]
    print("AUDIT r13:", f"PASS - all {len(need)} scaled-line and cost-sheet values present" if not bad else f"MISSING {[(k, need[k]) for k in bad]}")
    for must in ("Per-module system cost sheet", "passive", "1.0 W (fixed)", "low-duty-cycle", "not a parasitic", "YBCO", "Tc ≈ 92 K", "flow is the variable"):
        print(f"AUDIT r13 phrase '{must}':", txt.count(must))


# =====================================================================================================
# ==== r14 (Morgan's review, 28 Oct 2026 23:18, and 23:19 on point 5): no new physics; wording,   ====
# ==== consistency and labelling. Every number quoted for the r14 changes is printed here.         ====
# =====================================================================================================
from math import log10 as _log10
print("\n--- r14: review points (Morgan 23:18 / 23:19) ---")
# (3) the 140 K Input C cap at N <= 3: the generator's cold-gas draw, made prominent for the single-module column
U1 = ULL9[1]
print(f"  (3) N = 1: generator cold-gas draw {U1['m_g']:,.2f} kg/s; vapour past the exchanger {U1['m_u']:,.2f} kg/s; outlet {U1['Tu']:.2f} K; "
      f"draw / module flow {U1['m_g']/md:.1%}; N = 2 {ULL9[2]['m_g']:,.2f}, N = 3 {ULL9[3]['m_g']:,.2f} kg/s")
# upper bound on the flow work across the exchanger's < 0.05 bar drop (V dp at the warm outlet; inside the generator duty, D14)
rho_N2 = {140.0: 2.456300, 80.0: 4.439861}        # kg/m3 at 1.01325 bar (Span et al. EoS via CoolProp 8.0.0, hard-coded)
try:
    import CoolProp.CoolProp as _C
    rho_N2 = {T: _C.PropsSI('D', 'T', T, 'P', 101325, 'N2') for T in rho_N2}
except Exception:
    pass
dp_hx = 0.05e5
W_dp1 = U1['m_u']/rho_N2[140.0]*dp_hx
W_dp69 = ULL9[69]['m_u']/rho_N2[80.0]*dp_hx
print(f"  (3) flow work bound V*dp at < 0.05 bar: N = 1 {W_dp1/1e6:.2f} MW ({W_dp1/P:.2%} of P; {U1['m_u']/rho_N2[140.0]:,.1f} m3/s at 140 K); "
      f"N >= 69 {W_dp69/1e6:.2f} MW per fleet ({ULL9[69]['m_u']/rho_N2[80.0]:,.1f} m3/s at 80 K; {W_dp69/(69*P):.3%} of the N = 69 gross)")
print(f"  (3) N = 1 final-module review at 140 K: T_m {FM9[140.0][0]:.2f} K, floor {FM9[140.0][1]/1e6:.2f} MW vs booked {main['Qc']/1e6:.2f} MW")
# (4) case B / final module: the ring equation has no T_c term; the floor does
for Tx in (77.35, FM9[80.0][0], Tsat6, FM9[140.0][0]):
    print(f"  (4) floor P*T/(Th-T) at {Tx:.2f} K = {P*Tx/(Th-Tx)/1e6:.2f} MW; ring Carnot 1 - T/Th = {1-Tx/Th:.1%}")
# (5) AI line: electricity booked in full; heat returned labelled as recoverable low-grade heat, never added to net
AI_lo, AI_hi = L0['AIlo'], L0['AIhi']
f_ret = 0.95                                     # A1 #32: "~95 %+ converted to recoverable waste heat"
T_ai = (313.15, 333.15, 353.15)                  # assumption: 40-80 C server-exhaust band [3]; 60 C central, as v7 10.2 assumes
print(f"  (5) AI electricity {AI_lo/1e6:.2f}-{AI_hi/1e6:.2f} MW per chain, booked in full in the net; "
      f"recoverable low-grade heat {f_ret*AI_lo/1e6:.2f}-{f_ret*AI_hi/1e6:.2f} MW; uncaptured {(1-f_ret)*AI_lo/1e6:.2f}-{(1-f_ret)*AI_hi/1e6:.2f} MW")
for Tq in T_ai:
    print(f"      at {Tq:.2f} K ({Tq-273.15:.0f} C): Carnot vs 300 K {1-Ta/Tq:.2%}; min work per MW delivered into the 453.15 K feed {1-Tq/Th:.4f} MW "
          f"(ideal heat-pump heating COP {Th/(Th-Tq):.3f})")
AIREC = {}
for N in (1, 10, 100, 1000):
    nAI = -(-N//100)
    AIREC[N] = (nAI*f_ret*AI_lo, nAI*f_ret*AI_hi)
    print(f"      fleet N {N:4d}: AI instances {nAI}; useful heat available (AI, 40-80 C) {AIREC[N][0]/1e6:,.2f}-{AIREC[N][1]/1e6:,.2f} MW (not added to net)")
# other heat streams: temperatures and whether reuse is possible on the stated basis
Qamb = L0['Qheat'] - P
print(f"  (5) heat to ambient from the lift and engine, design, one module: {Qamb/1e6:,.2f} MW at T_a = {Ta:.2f} K (exergy vs ambient 0); "
      f"N = 100: {100*Qamb/1e6:,.2f} MW")
print(f"  (5) cold-side streams (not usable heat): reset heat {main['Qc']/1e6:.2f} MW at 77.35 K; vapour pickup {Qvap/1e6:.2f} MW at 77.35-140 K; "
      f"cryo {L0['cryo']/1e3:.3f} kW lifted inside the ambient line; vent {L0['vent_lo']/1e6:.2f}-{L0['vent_hi']/1e6:.2f} MW")
# (6) vent heat sits inside the 29.07 MW floor
print(f"  (6) vent heat {vent_u/1e6:.2f}-{L0['vent_hi']/1e6:.2f} MW = {vent_u/main['Qc']:.1%}-{L0['vent_hi']/main['Qc']:.1%} of the {main['Qc']/1e6:.2f} MW floor; "
      f"waste heat one module = ring + lift + cryo + leak = {(L0['P']+L0['Qr'])/1e6:.2f} + {L0['Qlift']/1e6:,.2f} + {L0['cryo']/1e6:.6f} + {L0['leak']/1e6:.3f} = {FL13[1]['heat']/1e6:,.2f} MW")
# (7) extrapolation of the code laws: decades beyond the calibration point
ratio = md*3600/500
print(f"  (7) code laws at the worked flow: {md*3600:,.0f} kg/h / 500 kg/h = {ratio:,.0f}x = {_log10(ratio):.2f} decades; "
      f"0.75 exponent: law gives {ratio**0.75:,.1f}x its calibration value against {ratio:,.0f}x the flow; "
      f"hysteresis bound 150,000 -> 200,000 rpm = {_log10(200000/150000):.3f} decades")
# minor: heat-only vs hybrid trade
print(f"  (minor) heat-only bound: 1/COP_heat = {1/main['COP']:.2f} units of 453.15 K heat per unit of heat lifted from 77.35 K; "
      f"hybrid trade: 1 MW_e into the lift saves {1/(eII_eng*eta_h):.2f} MW of heat (Eq. 6.6g; {1/eta_h:.2f} reversible)")
if os.path.exists(md_path):
    txt = open(md_path, encoding="utf-8").read()
    need14 = {"draw": f"{U1['m_g']:,.2f} kg/s", "drawshare": f"{U1['m_g']/md:.1%}".replace('%', ' %'), "Wdp1": f"{W_dp1/1e6:.2f} MW",
              "Wdp69": f"{W_dp69/1e6:.2f} MW", "AIrec": f"{f_ret*AI_lo/1e6:.2f}–{f_ret*AI_hi/1e6:.2f} MW",
              "AIunc": f"{(1-f_ret)*AI_lo/1e6:.2f}–{(1-f_ret)*AI_hi/1e6:.2f} MW", "AIrec1000": f"{AIREC[1000][0]/1e6:,.2f}–{AIREC[1000][1]/1e6:,.2f} MW",
              "wmin60": f"{1-T_ai[1]/Th:.4f}", "COPhp": f"{Th/(Th-T_ai[1]):.3f}", "carnot60": f"{1-Ta/T_ai[1]:.2%}".replace('%', ' %'),
              "dec": f"{_log10(ratio):.2f} decades", "hyst_dec": f"{_log10(200000/150000):.3f}", "COPinv": f"{1/main['COP']:.2f} units",
              "Qamb": f"{Qamb/1e6:,.2f} MW", "carnotB": f"{1-Tsat6/Th:.1%}".replace('%', ' %'), "carnotTm": f"{1-FM9[140.0][0]/Th:.1%}".replace('%', ' %')}
    bad = [k for k, v in need14.items() if v not in txt]
    print("AUDIT r14:", f"PASS - all {len(need14)} r14 values present" if not bad else f"MISSING {[(k, need14[k]) for k in bad]}")
    for stale in ("allage", "need P at a cold end above", "needs P at a cold end above", "P at a cold end above 77.35 K", "The tenth column", "P at a warmer cold end"):
        print(f"AUDIT r14 stale phrase '{stale}':", txt.count(stale))
    for must in ("useful heat available", "recoverable low-grade heat", "not added to the net", "no cold-end temperature term", "3.62 decades"):
        print(f"AUDIT r14 phrase '{must}':", txt.count(must))
# ---- r14 point 2: print every scaled-table line of 6.6.15 and the cost-sheet helpers, so the PDF number check can
#      match each table value to a printed calc value ----
print("\n--- r14: full scaled-line table (6.6.15) as printed in the section ---")
for lab, m, Lc in TAB13:
    print(f"  {lab:38s} reset {Lc['Qr']/1e3:,.2f} kW_th | lift {Lc['Qlift']/1e3:,.2f} kW_th | AI {Lc['AIlo']/1e3:,.2f}-{Lc['AIhi']/1e3:,.2f} kW_e | "
          f"ionisation loop {Lc['ion']/1e3:,.2f} kW (internal, net 0)")
print(f"  bearing + stator lifted {L0['bear'] + E_stat:.2f} W; eddy-only bearing exponent 2 x {b_rpm:.4f} = {2*b_rpm:.4f}")
print(f"  throttle heads after 6:1 from 5.5 / 6.0 bar g: {(5.5e5 + 101325)/6/1e5:.3f} / {(6.0e5 + 101325)/6/1e5:.3f} bar a")
print(f"  published inputs used as printed (not derived): eta_B = 16.08/20.1 kJ/kg [9]; v7 section 10.2 (60 C outlet)")

# =====================================================================================================================
# ==== r15 (Morgan 29 Oct 2026, 00:43 request; his proposed mechanism 00:45; stream split 00:48; N2 properties 00:51; ====
# ==== hotter feed 00:53). Re-condenser as internal regeneration, tested with real N2 properties (CoolProp 8.0.0,    ====
# ==== Span et al. EoS, the reference EoS of NIST REFPROP for N2). CoolProp is required for this block.               ====
# =====================================================================================================================
import CoolProp.CoolProp as CP
from math import log as _ln, sqrt as _sqrt, exp as _exp
PS = CP.PropsSI; FL = 'Nitrogen'
print("\n=================== r15 RE-CONDENSER AS INTERNAL REGENERATION (Morgan 2026-10-29 00:43-00:53) ===================")
p0 = 101325.0                                   # tank, 1 atm (77.35 K basis, r11 decision 2)
pH = p0 + dP_loop                               # 7.0133 bar a: 6 bar g working head [A #33, #87]
PR = 6.0                                        # 6:1 expansion (v7 w_exp basis)
dTp = 2.0                                       # K, exchanger pinch [assumed; large plate-fin practice]
eta_pump = etaB
def H(T=None, p=None, Q=None, S=None, h=None):
    if Q is not None: return PS('H', 'P', p, 'Q', Q, FL)
    if S is not None: return PS('H', 'P', p, 'S', S, FL)
    return PS('H', 'P', p, 'T', T, FL)
def S_(T, p): return PS('S', 'P', p, 'T', T, FL)
def T_ph(p, h): return PS('T', 'P', p, 'H', h, FL)
def maxduty(hot_p, hot_hin, cold_p, cold_hin, cap, dT, n=160):
    """largest counterflow duty Q <= cap: hot stream from hot_hin downward, cold stream from cold_hin upward, pinch dT"""
    def ok(Q):
        hout = hot_hin - Q
        for i in range(n + 1):
            q = Q*i/n
            if T_ph(hot_p, hout + q) < T_ph(cold_p, cold_hin + q) + dT - 1e-9: return False
        return True
    if ok(cap): return cap
    lo, hi = 0.0, cap
    for _ in range(40):
        mid = 0.5*(lo + hi); lo, hi = (mid, hi) if ok(mid) else (lo, mid)
    return lo

def cycle(Th_, pH_, dT=dTp, mvr=False, eref=None):
    """Pumped-liquid N2 loop per kg: 1 sat. liquid (tank, p0) -> pump -> 2 -> HP heating to Th_ -> 3 -> isothermal
    6:1 expansion at Th_ (ring) -> 4 -> LP regenerator -> 5 -> cold end (re-condenser) -> 1.
    mvr=True: cold vapour recompression (heat pump) moves LP latent heat up to the HP boiling band (T_sat(pH)+dT)."""
    pL_ = pH_/PR
    h1 = H(p=p0, Q=0); s1 = PS('S', 'P', p0, 'Q', 0, FL)
    wp = (H(p=pH_, S=s1) - h1)/eta_pump; h2 = h1 + wp
    h3 = H(Th_, pH_); s3 = S_(Th_, pH_); h4 = H(Th_, pL_); s4 = S_(Th_, pL_)
    qiso = Th_*(s4 - s3); wiso = qiso - (h4 - h3)
    TsH = PS('T', 'P', pH_, 'Q', 0, FL); TsL = PS('T', 'P', pL_, 'Q', 0, FL)
    hgH = H(p=pH_, Q=1); hlL = H(p=pL_, Q=0); hgL = H(p=pL_, Q=1)
    r = dict(Th=Th_, pH=pH_, pL=pL_, wp=wp, qiso=qiso, wiso=wiso, TsH=TsH, TsL=TsL, h1=h1, h2=h2, h3=h3, h4=h4)
    if not mvr:
        Qreg = maxduty(pL_, h4, pH_, h2, h3 - h2, dT)
        h5 = h4 - Qreg
        r.update(Qreg=Qreg, T5=T_ph(pL_, h5), qhx=h3 - h2 - Qreg, Qdir=0.0, QL=0.0, W=0.0, qc=h5 - h1)
    else:
        Qreg = maxduty(pL_, h4, pH_, hgH, h3 - hgH, dT)              # LP gas -> HP gas above boiling
        h5 = h4 - Qreg; T5 = T_ph(pL_, h5)
        hcut = H(min(T5, max(TsL + 1e-3, T_ph(pH_, h2) + dT)), pL_) if T5 > TsL + 1e-3 else h5
        Qdir = maxduty(pL_, h5, pH_, h2, max(0.0, h5 - hcut), dT)    # LP gas below T5 -> HP liquid (downhill)
        D = hgH - h2 - Qdir                                           # HP cold-band demand left (liquid + boiling)
        TL, THp = TsL, TsH + dT
        c = (THp/TL - 1)/eref                                         # W per W moved, real machine
        qrem = h5 - Qdir - h1
        QL = min(qrem, D/(1 + c)); W = c*QL
        extra = max(0.0, D - QL*(1 + c))                              # cold band still short: direct 453 K heat (downhill)
        r.update(Qreg=Qreg, T5=T5, Qdir=Qdir, D=D, c=c, QL=QL, W=W, qhx=h3 - hgH - Qreg + extra, extra=extra,
                 qc=qrem - QL, TL=TL, TH=THp)
    r['qh'] = r['qhx'] + qiso
    r['res'] = r['qh'] + wp + r['W'] - wiso - r['qc']                 # first law over the loop, per kg (must be 0)
    return r

# ---- (1) the stream split: external booking (v7) vs internal booking (Morgan 00:48) ----
print("(1) two-column comparison, one module (W):")
leak_v7 = mmu*w_exp
R_ext = Q_v7 - P - leak_v7 - Qrej_v7
print(f"    EXTERNAL (v7 Eq. 8): in Q {Q_v7/1e6:.3f} MW | out P {P/1e6:.3f} + leak term {leak_v7/1e6:.3f} + Q_rej {Qrej_v7/1e6:.3f} MW | R = {R_ext:.3e} W")
h_l0 = H(p=p0, Q=0)
vent_T = (80.0, 300.0, 453.15)
dh_vent = {T: H(T, p0) - h_l0 for T in vent_T}
ds_vent = {T: S_(T, p0) - PS('S', 'P', p0, 'Q', 0, FL) for T in vent_T}
for T in vent_T:
    print(f"    vent gas at {T:.2f} K vs makeup liquid: dh {dh_vent[T]/1e3:.2f} kJ/kg -> {mmu*dh_vent[T]/1e6:.3f} MW; ds {ds_vent[T]/1e3:.4f} kJ/kg K -> {mmu*ds_vent[T]/1e3:.2f} kW/K")
Qtop_lit = mmu*dh_vent[453.15]                  # Morgan's 'a few MW': top-up sized to the leak only
R_lit = Qtop_lit - P - leak_v7
print(f"    INTERNAL, literal (top-up sized to the leak only, {Qtop_lit/1e6:.2f} MW): R = Q_top - P - m_leak h_leak = {R_lit/1e6:,.2f} MW (does not close)")
print(f"    first law: P <= Q_top - m_leak h_leak, so a top-up of {Qtop_lit/1e6:.2f} MW supports at most {(Qtop_lit-leak_v7)/1e6:.2f} MW of P")
Qh_int = P + leak_v7
R_int = Qh_int - P - leak_v7
print(f"    INTERNAL with the 180 C waste heat as a boundary input: in Q_h {Qh_int/1e6:.3f} MW | out P {P/1e6:.3f} + leak term {leak_v7/1e6:.3f} | R = {R_int:.3e} W (first law closes)")
Sgen_int = mmu*ds_vent[453.15] - Qh_int/Th
print(f"    second law, internal booking, nothing rejected: S_gen = m_leak ds_vent - Q_h/T_h = {mmu*ds_vent[453.15]/1e3:.2f} - {Qh_int/Th/1e3:.2f} = {Sgen_int/1e3:,.2f} kW/K (< 0: forbidden)")
print(f"    vent carries {mmu*dh_vent[80.0]/1e6:.2f}-{mmu*dh_vent[453.15]/1e6:.2f} MW against the required >= {main['Qc']/1e6:.2f} MW floor: "
      f"{main['Qc']/(mmu*dh_vent[453.15]):.1f}x-{main['Qc']/(mmu*dh_vent[80.0]):.1f}x short")
for T in (300.0, 453.15):
    ex = Th*ds_vent[T] - dh_vent[T]
    mmin = P/ex
    print(f"    open cycle (no heat rejected, vent at {T:.2f} K): m_vent >= P/(T_h ds - dh) = {mmin:.2f} kg/s = {mmin/md:.2%} of the flow "
          f"({mmin/mmu:.1f}x the 0.4 % vent); makeup liquefaction at 0.55 kWh/kg {mmin*SEC_kg/1e6:.2f} MW, at w_min 0.207 kWh/kg {mmin*0.207*3.6e6/1e6:.2f} MW")
OPEN = {T: P/(Th*ds_vent[T] - dh_vent[T]) for T in (300.0, 453.15)}

# ---- (2) cycle states with real N2 properties ----
print("(2) pumped-liquid loop, real N2 (CoolProp 8.0.0 / Span et al.), Th 453.15 K, pH 7.0133 bar a, 6:1:")
C0 = cycle(Th, pH, dT=0.0); C2 = cycle(Th, pH, dT=dTp)
for lab, c in (("pinch 0 K (ideal exchanger)", C0), ("pinch 2 K", C2)):
    print(f"    {lab}: T2 {T_ph(pH, c['h2']):.2f} K; T_sat(pH) {c['TsH']:.2f} K; T_sat(pL) {c['TsL']:.2f} K; pump {c['wp']/1e3:.3f} kJ/kg; "
          f"w_iso {c['wiso']/1e3:.2f} kJ/kg; q_iso {c['qiso']/1e3:.2f} kJ/kg; regen {c['Qreg']/1e3:.2f} kJ/kg (LP out {c['T5']:.2f} K); "
          f"q_h ext {c['qh']/1e3:.2f} kJ/kg; cold end {c['qc']/1e3:.2f} kJ/kg; residual {c['res']:.1e} J/kg")
    print(f"      x {md:.3f} kg/s: P_cycle {md*c['wiso']/1e6:.2f} MW; Q_h {md*c['qh']/1e6:.2f} MW; cold end {md*c['qc']/1e6:.2f} MW; "
          f"efficiency {(c['wiso']-c['wp'])/c['qh']:.2%}; v7 Q_rej {Qrej_v7/1e6:.2f} MW; floor {main['Qc']/1e6:.2f} MW; latent recovered {1-c['qc']/(hgL_ := H(p=c['pL'],Q=1)-H(p=c['pL'],Q=0)) if False else 0:.0%}")
hfgL = H(p=C2['pL'], Q=1) - H(p=C2['pL'], Q=0); hfgH = H(p=pH, Q=1) - H(p=pH, Q=0)
print(f"    latent at pL {hfgL/1e3:.2f} kJ/kg at {C2['TsL']:.2f} K; HP boiling needs {hfgH/1e3:.2f} kJ/kg at {C2['TsH']:.2f} K: "
      f"gap {C2['TsH']-C2['TsL']:.2f} K uphill -> regenerable latent 0 %; LP gas sensible 453.15 K -> T_sat(pL) {(C2['h4']-H(p=C2['pL'],Q=1))/1e3:.2f} kJ/kg (regenerable)")
print(f"    w_iso EoS {C2['wiso']/1e3:.2f} kJ/kg vs v7 w_exp 242.5 kJ/kg ({C2['wiso']/w_exp-1:+.2%})")
print(f"    eps needed for the floor {1-main['Qc']/Qrej_v7:.3f}; eps achieved by regeneration alone (cold end vs v7 Q_rej) {1-md*C2['qc']/Qrej_v7:+.3f}")
# ---- (3) passive J-T and expansion cold ----
print("(3) passive liquid return:")
for pa, T in ((C2['pL'], 79.0), (C2['pL'], 100.0), (pH, 100.0), (pH, 120.0)):
    y = (H(T, p0) - H(T, pa))/(H(T, p0) - h_l0)
    print(f"    Linde-Hampson y from {pa/1e5:.4f} bar a at {T:.1f} K to 1 atm: {y:.4%}")
YJT_resid = (H(100.0, p0) - H(100.0, C2['pL']))/(H(100.0, p0) - h_l0)
YJT_full = (H(100.0, p0) - H(100.0, pH))/(H(100.0, p0) - h_l0)
hlL = H(p=C2['pL'], Q=0); xfl = (hlL - h_l0)/(H(p=p0, Q=1) - h_l0)
print(f"    throttling the LP condensate {C2['pL']/1e5:.4f} -> 1.01325 bar: flash {xfl:.3%} (liquid kept {1-xfl:.3%})")
s_in = S_(Th, pH); h_out_s = PS('H', 'P', C2['pL'], 'S', s_in, FL); T_out_s = PS('T', 'P', C2['pL'], 'S', s_in, FL)
print(f"    adiabatic (not isothermal) 6:1 expansion from 453.15 K: outlet {T_out_s:.1f} K, still gas ({T_out_s - C2['TsL']:.1f} K above saturation)")
# pressure needed for an isentropic expansion from 453.15 K to reach saturated vapour at 1 atm
sg0 = PS('S', 'P', p0, 'Q', 1, FL)
lo, hi = 2e5, 1e9
for _ in range(80):
    mid = _sqrt(lo*hi)
    lo, hi = (mid, hi) if S_(Th, mid) > sg0 else (lo, mid)
print(f"    isentropic from 453.15 K to saturated vapour at 1 atm needs p_in {lo/1e5:,.0f} bar a (ratio {lo/p0:,.0f}:1), and still yields 0 % liquid")
PREQ = lo
print(f"    J-T self-cooling share booked since r9: 0.031 MW")
# ---- (4) cold vapour recompression (MVR): the legitimate form of 'latent routed back to the expansion inlet' ----
print("(4) latent routing: condensing LP stream at T_sat(pL) cannot heat the HP feed boiling at T_sat(pH) directly;")
M_d = cycle(Th, pH, dT=dTp, mvr=True, eref=eII_ref_hi); M_s = cycle(Th, pH, dT=dTp, mvr=True, eref=eII_ref_lo)
M_i = cycle(Th, pH, dT=dTp, mvr=True, eref=1.0)
for lab, c in (("ideal (Carnot)", M_i), ("design eta_II 0.5175", M_d), ("sizing eta_II 0.345", M_s)):
    print(f"    MVR {lab}: lift {c['TL']:.2f} -> {c['TH']:.2f} K, W/Q {c['c']:.4f}; moved {c['QL']/1e3:.2f} kJ/kg of {hfgL/1e3:.2f}; work {c['W']/1e3:.2f} kJ/kg; "
          f"direct LP gas -> HP liquid {c['Qdir']/1e3:.2f} kJ/kg; regen {c['Qreg']/1e3:.2f} kJ/kg; q_h ext {c['qh']/1e3:.2f} kJ/kg; residual cold end {c['qc']/1e3:.2f} kJ/kg; first law {c['res']:.1e} J/kg")
    print(f"      x {md:.3f} kg/s: moved {md*c['QL']/1e6:.2f} MW; MVR work {md*c['W']/1e6:.2f} MW; Q_h {md*c['qh']/1e6:.2f} MW; residual cold end {md*c['qc']/1e6:.2f} MW "
          f"(floor {main['Qc']/1e6:.2f}); latent regenerated {c['QL']/hfgL:.1%}")
print(f"    routing to the 453.15 K inlet instead: W/Q ideal {(Th+dTp)/M_d['TL']-1:.3f}, design {((Th+dTp)/M_d['TL']-1)/eII_ref_hi:.3f} (vs {M_d['c']:.4f} to the boiling band)")
# ---- (5) options costed, one module, heat-led (E_lift = 0; MVR shaft from the waste-heat engine of D8) ----
eng = eII_eng*eta_h                              # real engine efficiency 0.135
def option(qc, qh, W, label):
    Qc_ = md*qc; Qh_ = md*qh; W_ = md*W
    Qlift = Qc_*lift_per_W; Qmvr = W_/eng
    tot = Qh_ + Qmvr + Qlift
    amb = tot - P + md*C2['wp'] - md*(qh*0) # placeholder, recomputed below
    return dict(label=label, Qc=Qc_, Qh=Qh_, W=W_, Qlift=Qlift, Qmvr=Qmvr, tot=tot)
OPT = {
 'R': option(C2['qc'], C2['qh'], 0.0, "(R) passive re-condenser (v7 external booking, real N2): cold end lifted to 300 K by the LN2 generator"),
 'H': option(M_d['qc'], M_d['qh'], M_d['W'], "(H) cold vapour recompression to the boiling band + residual lifted (design machines)"),
 'Hs': option(M_s['qc'], M_s['qh'], M_s['W'], "(H) same, sizing machines (eta_II 0.345)"),
 'F': dict(label="r14 floor booking (reversible cold end; lower bound)", Qc=main['Qc'], Qh=P+main['Qc'], W=0.0, Qlift=main['Qc']*lift_per_W, Qmvr=0.0,
           tot=P+main['Qc']+main['Qc']*lift_per_W),
}
for k in ('F', 'R', 'H', 'Hs'):
    o = OPT[k]
    print(f"    {k:2s} {o['label']}: cold end {o['Qc']/1e6:.2f} MW; cycle heat {o['Qh']/1e6:.2f} MW; MVR work {o['W']/1e6:.2f} MW (heat {o['Qmvr']/1e6:.2f} MW); "
          f"lift heat {o['Qlift']/1e6:,.2f} MW; total waste heat {o['tot']/1e6:,.2f} MW ({o['tot']/P:.2f} P; P/Q {P/o['tot']:.2%})")
openE = OPEN[300.0]*SEC_kg
print(f"    (ii) open cycle (vent carries the rejection, vent at 300 K): vent {OPEN[300.0]:.2f} kg/s; makeup {openE/1e6:.2f} MW_e at 0.55 kWh/kg; net before AI {(P-openE-L0['eaux'])/1e6:.2f} MW")
print(f"    chosen: (H). Saves {(OPT['R']['tot']-OPT['H']['tot'])/1e6:,.2f} MW of heat per module against (R) ({1-OPT['H']['tot']/OPT['R']['tot']:.1%}); "
      f"is {OPT['H']['tot']/OPT['F']['tot']:.2f}x the r14 floor booking")
# heat-driven vs electric MVR shaft
print(f"    MVR shaft from electricity instead: net before AI {(L0['net0']-OPT['H']['W'])/1e6:.2f} MW; heat {(OPT['H']['tot']-OPT['H']['Qmvr'])/1e6:,.2f} MW")
# ---- (6) control volumes: first law and entropy generation, one module, chosen design (H) ----
o = OPT['H']; Hc = M_d
Q_in_heat = o['tot']
lift_W_real = o['Qc']*(Ta/Tc - 1)/eII_ref_hi       # LN2 generator shaft work (from its engine)
Q_amb = (o['Qmvr'] - o['W']) + (o['Qlift'] - lift_W_real) + (o['Qc'] + lift_W_real)   # engines' rejection + generator condenser
E_pump = md*Hc['wp']
vent_h = mmu*dh_vent[300.0]; vent_s = mmu*ds_vent[300.0]
leak_eps = vent_h          # vent gas leaves at 300 K; makeup arrives as liquid at 77.35 K
# boundary: in waste heat, pump electricity, makeup liquid; out P (gross isothermal work), heat to ambient, vent gas
P_c = md*Hc['wiso']
R1 = (Q_in_heat - P_c + E_pump) - Q_amb      # loop + MVR + generator; vent/makeup handled next
# the vent and makeup: the leaked 0.4 % is warmed by waste heat to 300 K before leaving (bounded by its enthalpy) - book it explicitly
R_A = (Q_in_heat + vent_h + E_pump + mmu*h_l0) - (P_c + Q_amb + mmu*(h_l0 + dh_vent[300.0]))
print(f"(6) view A (whole plant: loop, ring, MVR, cold box, LN2 generator, engines):")
print(f"    in: waste heat {Q_in_heat/1e6:,.2f} MW (+ leak warming {vent_h/1e6:.3f} MW) + pump {E_pump/1e6:.3f} MW_e + makeup liquid {mmu:.4f} kg/s")
print(f"    out: P_cycle {P_c/1e6:.2f} MW + heat to 300 K {Q_amb/1e6:,.2f} MW + vent {mmu:.4f} kg/s at 300 K")
print(f"    first-law residual R_A = {R_A:.3e} W")
S_A = Q_amb/Ta + vent_s - Q_in_heat/Th - vent_h/Th
print(f"    entropy generation S_gen,A = Q_amb/T_a + m(s_v - s_l) - Q_h/T_h = {Q_amb/Ta/1e3:,.2f} + {vent_s/1e3:.2f} - {Q_in_heat/Th/1e3:,.2f} - {vent_h/Th/1e3:.3f} = {S_A/1e3:,.2f} kW/K (>= 0)")
# view B: cold box (re-condenser + tank liquid + ullage), heat in at about 77-79 K, out to the LN2 generator
ingress_area, ingress_flux = 1000.0, 1.0      # m2, W/m2 [assumed: MLI-class insulation; no deposited record]
Q_bear = L0['bear'] + E_stat
Q_ing = ingress_area*ingress_flux
Q_pinch = md*(C2['qc'] - C0['qc'])
Qgen_B = o['Qc'] + Q_bear + Q_ing
R_B = (o['Qc'] + Q_bear + Q_ing) - Qgen_B
print(f"(6) view B (cold box): in residual condensing load {o['Qc']/1e6:.3f} MW + YBCO/stator {Q_bear:.2f} W + insulation {Q_ing/1e3:.1f} kW [assumed 1 W/m2 x 1,000 m2] "
      f"-> out to the LN2 generator {Qgen_B/1e6:.3f} MW; residual {R_B:.1e} W; 2 K pinch adds {Q_pinch/1e6:.2f} MW to the cold end (vs 0 K)")
S_B = Qgen_B/Tc - o['Qc']/M_d['TL'] - (Q_bear + Q_ing)/Tc
print(f"    S_gen,B = Q_out/T_c - Q_in/T_in = {S_B/1e3:.3f} kW/K (>= 0: heat flows {M_d['TL']:.2f} K -> {Tc:.2f} K)")
# ---- (7) top-up, r14 vs r15 ----
print(f"(7) top-up: mass {mmu:.4f} kg/s (unchanged); makeup liquefaction {L0['Pliq']/1e6:.2f} MW_e (unchanged); leak enthalpy {mmu*dh_vent[80.0]/1e6:.2f}-{mmu*dh_vent[453.15]/1e6:.2f} MW")
print(f"    cold-side boundary load: r14 {main['Qc']/1e6:.2f} MW (floor) -> r15 {Qgen_B/1e6:.2f} MW (residual after MVR + ingress); MVR shaft {o['W']/1e6:.2f} MW from waste heat")
print(f"    unrecoverable itemised: latent beyond MVR reach {o['Qc']/1e6:.2f} MW (includes 2 K pinch {Q_pinch/1e6:.2f} MW); bearings/stators {Q_bear:.2f} W; insulation {Q_ing/1e3:.1f} kW (assumed)")
# ---- (8) inventory and temperature, pass by pass ----
print("(8) inventory and tank temperature, 20 passes (pass = 60 s; tank 1,000 m3 liquid + 100 m3 ullage, assumed; relief 9.0132 bar a, top of the 3-8 bar g band):")
V_tank = 1100.0; tau = 60.0; p_rel = 9.0132e5
def T_from_vap(Mv, Vu):
    rho = Mv/Vu
    lo_, hi_ = 63.2, PS('T', 'P', p_rel, 'Q', 1, FL)
    if PS('D', 'T', hi_, 'Q', 1, FL) <= rho: return hi_, True
    for _ in range(50):
        m_ = 0.5*(lo_ + hi_); lo_, hi_ = (m_, hi_) if PS('D', 'T', m_, 'Q', 1, FL) < rho else (lo_, m_)
    return lo_, False
SIM = {}
need = md*(1 - (1 - eta_reg))*C2['qc']              # heat to re-condense the returning 99.6 % (passive layout)
for case, removed in (("Morgan passive (J-T 0.031 MW + vent)", 0.031e6 + vent_u), ("booked (H): MVR + generator", need), ("generator 1 % short", 0.99*need)):
    ML = 1000.0*rho_L; Mv = PS('D', 'T', Tc, 'Q', 1, FL)*100.0; rows = []
    vented_tot = 0.0
    for k in range(1, 21):
        y = min(1.0, removed/need)
        ret_liq = eta_reg*md*tau*y; ret_vap = eta_reg*md*tau*(1 - y)
        ML = ML - md*tau + ret_liq + mmu*tau
        Vu = V_tank - ML/rho_L
        Mv = Mv + ret_vap
        T_t, at_rel = T_from_vap(Mv, Vu)
        vent_k = 0.0
        if at_rel:
            cap = PS('D', 'P', p_rel, 'Q', 1, FL)*Vu; vent_k = Mv - cap; Mv = cap
        vented_tot += vent_k
        rows.append((k, ML/1e3, T_t, vent_k/tau))
    SIM[case] = rows
    for k, ml, T_t, vk in rows:
        if k in (1, 2, 5, 10, 20):
            print(f"    {case:40s} pass {k:2d}: liquid {ml:9,.1f} t | tank {T_t:6.2f} K | relief flow {vk:7.2f} kg/s")
print(f"    -190 C = 83.15 K is saturation at {PS('P','T',83.15,'Q',0,FL)/1e5:.4f} bar a; the 77.35 K basis is -195.80 C at 1.01325 bar a")
# ---- (9) N2 properties: rate and hardware size (not amount) ----
rl = PS('D', 'P', p0, 'Q', 0, FL); rv = PS('D', 'P', p0, 'Q', 1, FL); sig_st = PS('I', 'P', p0, 'Q', 0, FL)
qchf = 0.131*hfg_77*_sqrt(rv)*(sig_st*9.80665*(rl - rv))**0.25
print("(9) N2 properties (CoolProp at 1 atm):")
print(f"    h_fg {hfg_77/1e3:.2f} kJ/kg; rho_l {rl:.2f}; rho_v {rv:.3f} kg/m3; liquid/sat. vapour {rl/rv:.1f}; liquid/gas at 293.15 K {rl/PS('D','T',293.15,'P',p0,FL):.1f}, at 288.15 K {rl/PS('D','T',288.15,'P',p0,FL):.1f}")
print(f"    surface tension {sig_st*1e3:.3f} mN/m; Zuber-Kutateladze CHF 0.131 h_fg rho_v^0.5 [sigma g (rho_l - rho_v)]^0.25 = {qchf/1e3:.1f} kW/m2")
for lab, Q_ in (("residual cold end (H)", OPT['H']['Qc']), ("passive cold end (R)", OPT['R']['Qc']), ("floor", main['Qc'])):
    print(f"    boiling area for {lab} {Q_/1e6:.2f} MW: at CHF {Q_/qchf:,.0f} m2; at 50 % of CHF {Q_/(0.5*qchf):,.0f} m2; boil-off {Q_/hfg_77:,.2f} kg/s")
print(f"    the latent heat moves {hfg_77/1e3:.2f} kJ per kg at constant temperature: {hfg_77/(1040*1.0)/1e0:.0f} kg of gas per K of sensible warming carries the same")
# ---- (10) hotter feed and pressure sweep (Morgan 00:53) ----
print("(10) feed temperature and pressure sweep (H basis, design machines; P held by the ring equation at fixed sigma, omega, B, K, V):")
SW = []
kB, Eion = 8.617333e-5, 15.581
for Thx in (453.15, 463.15, 473.15, 523.15, 573.15):
    for pHx in (6.5133e5, 7.0133e5, 9.0132e5):
        c = cycle(Thx, pHx, dT=dTp, mvr=True, eref=eII_ref_hi)
        sH = S_(Thx, pHx); hs = PS('H', 'P', pHx/PR, 'S', sH, FL)
        c0 = _sqrt(2*(H(Thx, pHx) - hs))
        m_x = P/c['wiso']
        lpw = (Ta/Tc - 1)/(eII_ref_hi*eII_eng*(1 - Ta/Thx))
        eng_x = eII_eng*(1 - Ta/Thx)
        Qc_x = m_x*c['qc']; W_x = m_x*c['W']; Qh_x = m_x*c['qh']
        tot_x = Qh_x + W_x/eng_x + Qc_x*lpw
        floor_x = P*Tc/(Thx - Tc)
        res_x = m_x*c['res']
        lim = "within published setpoint" if Thx <= 453.15 else ("within CFRP 200 C rating [3]" if Thx <= 473.15 else "exceeds CFRP 200 C rating [3]")
        SW.append(dict(Th=Thx, pH=pHx, c0=c0, m=m_x, tot=tot_x, Qc=Qc_x, W=W_x, Qh=Qh_x, floor=floor_x, carnot=1 - Tc/Thx, eff=P/tot_x, res=res_x, lim=lim))
        print(f"    Th {Thx:.2f} K, pH {pHx/1e5:.4f} bar a: c0 {c0:,.0f} m/s; w {c['wiso']/1e3:.2f} kJ/kg; m {m_x:.2f} kg/s; rpm 200,000 (held); "
              f"Carnot {1-Tc/Thx:.2%}; floor {floor_x/1e6:.2f} MW; residual cold end {Qc_x/1e6:.2f} MW; "
              f"MVR {W_x/1e6:.2f} MW; total heat {tot_x/1e6:,.2f} MW; P/Q {P/tot_x:.2%}; first law {res_x:.1e} W; {lim}")
print("    conductivity: the design's own passive ionisation of charged cryogenic N2 (sigma_high, published); no thermal-ionisation (Saha) or hot-plasma model is used (r21, Morgan 11:28)")
print(f"    tip speed at 200,000 rpm, r = 93 mm: {2*pi*0.093*200000/60:,.0f} m/s")
# drift when heat in exceeds P + rejection + losses (regenerated loop: the surplus returns to the inlet each pass)
cpH = PS('C', 'T', Th, 'P', pH, FL)
for frac in (0.01, 0.05):
    dQ = frac*OPT['H']['Qh']; dT_pass = dQ/(md*cpH)
    n5 = 5.0/dT_pass; nlim = (473.15 - Th)/dT_pass
    print(f"    surplus {frac:.0%} of cycle heat ({dQ/1e6:.2f} MW): +{dT_pass:.2f} K per pass; AI interlock (+5 K [3]) after {n5:.1f} passes; CFRP rating 473.15 K after {nlim:.1f} passes")
print(f"    cp N2 at 453.15 K, 7.0133 bar a {cpH:.1f} J/kg K")
# ---- (11) flow anchors: vent capacity vs required rejection ----
print("(11) flow anchors (r13 law): vent enthalpy vs required cold-end rejection")
ANCH = []
for lab, m in (("0.038 kg/s", 0.038), ("1000 kg/h", 1000/3600), ("582.336 kg/s", md)):
    Pm = P_of(m); vent_cap = (1 - eta_reg)*m*dh_vent[453.15]; fl = Pm*Tc/(Th - Tc)
    res_cold = m*M_d['qc']
    ANCH.append((lab, m, Pm, vent_cap, fl, res_cold))
    print(f"    {lab:13s}: P {Pm/1e3:,.2f} kW; vent (0.4 %, gas at 453.15 K) carries {vent_cap/1e3:,.3f} kW; floor {fl/1e3:,.2f} kW; "
          f"design residual cold end (H) {res_cold/1e3:,.2f} kW; vent / floor {vent_cap/fl:.2%}")
# ---- (12) fleet on the booked (H) basis ----
print("(12) fleet, booked (H) basis, eta_reg 0.996, one AI per 100-module chain:")
bo_H = OPT['H']['Qc']/hfg_77; ret_H = bo_H*dP_loop/(rho_L*etaB)
FLH = {}
for N in (1, 10, 100, 1000):
    nAI = -(-N//100)
    elec = N*L0['eaux'] + (N - 1)*ret_H
    net_hi = N*P - L0['Pliq'] - elec - nAI*L0['AIlo']; net_lo = N*P - L0['Pliq'] - elec - nAI*L0['AIhi']
    heat = N*OPT['H']['tot'] + L0['leak']
    FLH[N] = (elec, net_lo, net_hi, heat)
    print(f"    N {N:4d}: heat {heat/1e6:,.2f} MW; pumps and controls {elec/1e6:,.2f} MW; net {net_lo/1e6:,.2f}-{net_hi/1e6:,.2f} MW; residual boil-off per reset {bo_H:.2f} kg/s; return pump {ret_H/1e6:.3f} MW")
print(f"    net before AI, N = 1: {L0['net0']/1e6:.2f} MW (unchanged: MVR and lift run on waste heat)")
# ---- (13) Morgan 00:58: unrecovered latent -> extra LN2-generator duty; sensitivity to the recovery fraction ----
print("(13) closure path (Morgan 00:58): latent not recovered at the re-condenser = extra LN2-generator duty, lifted to 300 K")
Qlat = Qrej_v7                                   # v7's returned-stream latent load, 116.00 MW
eps_max_ = 1 - main['Qc']/Qlat
eps_mvr = 1 - OPT['H']['Qc']/Qlat
w_lift_e = (Ta/Tc - 1)/eII_ref_hi                # W_e per W lifted, design machines (electric generator drive)
print(f"    returned-stream latent {Qlat/1e6:.2f} MW; second-law cap on recovery eps_max {eps_max_:.4f}; passive regeneration {0:.0%}; "
      f"MVR design (H) equivalent eps {eps_mvr:.4f}")
print(f"    lift per W: heat-driven {lift_per_W:.2f} W of 180 C heat; electric {w_lift_e:.4f} W_e (published-machine fraction {eII_ref_hi:.4f} of Carnot)")
SENS = []
for eps in (0.0, 0.5, 0.70, eps_max_, 0.90, 0.996):
    eff_eps = min(eps, eps_max_)
    Qun = max((1 - eps)*Qlat, main['Qc'])
    heat = P + Qun + Qun*lift_per_W + L0['leak']
    net_heat = L0['net0']
    net_elec = P - L0['Pliq'] - L0['eaux'] - Qun*w_lift_e
    SENS.append((eps, Qun, heat, net_heat, net_elec))
    tag = " (capped at the second-law floor)" if eps > eps_max_ else ""
    print(f"    eps {eps:6.4f}: generator extra duty {Qun/1e6:7.2f} MW{tag}; heat-led: waste heat {heat/1e6:9,.2f} MW, net before AI {net_heat/1e6:.2f} MW; "
          f"electric lift: net before AI {net_elec/1e6:8.2f} MW")
print("    with flow (r13 law, heat-led, MVR design case): ")
for lab, m in (("0.038 kg/s", 0.038), ("1000 kg/h", 1000/3600), ("582.336 kg/s", md)):
    k = P_of(m)/P
    print(f"      {lab:13s}: residual generator duty {k*OPT['H']['Qc']/1e3:,.2f} kW; MVR {k*OPT['H']['W']/1e3:,.2f} kW; total heat {k*OPT['H']['tot']/1e3:,.2f} kW; "
          f"heat to 300 K {k*(OPT['H']['tot']-P)/1e3:,.2f} kW")

# ---- (14) Morgan 00:59: book the generator duty from the published cryocooler / LN2 records ----
print("(14) LN2-generator duty on the residual boil-off, from the published records:")
SEC_pub = (0.15, 0.25)                           # kWh/kg, 'system target' with Stage 1 + 2 pre-cooling [Zenodo 18916931, How do we reduce parasitic costs, intro and 6.3.2]
bo_res = OPT['H']['Qc']/hfg_77
w_rev_vap = hfg_77*(Ta/Tc - 1)/3.6e6             # kWh/kg, reversible re-liquefaction of saturated vapour at 77.35 K against 300 K
print(f"    residual boil-off {bo_res:.2f} kg/s; reversible minimum to re-liquefy saturated vapour at 77.35 K vs 300 K {w_rev_vap:.4f} kWh/kg")
for sec in SEC_pub:
    We = bo_res*sec*3.6e6
    print(f"    at {sec:.2f} kWh/kg: electricity {We/1e6:.2f} MW_e ({sec/w_rev_vap:.2f}x the reversible minimum); heat to 300 K {(We + OPT['H']['Qc'])/1e6:.2f} MW; "
          f"net before AI if electric {(L0['net0'] - We)/1e6:.2f} MW")
We_floor = main['Qc']/hfg_77*0.25*3.6e6
print(f"    the same at the r14 floor (145.93 kg/s): {main['Qc']/hfg_77*0.15*3.6e6/1e6:.2f}-{We_floor/1e6:.2f} MW_e")
print(f"    heat-led (D8, design machines): {OPT['H']['Qlift']/1e6:,.2f} MW of 180 C heat, heat to 300 K {(OPT['H']['Qlift'] + OPT['H']['Qc'])/1e6:,.2f} MW; net before AI {L0['net0']/1e6:.2f} MW")
# space: radiative rejection at the condensing temperature
sb = 5.670374419e-8; eps_r = 0.9                  # emissivity 0.9 as in the TITAN record [Zenodo 18916931, Replenishing LN2 for Free]
for Trad in (77.35, 243.0):
    flux = eps_r*sb*(Trad**4 - 2.7**4)
    print(f"    space radiator at {Trad:.2f} K, eps 0.9: {flux:.3f} W/m2 -> {OPT['H']['Qc']/flux/1e6:,.2f} km2 for {OPT['H']['Qc']/1e6:.2f} MW; {main['Qc']/flux/1e6:,.2f} km2 for the floor")
print(f"    published example check: 0.9 x sigma x 80 m2 x (40^4 - 2.7^4) = {0.9*sb*80*(40**4-2.7**4):.2f} W (record prints 3.2 kW)")
print(f"    record's 50-100 m2 at 77.35 K rejects {0.9*sb*50*77.35**4:.0f}-{0.9*sb*100*77.35**4:.0f} W")
# ---- (15) Morgan 01:02: the vent's heat-carrying capacity at the hottest stream ----
print("(15) vent heat-carrying capacity m_vent (h(T_exit) - h_makeup) vs required rejection after internal recovery:")
dh573 = H(573.15, p0) - h_l0
for lab, m in (("0.038 kg/s", 0.038), ("1000 kg/h", 1000/3600), ("582.336 kg/s", md)):
    k = P_of(m)/P; mv = (1 - eta_reg)*m
    need_H = k*OPT['H']['Qc']; need_F = k*main['Qc']
    for Tx, dh in ((453.15, dh_vent[453.15]), (573.15, dh573)):
        cap = mv*dh
        print(f"    {lab:13s} exit {Tx:.2f} K: vent {mv*1e3:,.3f} g/s carries {cap/1e3:,.3f} kW; required (H residual) {need_H/1e3:,.2f} kW -> vent covers {cap/need_H:.2%}, "
              f"300 K path {(need_H-cap)/1e3:,.2f} kW; vs floor {cap/need_F:.2%}")
print(f"    dh to 573.15 K {dh573/1e3:.2f} kJ/kg; to 453.15 K {dh_vent[453.15]/1e3:.2f} kJ/kg")

# ---- (16) Morgan 01:03: the vent as a heat-transfer path (heat travels through the gas, not held by it) ----
print("(16) vent as a heat path to the 300 K ambient (conduction along the gas column + wall convection):")
Dv, Lv, h_out = 0.10, 1.0, 25.0                 # m, m, W/m2K [assumed: vent bore 100 mm, 1 m exposed run, forced-air convection outside]
Av = pi*Dv**2/4; Aw = pi*Dv*Lv
for Tg in (Tc, 243.0, Th, 573.15):
    kg = PS('L', 'T', Tg, 'P', p0, FL)
    q_cond = kg*Av*(Tg - Ta)/Lv
    q_conv = h_out*Aw*(Tg - Ta)
    print(f"    gas at {Tg:.2f} K: k {kg*1e3:.2f} mW/m K; conduction along the column {q_cond:+.3f} W; wall convection {q_conv/1e3:+.3f} kW "
          f"({'out of the loop' if Tg > Ta else 'INTO the loop'})")
print(f"    required rejection after internal recovery (H residual) {OPT['H']['Qc']/1e6:.2f} MW at about 78 K: heat cannot flow from 78 K to 300 K without work")
print(f"    wall area needed to pass the residual at 453.15 K by convection (h 25 W/m2K): {OPT['H']['Qc']/(h_out*(Th-Ta))/1e3:,.1f} thousand m2, "
      f"and that heat would then leave the 453 K feed before the ring, not the 78 K cold end")
# ---- r15 audit ----
if os.path.exists(md_path):
    txt = open(md_path, encoding="utf-8").read()
    need15 = {"Rlit": f"{abs(R_lit)/1e6:,.2f} MW", "Sint": f"{abs(Sgen_int)/1e3:,.2f} kW/K", "qcR": f"{md*C2['qc']/1e6:.2f} MW", "QhR": f"{md*C2['qh']/1e6:.2f} MW",
              "gap": f"{C2['TsH']-C2['TsL']:.2f} K", "resH": f"{OPT['H']['Qc']/1e6:.2f} MW", "WH": f"{OPT['H']['W']/1e6:.2f} MW",
              "totH": f"{OPT['H']['tot']/1e6:,.2f} MW", "totR": f"{OPT['R']['tot']/1e6:,.2f} MW", "SA": f"{S_A/1e3:,.2f} kW/K",
              "RA": "R_A", "open300": f"{OPEN[300.0]:.2f} kg/s", "chf": f"{qchf/1e3:.1f} kW/m2".replace('m2', 'm²')}
    bad = [k for k, v in need15.items() if v not in txt]
    print("AUDIT r15:", f"PASS - all {len(need15)} r15 values present" if not bad else f"MISSING {[(k, need15[k]) for k in bad]}")

# =====================================================================================================================
# ==== r16 (Morgan 29 Oct 2026, 01:41-02:00): hot-side vent; recirculation framing; waste heat as free fuel;        ====
# ==== two COP accounts everywhere; Earth and space operational cases.                                              ====
# =====================================================================================================================
print("\n=================== r16 TWO COP ACCOUNTS, HOT-SIDE VENT, EARTH AND SPACE (Morgan 01:41-02:00) ===================")
# ---- (1) the 0.4 % vent leaves from the hot charged side (~453.15 K) and repels its heat to ambient air ----
h453 = H(453.15, p0); h300 = H(300.0, p0)
vent_hot_amb = mmu*(h453 - h300)                 # heat the vented gas gives the 300 K air as it cools 453.15 -> 300 K (downhill)
vent_hot_tot = mmu*(h453 - h_l0)                 # enthalpy leaving with the vent, relative to the makeup liquid
print(f"(1) vent from the hot side at 453.15 K: {mmu:.4f} kg/s; heat rejected to 300 K air (453.15 -> 300 K) {vent_hot_amb/1e6:.3f} MW "
      f"({(h453-h300)/1e3:.2f} kJ/kg); enthalpy leaving vs makeup liquid {vent_hot_tot/1e6:.3f} MW; separate from the cold-side closure {OPT['H']['Qc']/1e6:.2f} MW")
for lab, m in (("0.038 kg/s", 0.038), ("1000 kg/h", 1000/3600), ("582.336 kg/s", md)):
    mv = (1 - eta_reg)*m
    print(f"    {lab:13s}: vent {mv*1e3:,.3f} g/s; hot-side rejection to air {mv*(h453-h300)/1e3:,.3f} kW; enthalpy leaving {mv*(h453-h_l0)/1e3:,.3f} kW")
# ---- (2) framing: where the external waste heat enters the loop and whether the generator's rejection can go back in ----
qx_nonIso = M_d['qh'] - M_d['qiso']
T_ext_start = T_ph(pH, M_d['h3'] - qx_nonIso)
print(f"(2) recirculated in the loop per kg (design H): sensible regenerated {M_d['Qreg']/1e3:.2f} + direct {M_d['Qdir']/1e3:.2f} + latent by MVR {M_d['QL']/1e3:.2f} kJ/kg "
      f"= {md*(M_d['Qreg']+M_d['Qdir']+M_d['QL'])/1e6:.2f} MW recirculated; outside heat into the feed {md*qx_nonIso/1e6:.2f} MW at {T_ext_start:.2f}-453.15 K "
      f"plus the isothermal expansion {md*M_d['qiso']/1e6:.2f} MW at 453.15 K")
print(f"    generator condenser at ~300 K can feed the loop only below 300 K; the loop's outside warming need starts at {T_ext_start:.2f} K -> usable return 0 MW (booked to ambient)")
print(f"    MVR delivers into the feed's boiling band (start of the expansion loop): {md*M_d['QL']/1e6:.2f} + {OPT['H']['W']/1e6:.2f} = {(md*M_d['QL']+OPT['H']['W'])/1e6:.2f} MW")
# ---- (3)-(4) two COP accounts ----
E_strip = 11.7                                   # W, Book 1 strip [8]
def cop_row(N, Qheat, ret):
    Ein = L0['Pliq'] + N*L0['eaux'] + (N - 1)*ret
    Pg = N*P
    return dict(N=N, Ein=Ein, Pg=Pg, Q=Qheat, a=Pg/(Qheat + Ein), b=Pg/Ein,
                b_ai=Pg/(Ein + (-(-N//100))*L0['AIlo']), bnet=(Pg - Ein)/Ein)
ret_floor = (main['Qc']/hfg_77)*dP_loop/(rho_L*etaB)
COP = {}
print(f"    COP_e ceiling per module, booked: P/(E_aux + return pump) = {P/(L0['eaux']+ret_H):.1f}; floor {P/(L0['eaux']+ret_floor):.1f}")
print(f"    vent moved to hot side: N=1 generator cold-gas draw +{mmu:.2f} kg/s -> {430.58+mmu:.1f} kg/s (r15 Table 13f 430.58); N=4 boil-off {3*145.93:.1f} kg/s, shift {mmu/(3*145.93+mmu):.2%}")
print("(3) two COP accounts. (a) P/(Q_waste + E_in): full thermodynamic books. (b) P/E_in: electricity out over electricity in, waste heat unpaid.")
print(f"    E_in = makeup {L0['Pliq']/1e6:.3f} MW_e (shared) + N x pumps/controls/strip {L0['eaux']/1e6:.4f} MW_e + (N-1) x return pump; AI excluded from E_in (a use of the output), shown as b_AI2%")
for basis, Qmod, ret in (("booked (H)", OPT['H']['tot'], ret_H), ("floor (lower bound)", OPT['F']['tot'], ret_floor)):
    for N in (1, 10, 100, 1000):
        r = cop_row(N, N*Qmod + L0['leak'], ret)
        COP[(basis, N)] = r
        print(f"    {basis:20s} N {N:4d}: E_in {r['Ein']/1e6:,.3f} MW_e; waste heat {r['Q']/1e6:,.2f} MW; gross {r['Pg']/1e6:,.2f} MW; "
              f"COP_a {r['a']:.4f} ({r['a']:.2%}); COP_b {r['b']:,.1f}; COP_b with AI 2 % {r['b_ai']:,.1f}; (net/E_in {r['bnet']:,.1f})")
print(f"    Book 1 strip only (v7): P / 11.7 W = {P/E_strip:,.0f}; P / 0.8 kW controls = {P/800:,.0f}")
# bench point and sweep rows
for (Thx, pHx) in ((463.15, 6.5133e5), (453.15, 7.0133e5)):
    s_ = [x for x in SW if abs(x['Th'] - Thx) < 1e-6 and abs(x['pH'] - pHx) < 1]
    Ein1 = L0['Pliq'] + L0['eaux']
    print(f"    sweep {Thx:.2f} K, {pHx/1e5:.4f} bar a: COP_a {P/(s_[0]['tot']+L0['leak']+Ein1):.4f}; COP_b {P/Ein1:,.1f}")
for x in SW:
    x['cop_a'] = P/(x['tot'] + L0['leak'] + L0['Pliq'] + L0['eaux'])
print("    sweep COP_a by row: " + "; ".join(f"{x['Th']:.2f}/{x['pH']/1e5:.4f} {x['cop_a']:.4f}" for x in SW))
# options table
Ein1 = L0['Pliq'] + L0['eaux']
for k in ('F', 'R', 'H', 'Hs'):
    o = OPT[k]
    print(f"    option {k}: COP_a {P/(o['tot'] + L0['leak'] + Ein1):.4f}; COP_b {P/Ein1:,.1f}")
print(f"    open cycle: COP_b {P/(openE + L0['eaux']):.3f}")
print(f"    electric MVR shaft instead: COP_b {P/(Ein1 + OPT['H']['W']):.2f}; COP_a {P/(OPT['H']['tot'] - OPT['H']['Qmvr'] + L0['leak'] + Ein1 + OPT['H']['W']):.4f}")
print(f"    sensitivity (Table 13p), heat-led: " + "; ".join(f"eps {e:.4f} COP_a {P/(h_ + Ein1):.4f}" for (e, Qun, h_, nh, ne) in SENS))
print(f"    sensitivity, electric lift: " + "; ".join(f"eps {e:.4f} COP_b {P/(Ein1 + Qun*w_lift_e):.2f}" for (e, Qun, h_, nh, ne) in SENS))
print(f"    published electric re-liquefaction 0.15-0.25 kWh/kg: COP_b {P/(Ein1 + bo_res*0.15*3.6e6):.3f}-{P/(Ein1 + bo_res*0.25*3.6e6):.3f}")
# flow anchors (r13 law): both COPs
print("    flow anchors (r13 law, booked H, N = 1):")
for lab, m in (("0.038 kg/s", 0.038), ("1000 kg/h", 1000/3600), ("582.336 kg/s", md)):
    Lc = closed(m); k = Lc['P']/P
    Ein_m = Lc['Pliq'] + Lc['eaux']
    print(f"      {lab:13s}: P {Lc['P']/1e3:,.2f} kW; E_in {Ein_m/1e3:,.3f} kW; waste heat {k*OPT['H']['tot']/1e3:,.2f} kW; COP_a {Lc['P']/(k*OPT['H']['tot'] + Ein_m):.4f}; COP_b {Lc['P']/Ein_m:,.2f}")
for row in TAB13A:
    El = row[0]
    print(f"    Table 13a E_lift {El/1e6:4.0f} MW: COP_a design {P/(row[1]+L0['leak']+Ein1+El):.4f}, sizing {P/(row[2]+L0['leak']+Ein1+El):.4f}; COP_b {P/(Ein1+El):.2f}")
# ---- (5) Earth and space operational cases ----
print("(5) operational cases, one module:")
SEC_space = 0.05*3600e3                          # J/kg: v7 Table 8 space cold-side fill 0.05 kWh/kg
Pliq_sp = mmu*SEC_space
Ein_sp = Pliq_sp + L0['eaux']
eps_r = 0.9
def area(Q, T): return Q/(eps_r*sb*(T**4 - 2.7**4))
eng_rej = OPT['H']['Qmvr'] - OPT['H']['W']
A_cold = area(OPT['H']['Qc'], Tc); A_eng = area(eng_rej, 300.0)
heat_sp_H = OPT['H']['Qh'] + OPT['H']['Qmvr'] + L0['leak']
A_R = area(OPT['R']['Qc'], C2['TsL']); heat_sp_R = OPT['R']['Qh'] + L0['leak']
print(f"    Earth (300 K air): waste heat {(OPT['H']['tot']+L0['leak'])/1e6:,.2f} MW; heat to air {Q_amb/1e6:,.2f} MW (+ vent {vent_hot_amb/1e6:.3f} MW); E_in {Ein1/1e6:.3f} MW_e; "
      f"COP_a {P/(OPT['H']['tot']+L0['leak']+Ein1):.4f}; COP_b {P/Ein1:,.1f}")
print(f"    Space (2.7 K sink), MVR + radiate residual at 77.35 K: heat {heat_sp_H/1e6:,.2f} MW; radiator {A_cold/1e6:,.2f} km2 at 77.35 K + {A_eng/1e6:,.3f} km2 at 300 K for the MVR engine's {eng_rej/1e6:.2f} MW; "
      f"makeup {Pliq_sp/1e6:.3f} MW_e at 0.05 kWh/kg; E_in {Ein_sp/1e6:.3f} MW_e; COP_a {P/(heat_sp_H+Ein_sp):.4f}; COP_b {P/Ein_sp:,.1f}")
print(f"    Space, passive re-condenser radiating {OPT['R']['Qc']/1e6:.2f} MW at {C2['TsL']:.2f} K: radiator {A_R/1e6:,.2f} km2; heat {heat_sp_R/1e6:,.2f} MW; COP_a {P/(heat_sp_R+Ein_sp):.4f}; COP_b {P/Ein_sp:,.1f}")
print(f"    record's net space liquefaction 0.01-0.02 kWh/kg: makeup {mmu*0.01*3.6e6/1e6:.3f}-{mmu*0.02*3.6e6/1e6:.3f} MW_e")
SPACE = dict(Pliq=Pliq_sp, Ein=Ein_sp, A_cold=A_cold, A_eng=A_eng, heatH=heat_sp_H, A_R=A_R, heatR=heat_sp_R)
# ---- r16 audit ----
if os.path.exists(md_path):
    txt = open(md_path, encoding="utf-8").read()
    need16 = {"vamb": f"{vent_hot_amb/1e6:.3f} MW", "copa1": f"{COP[('booked (H)',1)]['a']:.4f}", "copb1": f"{COP[('booked (H)',1)]['b']:,.1f}",
              "copb1000": f"{COP[('booked (H)',1000)]['b']:,.1f}", "strip": f"{P/E_strip:,.0f}", "Acold": f"{A_cold/1e6:,.2f} km²",
              "copbsp": f"{P/Ein_sp:,.1f}", "Tstart": f"{T_ext_start:.2f} K"}
    bad = [k for k, v in need16.items() if v not in txt]
    print("AUDIT r16:", f"PASS - all {len(need16)} r16 values present" if not bad else f"MISSING {[(k, need16[k]) for k in bad]}")
    for stale in ("vent draws from the ullage", "inside the 29.07 MW floor", "leaves inside the 29.07 MW"):
        print(f"AUDIT r16 stale vent phrase '{stale}':", txt.count(stale))

# =====================================================================================================================
# ==== r17 (Morgan 29 Oct 2026, 10:03-10:04): what scales the output further - levers ranked by exponent            ====
# =====================================================================================================================
print("\n=================== r17 WHAT SCALES THE OUTPUT FURTHER (Morgan 10:03-10:04) ===================")
from math import pi as _pi
sig, rpm, r, h, d, B, K = 14000.0, 200000, 0.093, 0.4, 0.002, 5.0, 0.65   # v7 worked ring (line 10 of this script)
def Pring(sig_=sig, rpm_=rpm, r_=r, h_=h, d_=d, B_=B, K_=K):
    v_ = rpm_*2*_pi/60*r_
    return sig_*(v_*B_)**2*K_*(1-K_)*2*_pi*r_*h_*d_
P0r = Pring()
print(f"ring equation check: P = {P0r/1e6:.2f} MW at sigma {sig:.0f} S/m, {rpm:,} rpm, r {r*1e3:.0f} mm, h {h} m, delta {d*1e3:.0f} mm, B {B} T, K {K}")
LEV = {}
for name, kw, expo in (("B", dict(B_=B*1.1), 2), ("rpm", dict(rpm_=rpm*1.1), 2), ("r", dict(r_=r*1.1), 3),
                       ("sigma", dict(sig_=sig*1.1), 1), ("h", dict(h_=h*1.1), 1), ("delta", dict(d_=d*1.1), 1)):
    g = Pring(**kw)/P0r - 1; LEV[name] = g
    print(f"  lever {name:6s}: P ~ x^{expo}; +10 % -> {g:+.2%} ({Pring(**kw)/1e6:.2f} MW)")
gK = Pring(K_=K*1.1)/P0r - 1; gKopt = Pring(K_=0.5)/P0r - 1
print(f"  lever K (load factor, K = {K}): K(1-K) = {K*(1-K):.4f}; +10 % (K {K*1.1:.3f}) -> {gK:+.2%}; -10 % (K {K*0.9:.3f}) -> {Pring(K_=K*0.9)/P0r-1:+.2%}; at the optimum K = 0.5 -> {gKopt:+.2%} (max {Pring(K_=0.5)/1e6:.2f} MW)")
for name, b in (("mdot (P)", b_P), ("mdot (sigma)", b_sig), ("mdot (rpm)", b_rpm)):
    print(f"  flow law {name}: exponent {b:.4f}; +10 % flow -> {1.1**b-1:+.2%}")
v_tip = rpm*2*_pi/60*r
rho_cfrp = 1600.0                                 # kg/m3 [r18: published, records 18916931 and 20031552]
print(f"  rim: tip speed {v_tip:,.1f} m/s; thin-ring hoop stress rho v^2 = {rho_cfrp*v_tip**2/1e9:.2f} GPa (rho {rho_cfrp:.0f} kg/m3 assumed); +10 % rpm or r -> {rho_cfrp*(1.1*v_tip)**2/1e9:.2f} GPa (+21.00 %)")
print(f"  gap motional voltage v B delta = {v_tip*B*d:.2f} V (+10 % B or delta -> {v_tip*B*d*1.1:.2f} V); N2 Paschen minimum ~275 V [assumed, literature]")
# feed temperature / pressure: heat per unit output at fixed P
s_b = [x for x in SW if abs(x['Th']-463.15) < 1e-6 and abs(x['pH']-6.5133e5) < 1][0]
s_0 = [x for x in SW if abs(x['Th']-453.15) < 1e-6 and abs(x['pH']-7.0133e5) < 1][0]
print(f"  feed 463.15 K / 6.5133 bar a vs 453.15 K / 7.0133 bar a: heat {s_b['tot']/1e6:,.2f} vs {s_0['tot']/1e6:,.2f} MW ({s_b['tot']/s_0['tot']-1:+.2%}); "
      f"P per unit heat {s_0['tot']/s_b['tot']-1:+.2%}; P unchanged (ring equation has no T term)")
# recovery: heat-led P unchanged; heat per module
print(f"  recovery fraction: P unchanged; heat per module {OPT['R']['tot']/1e6:,.2f} MW (eps 0) -> {OPT['H']['tot']/1e6:,.2f} MW (MVR) -> {OPT['F']['tot']/1e6:,.2f} MW (floor); modules per unit site heat x{OPT['R']['tot']/OPT['H']['tot']:.2f} (R->H), x{OPT['H']['tot']/OPT['F']['tot']:.2f} (H->floor)")
# fleet N: COP_e; site heat
for N in (1, 10, 100, 1000):
    print(f"  N {N:4d}: COP_e {COP[('booked (H)',N)]['b']:.1f} (cap {P/(L0['eaux']+ret_H):.1f})")
Qmod = OPT['H']['tot'] + L0['leak']
for site in (1e9, 10e9, 100e9):
    print(f"  site heat {site/1e9:.0f} GW -> N = {site/Qmod:.2f} modules (booked {Qmod/1e6:,.2f} MW each) -> {int(site//Qmod)*P/1e6:,.2f} MW gross; on the floor N = {site/(OPT['F']['tot']+L0['leak']):.2f}")
print(f"  +10 % site heat -> +10.00 % modules and output (P ~ N)")
if os.path.exists(md_path):
    txt = open(md_path, encoding="utf-8").read()
    need17 = {"r": f"{LEV['r']:+.2%}", "B": f"{LEV['B']:+.2%}", "K": f"{gK:+.2%}", "Kopt": f"{gKopt:+.2%}",
              "flow": f"{1.1**b_P-1:+.2%}", "hoop": f"{rho_cfrp*v_tip**2/1e9:.2f} GPa", "gapV": f"{v_tip*B*d:.2f} V",
              "feed": f"{s_0['tot']/s_b['tot']-1:+.2%}", "site": f"{1e9/Qmod:.2f}"}
    need17 = {k: (v.replace('%', ' %').replace('-', '−') if v.endswith('%') else v) for k, v in need17.items()}
    need17["site"] = f"{10e9/Qmod:.2f}"
    bad = [k for k, v in need17.items() if v not in txt]
    print("AUDIT r17:", f"PASS - all {len(need17)} r17 values present" if not bad else f"MISSING {[(k, need17[k]) for k in bad]}")

# ---------------- r18: positive N2 chamber pressure lever and published rim-stress envelope ----------------
print("\n=== r18: pressure lever and published rim-stress envelope ===")
pa0, pa1 = 7.0133, 9.0133                         # bar a: working 6 bar g (published 5.5-6) and band top 8 bar g (published 3-8 bar g, 21682741)
kp = 0.85                                         # n_e ~ p^0.85: programme code exponent (V6P, local) inside the published 0.7-1.0 (21682741)
fp = (pa1/pa0)**kp
print(f"  pressure 6 -> 8 bar g ({pa0} -> {pa1} bar a, x{pa1/pa0:.4f}): n_e x{(pa1/pa0)**0.7:.4f} to x{pa1/pa0:.4f} (published p^0.7-1.0); code p^0.85 -> sigma x{fp:.4f} ({fp-1:+.2%})")
print(f"  pressure +10 %: sigma and P x{1.1**kp:.4f} ({1.1**kp-1:+.2%}) at fixed rpm [headroom inside the band; the 6 bar g working point is already inside sigma_high = 14,000 S/m]")
sb_ult = (5.5e9, 7.0e9); relief = 0.497e9         # 20031552 Table 1: sigma_ult 5.5-7.0 GPa; Maxwell relief 0.497 GPa at 5 T, t 2 mm, r 0.1 m (r19: comment corrected)
def hoop(rpm_, r_): return rho_cfrp*(rpm_*2*_pi/60*r_)**2
for r_ in (0.1, r):
    hs = hoop(rpm, r_)
    print(f"  r {r_*1e3:.0f} mm, {rpm:,} rpm: rho v^2 = {hs/1e9:.2f} GPa; net of relief {(hs-relief)/1e9:.2f} GPa; SF {sb_ult[0]/(hs-relief):.2f} (5.5 GPa) to {sb_ult[1]/(hs-relief):.2f} (7.0 GPa)")
print(f"  check vs 20031552: r 100 mm, 120,000 rpm -> {hoop(120000,0.1)/1e9:.2f} GPa (published 2.53 GPa)")
def rpm_at(SF, r_, ult=7.0e9): return ((ult/SF + relief)/(rho_cfrp*r_**2))**0.5*60/(2*_pi)
for r_ in (0.1, r):
    print(f"  r {r_*1e3:.0f} mm: continuous SF 2 -> {rpm_at(2, r_):,.0f} rpm; burst SF 1 -> {rpm_at(1, r_):,.0f} rpm (7.0 GPa, 5 T relief)")
rc = rpm_at(2, r)
RS = {}
for rr in (120000, 150000, rc, 180000, rpm):
    a = Pring(rpm_=rr); b2 = Pring(rpm_=rr, sig_=sig*fp)
    RS[rr] = (a, b2)
    print(f"  {rr:,.0f} rpm: hoop {hoop(rr, r)/1e9:.2f} GPa (SF {7.0e9/(hoop(rr,r)-relief):.2f} at 7.0 GPa); P {a/1e6:.2f} MW at 6 bar g; {b2/1e6:.2f} MW at 8 bar g (sigma {sig*fp:,.0f} S/m)")
need_s = sig*(rpm/150000)**2
print(f"  to hold {P0r/1e6:.2f} MW at 150,000 rpm: sigma {need_s:,.0f} S/m (x{(rpm/150000)**2:.4f}); by p^0.85 that needs {pa0*((rpm/150000)**2)**(1/kp):.2f} bar a = {pa0*((rpm/150000)**2)**(1/kp)-1.0133:.2f} bar g (outside the published 3-8 bar g)")
Pm = Pring(sig_=16100, rpm_=250000, B_=8.0, K_=0.5)
print(f"  v4 mastery envelope (every amplifier at the top of its range; mastery assumption): sigma 16,100 S/m, 250,000 rpm, 8 T, K 0.5 -> {Pm/1e6:.2f} MW; hoop {hoop(250000,r)/1e9:.2f} GPa (above the 7.0 GPa ultimate)")
if os.path.exists(md_path):
    txt = open(md_path, encoding="utf-8").read()
    f2 = lambda x: f"{x:,.2f}"
    need18 = {"fp": f"{fp-1:+.2%}", "p10": f"{1.1**kp-1:+.2%}", "hoop100": f"{hoop(rpm,0.1)/1e9:.2f} GPa",
              "net": f"{(hoop(rpm,r)-relief)/1e9:.2f} GPa", "SFlo": f"{sb_ult[0]/(hoop(rpm,r)-relief):.2f}", "SFhi": f"{sb_ult[1]/(hoop(rpm,r)-relief):.2f}",
              "rc100": f"{rpm_at(2,0.1):,.0f}", "rc": f"{rc:,.0f}", "burst": f"{rpm_at(1,r):,.0f}",
              "P150": f2(RS[150000][0]/1e6), "P150p": f2(RS[150000][1]/1e6), "Prc": f2(RS[rc][0]/1e6), "Prcp": f2(RS[rc][1]/1e6),
              "P180": f2(RS[180000][0]/1e6), "P180p": f2(RS[180000][1]/1e6), "P120": f2(RS[120000][0]/1e6),
              "sig8": f"{sig*fp:,.0f}", "needs": f"{need_s:,.0f}", "needp": f"{pa0*((rpm/150000)**2)**(1/kp)-1.0133:.2f}", "Pm": f2(Pm/1e6)}
    need18 = {k: (v.replace('%', ' %').replace('-', '−') if v.endswith('%') else v) for k, v in need18.items()}
    wd18 = {k: need18.pop(k) for k in ("net", "Prc", "Prcp")}   # r19: 93 mm envelope values withdrawn (stress taken on the 0.1 m sleeve)
    print("AUDIT r18 withdrawn in r19 (93 mm envelope):", wd18, "| still in text:", [k for k, v in wd18.items() if v in txt] or "none")
    bad = [k for k, v in need18.items() if v not in txt]
    print("AUDIT r18:", f"PASS - all {len(need18)} remaining r18 values present" if not bad else f"MISSING {[(k, need18[k]) for k in bad]}")

# ---------------- r19: the RPM Explainer (20031552 / 20025405) read in full: physical rpm on the 0.1 m CFRP sleeve ----------------
print("\n=== r19: rim stress on the published 0.1 m sleeve (RPM Explainer and 4xModule code) ===")
mu0 = 4*_pi*1e-7
def relief_x(B_=5.0, t_=0.002, r_=0.1): return B_**2/(2*mu0)*r_/t_        # 4xModule code magnetic_relief(): P_mag * r / t
rs = 0.1                                                                 # published sleeve outer radius (Explainer section 2; 4xModule self.r = 0.1)
for B_, t_ in ((2.0, 0.010), (2.0, 0.005), (5.0, 0.002)):
    print(f"  relief B {B_} T, t {t_*1e3:.0f} mm: {relief_x(B_, t_)/1e9:.3f} GPa (published 0.016 / 0.032 / 0.497)")
rel = relief_x(); print(f"  relief on the 93 mm ring by the same formula: {relief_x(r_=r)/1e9:.3f} GPa (r18 applied 0.497)")
v_s = rpm*2*_pi/60*rs; hs = rho_cfrp*v_s**2
print(f"  200,000 rpm physical, r 100 mm: tip {v_s:,.1f} m/s; rho v^2 = {hs/1e9:.2f} GPa; net {(hs-rel)/1e9:.2f} GPa; SF {5.5e9/(hs-rel):.2f} (5.5 GPa) to {7.0e9/(hs-rel):.2f} (7.0 GPa)")
def rpm_s(SF, ult=7.0e9): return ((ult/SF + rel)/(rho_cfrp*rs**2))**0.5*60/(2*_pi)
rcs, rbs = rpm_s(2), rpm_s(1)
print(f"  envelope on the sleeve: continuous SF 2 {rcs:,.0f} rpm (published 150,938); burst {rbs:,.0f} rpm (published 206,712); 200,000 rpm is {1-rpm/rbs:.2%} below burst")
for rr in (120000, 150938, 180000):
    hh = rho_cfrp*(rr*2*_pi/60*rs)**2
    print(f"  {rr:,} rpm: sleeve {hh/1e9:.2f} GPa, SF {7.0e9/(hh-rel):.2f} (7.0 GPa), {5.5e9/(hh-rel):.2f} (5.5 GPa); ring P {Pring(rpm_=rr)/1e6:.2f} MW at 6 bar g, {Pring(rpm_=rr, sig_=sig*fp)/1e6:.2f} MW at 8 bar g")
need_c = sig*(rpm/150938)**2
print(f"  to hold {P0r/1e6:.2f} MW at 150,938 rpm: sigma {need_c:,.0f} S/m (x{(rpm/150938)**2:.4f}); by p^0.85 {pa0*((rpm/150938)**2)**(1/kp)-1.0133:.2f} bar g (outside 3-8 bar g)")
hh2 = hs/2
print(f"  half-formula check (Design Spec 18363156 'rho w^2 r^2 / 2 <= 3 GPa'; also the AI-discussion code, unpublished): 200,000 rpm, r 100 mm -> {hh2/1e9:.2f} GPa, net {(hh2-rel)/1e9:.2f} GPa, SF {7.0e9/(hh2-rel):.2f} (7.0 GPa); not adopted: the Explainer's Eq. 2 and Table 1 use rho w^2 r^2 (thin ring), which reproduces 2.53 GPa at 120,000 rpm")
print(f"  4xModule code: 92 kW/module net at 120,000 rpm (368 kW for 4); power scales linearly with rpm in that code")
if os.path.exists(md_path):
    txt = open(md_path, encoding="utf-8").read()
    h15 = rho_cfrp*(150938*2*_pi/60*rs)**2; h18 = rho_cfrp*(180000*2*_pi/60*rs)**2
    need19 = {"tip": f"{v_s:,.1f} m/s", "hs": f"{hs/1e9:.2f} GPa", "net": f"{(hs-rel)/1e9:.2f} GPa", "SFlo": f"{5.5e9/(hs-rel):.2f}", "SFhi": f"{7.0e9/(hs-rel):.2f}",
              "rcs": f"{rcs:,.0f}", "rbs": f"{rbs:,.0f}", "below": f"{1-rpm/rbs:.2%}".replace('%',' %'), "rel93": f"{relief_x(r_=r)/1e9:.3f} GPa",
              "P15": f"{Pring(rpm_=150938)/1e6:,.2f}", "P15p": f"{Pring(rpm_=150938, sig_=sig*fp)/1e6:,.2f}", "SF18": f"{7.0e9/(h18-rel):.2f}",
              "needc": f"{need_c:,.0f}", "needpc": f"{pa0*((rpm/150938)**2)**(1/kp)-1.0133:.2f}", "h15": f"{h15/1e9:.2f} GPa", "half": f"{hh2/1e9:.2f} GPa", "halfSF": f"{7.0e9/(hh2-rel):.2f}"}
    bad = [k for k, v in need19.items() if v not in txt]
    print("AUDIT r19:", f"PASS - all {len(need19)} r19 values present" if not bad else f"MISSING {[(k, need19[k]) for k in bad]}")

# ---------------- r20: forward derivation of every rotor/stress mitigation, combined (Morgan 10:56-11:02) ----------------
print("\n=== r20: how the mitigations make the rotor buildable (forward derivation, no target) ===")
W = lambda rpm_: rpm_*2*_pi/60
RPM = lambda w_: w_*60/(2*_pi)
nu = 0.3                                   # Poisson ratio [assumed, typical for a hoop-wound CFRP / Ti-Be; not in the records]
ult_hi, ult_lo = 7.0e9, 5.5e9              # published 20031552 (ring-burst validated); 19171590 overwrap 5-7 GPa
B0, t0 = 5.0, 0.002                        # published 20031552 Table 1 row 3
p_gas = 0.8e6                              # 8 bar g top of the published 3-8 bar g band (21682741)
s_pre = (50e6, 100e6, 150e6)               # overwrap winding pre-tension 50-150 MPa (19171590); mid used in the stack
g_cold = 1.12                              # 2.7 K strength gain: 4xModule code titan_strength_gain (20031552); Explainer text 10-15 %
R = {}
# (1) rotating thin ring
v200 = W(rpm)*rs
R['ring200'] = rho_cfrp*v200**2
print(f"(1) thin ring: element mass dm = rho h t r dtheta; centripetal force dm w^2 r = 2 sigma h t sin(dtheta/2) -> sigma = rho w^2 r^2 = rho v^2")
print(f"    200,000 rpm: w = {W(rpm):,.1f} rad/s; v = w r = {v200:,.1f} m/s; sigma = {R['ring200']/1e9:.2f} GPa; check 120,000 rpm -> {rho_cfrp*(W(120000)*rs)**2/1e9:.2f} GPa (published 2.53)")
c_solid = (3+nu)/8; c_bore = (3+nu)/4
print(f"    Lame, solid disc centre: (3+nu)/8 rho v^2 = {c_solid:.4f} rho v^2 = {c_solid*R['ring200']/1e9:.2f} GPa; disc with a small bore: (3+nu)/4 = {c_bore:.4f} rho v^2 = {c_bore*R['ring200']/1e9:.2f} GPa (x{c_bore/c_solid:.0f} solid)")
print(f"    Design Spec rho w^2 r^2 / 2 = {R['ring200']/2e9:.2f} GPa = solid-disc formula with nu = 1 ((3+1)/8 = 0.5): a disc result, not a sleeve result")
print(f"    +10 % r or rpm on the sleeve: {R['ring200']*1.21/1e9:.2f} GPa (Table 13y, r20 review)")
# (2) magnetic pressure relief
Pm5 = B0**2/(2*mu0)
print(f"(2) magnetic pressure P_mag = B^2/(2 mu0) = {B0}^2/(2 x {mu0:.4e}) = {Pm5/1e6:.3f} MPa at 5 T; inward on the sleeve, thin-wall hoop sigma = P r / t")
for B_, t_ in ((5.0, 0.002), (5.0, 0.005), (5.0, 0.010), (2.0, 0.010), (8.0, 0.002)):
    print(f"    B {B_} T, t {t_*1e3:.0f} mm: P_mag {B_**2/(2*mu0)/1e6:.3f} MPa x r/t {rs/t_:.0f} = relief {relief_x(B_, t_)/1e9:.3f} GPa")
print(f"    relief per unit allowable: d(rpm)/rpm = 0.5 x relief / (sigma_allow + relief)")
# (3) overwrap pre-tension and material
for sp_ in s_pre:
    print(f"(3) pre-tension {sp_/1e6:.0f} MPa left in the sleeve: allowable rho v^2 = ult/SF + relief - pre; radial pressure on the core and N52 column p = pre x t/r = {sp_*t0/rs/1e6:.1f} MPa (compression)")
for ult_, rho_ in ((5.5e9, 1600), (7.0e9, 1600)):
    print(f"    specific strength ult/rho = {ult_/rho_/1e6:.3f} MJ/kg -> burst tip speed sqrt(ult/rho) = {(ult_/rho_)**0.5:,.1f} m/s; burst rpm (no relief) {RPM((ult_/rho_)**0.5/rs):,.0f}")
pc_sens = 10e6*rs/t0
print(f"    core/magnet contact pressure (not modelled in the records): each 10 MPa adds {pc_sens/1e9:.2f} GPa of sleeve hoop stress (p r/t)")
# (4) shaftless
print(f"(4) shafted rotor: bore/keyway Kt >= 2 (20031552 s.7) -> peak 2 rho v^2; allowable rpm x 1/sqrt(2) = x{1/2**0.5:.4f}; shaftless ring Kt = 1 recovers x{2**0.5:.4f}")
# (5) gas pressure
gas_rel = p_gas*rs/t0
print(f"(5) chamber gas 8 bar g on the sleeve outer face: p r/t = {gas_rel/1e9:.3f} GPa ({gas_rel/R['ring200']:.2%} of the 200,000 rpm hoop stress; zero if the same pressure acts inside) [one-sided bound, assumed]")
for pg in (3, 4, 5, 6, 7, 8):
    f_ = ((pg+1.0133)/pa0)**kp
    print(f"    {pg} bar g: sigma x{f_:.4f} = {sig*f_:,.0f} S/m (p^0.85 code law, local; published n_e ~ p^0.7-1.0)")
# (6) thermal
print(f"(6) CFRP rated 200 C, < 150 C in operation, rotor surface < 60 C, inlet 453 K +/- 1 K held by the AI oracle (18916931): no strength-temperature curve is published, so no derating is applied")
print(f"    2.7 K: strength x{g_cold} (code) -> ult {ult_hi*g_cold/1e9:.2f} GPa")
# (7) combined stack
def allow_rpm(ult, SF, rel=0.0, gas=0.0, pre=0.0, Kt=1.0):
    return RPM(((ult/SF + rel + gas - pre)/Kt/(rho_cfrp*rs**2))**0.5)
STK = [("A  thin CFRP ring, 7.0 GPa, shafted (Kt 2), for comparison", dict(Kt=2.0)),
       ("B  shaftless distributed-force ring (Kt 1)", {}),
       ("C  + ReBCO magnetic relief, 5 T, t 2 mm", dict(rel=relief_x(B0, t0))),
       ("D  + overwrap pre-tension 100 MPa (core in compression)", dict(rel=relief_x(B0, t0), pre=100e6)),
       ("E  + chamber gas 8 bar g, one-sided", dict(rel=relief_x(B0, t0), pre=100e6, gas=gas_rel)),
       ("F  + 2.7 K strength x1.12 (space only)", dict(rel=relief_x(B0, t0), pre=100e6, gas=gas_rel, ult=ult_hi*g_cold))]
STAB = []
for name, kw in STK:
    ult_ = kw.pop('ult', ult_hi)
    row = [name]
    for SF in (2.0, 1.5):
        rr = allow_rpm(ult_, SF, **kw); row += [rr, Pring(rpm_=rr, sig_=sig*fp)]
    rb = allow_rpm(ult_, 1.0, **kw); row += [rb]
    STAB.append(row)
    print(f"  {name:60s}: SF2 {row[1]:,.0f} rpm, P {row[2]/1e6:,.2f} MW | SF1.5 {row[3]:,.0f} rpm, P {row[4]/1e6:,.2f} MW | burst {rb:,.0f} rpm (P at 8 bar g, sigma {sig*fp:,.0f} S/m)")
print(f"  checks: 120,000 rpm -> {rho_cfrp*(W(120000)*rs)**2/1e9:.2f} GPa; C at SF 2 = {allow_rpm(ult_hi,2,rel=relief_x()):,.0f} rpm; C burst = {allow_rpm(ult_hi,1,rel=relief_x()):,.0f} rpm")
# forward combined Earth point: stack E at SF 2 and SF 1.5; flow through the r13 chain
def m_for(Pt):
    lo, hi = 1e-4, 1e5
    for _ in range(200):
        mid = (lo*hi)**0.5
        if P_of(mid) < Pt: lo = mid
        else: hi = mid
    return mid
FWD = {}
for SF in (2.0, 1.5):
    rr = allow_rpm(ult_hi, SF, rel=relief_x(), pre=100e6, gas=gas_rel)
    Pf = Pring(rpm_=rr, sig_=sig*fp); mf = m_for(Pf); Lf = closed(mf); k = Lf['P']/P
    Ein_f = Lf['Pliq'] + Lf['eaux']; Qf = k*OPT['H']['tot']
    hs_f = rho_cfrp*(W(rr)*rs)**2
    FWD[SF] = dict(rpm=rr, P=Pf, m=mf, Ein=Ein_f, Q=Qf, cop_a=Pf/(Qf+Ein_f), cop_b=Pf/Ein_f, hs=hs_f, net=hs_f-relief_x()-gas_rel+100e6, site=10e9/(Qf+k*L0['leak']))
    f = FWD[SF]
    print(f"  FORWARD Earth point SF {SF}: {rr:,.0f} rpm; sleeve tip {W(rr)*rs:,.1f} m/s; hoop {hs_f/1e9:.2f} GPa; sigma {sig*fp:,.0f} S/m; P {Pf/1e6:,.2f} MW; "
          f"r13 flow {mf:,.2f} kg/s; E_in {Ein_f/1e6:.3f} MW_e; waste heat {Qf/1e6:,.2f} MW; COP_th {f['cop_a']:.4f}; COP_e {f['cop_b']:.1f}; 10 GW site -> {f['site']:.2f} modules")
Pc = Pring(rpm_=150938)
print(f"  gap motional voltage at the SF 2 forward point: v B delta = {W(FWD[2.0]['rpm'])*r*B*d:.2f} V on the {r*1e3:.0f} mm ring")
print(f"  comparison row: v7 worked point 200,000 rpm, 141.22 MW, sleeve SF {7.0e9/(R['ring200']-relief_x()):.2f}")
# field loop: B raises P (B^2) and the allowable w^2 (relief ~ B^2)
for B_ in (5.0, 6.0, 8.0):
    rr = allow_rpm(ult_hi, 2.0, rel=relief_x(B_), pre=100e6, gas=gas_rel)
    print(f"  field loop B {B_} T: relief {relief_x(B_)/1e9:.3f} GPa -> SF2 {rr:,.0f} rpm; P {Pring(rpm_=rr, sig_=sig*fp, B_=B_)/1e6:,.2f} MW [5 T published; above 5 T magnet margin not shown in the records]")
# plot
try:
    import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
    figd = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'r20_figs'); os.makedirs(figd, exist_ok=True)
    lab = [x[0][:1] for x in STAB]
    fig, ax = plt.subplots(1, 2, figsize=(10, 3.6))
    xs = range(len(STAB))
    ax[0].bar([x-0.2 for x in xs], [x[1]/1e3 for x in STAB], 0.4, label='SF 2'); ax[0].bar([x+0.2 for x in xs], [x[3]/1e3 for x in STAB], 0.4, label='SF 1.5')
    ax[0].plot(xs, [x[5]/1e3 for x in STAB], 'k_', ms=18, label='burst'); ax[0].axhline(200, ls='--', c='grey', label='v7 200k')
    ax[0].set_xticks(list(xs)); ax[0].set_xticklabels(lab); ax[0].set_ylabel('allowable rpm (thousands)'); ax[0].legend(fontsize=7); ax[0].set_title('Rotor speed, mitigations stacked A-F')
    ax[1].bar([x-0.2 for x in xs], [x[2]/1e6 for x in STAB], 0.4, label='SF 2'); ax[1].bar([x+0.2 for x in xs], [x[4]/1e6 for x in STAB], 0.4, label='SF 1.5')
    ax[1].axhline(P/1e6, ls='--', c='grey', label='v7 worked point (comparison)')
    ax[1].set_xticks(list(xs)); ax[1].set_xticklabels(lab); ax[1].set_ylabel('ring P at 8 bar g (MW)'); ax[1].legend(fontsize=7); ax[1].set_title('Output at the allowable speed')
    fig.tight_layout(); fig.savefig(os.path.join(figd, 'rotor_mitigation_stack_r20.png'), dpi=130); print("  plot: r20_figs/rotor_mitigation_stack_r20.png")
except Exception as e:
    print("  plot skipped:", e)
# ---- r20 (Morgan 11:03): cost against output, relative units (no prices in the records) ----
print("\n=== r20: cost vs output scaling (relative mass / volume units, derived) ===")
v_al = lambda SF: ((ult_hi/SF + relief_x() + gas_rel - 100e6)/rho_cfrp)**0.5
print(f"  stress-limited tip speed v_allow = sqrt((ult/SF + relief + gas - pre)/rho): SF 2 {v_al(2):,.1f} m/s; SF 1.5 {v_al(1.5):,.1f} m/s")
print(f"  at the stress limit w r = v_allow, so Eq. 4 becomes P = sigma (v_allow B)^2 K(1-K) 2 pi r h delta: P ~ sigma B^2 v_allow^2 r h delta (r enters once, not three times)")
m_sl = rho_cfrp*2*_pi*rs*t0*h
U_gap = Pm5*2*_pi*r*h*d
print(f"  sleeve mass rho 2 pi r t h = {m_sl:.3f} kg; gap field energy B^2/(2 mu0) x 2 pi r h delta = {U_gap:,.1f} J")
Pf2 = FWD[2.0]['P']
print(f"  per MW at the SF 2 forward point: sleeve {m_sl/(Pf2/1e6)*1e3:.2f} g/MW; gap field energy {U_gap/(Pf2/1e6):.2f} J/MW")
# exponents: output a, cost b, output per cost a-b
EXPS = [("chamber pressure p (sigma ~ p^0.85; vessel wall t_w = p R / sigma_w, mass ~ p)", kp, 1.0),
        ("field B (P ~ B^2; magnet field energy ~ B^2)", 2.0, 2.0),
        ("ring height h (P ~ h; sleeve, magnet, vessel mass ~ h; bearings, controls fixed)", 1.0, 1.0),
        ("gap delta (P ~ delta; field volume ~ delta)", 1.0, 1.0),
        ("radius r at fixed rpm (P ~ r^3; sleeve ~ r; stress ~ r^2)", 3.0, 1.0),
        ("radius r at the stress limit (P ~ r; core and magnet mass ~ r^2)", 1.0, 2.0),
        ("flow mdot (P ~ mdot^0.9441; pump, LN2 generator, radiator ~ mdot)", b_P, 1.0),
        ("fleet N (P ~ N; shared vent, tank, AI per chain)", 1.0, 1.0)]
for n_, a_, b_ in EXPS:
    print(f"  {n_}: output exponent {a_:.4f}; cost exponent {b_:.4f}; output per cost {a_-b_:+.4f}")
# compounding: +10 % on each stress-free lever (sigma via p, h, delta, B with relief), multiplicative
gains = {"p": 1.1**kp, "h": 1.1, "delta": 1.1}
vB = ((ult_hi/2 + relief_x(B0*1.1) + gas_rel - 100e6)/rho_cfrp)**0.5/v_al(2)
gains["B (incl. relief)"] = 1.1**2*vB**2
tot = 1.0
for k_, g_ in gains.items():
    tot *= g_; print(f"  +10 % {k_}: x{g_:.4f}; cumulative x{tot:.4f}")
c_items = {"sleeve (h)": 1.1, "pressure vessel (p x h)": 1.1*1.1, "magnet field energy (B^2 x h x delta)": 1.1**2*1.1*1.1}
for k_, c_ in c_items.items(): print(f"  cost item {k_}: x{c_:.4f}")
cmin, cmax = min(c_items.values()), max(c_items.values())
print(f"  compounded output x{tot:.4f}; module cost grows between x{cmin:.4f} and x{cmax:.4f} (each item only with its own drivers; shared bearings, controls, AI fixed); output per cost x{tot/cmax:.4f} to x{tot/cmin:.4f}: a product of power laws (multiplicative growth), not exponential")
# fleet COP_e(N)
for N in (1, 10, 100, 1000):
    print(f"  fleet N {N:4d}: output {N*P/1e6:,.2f} MW (v7 point); COP_e {COP[('booked (H)',N)]['b']:.1f}; output per unit electricity cost rises toward the cap {P/(L0['eaux']+ret_H):.1f} (saturating, ~N/(a + bN), not exponential)")
try:
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(1, 2, figsize=(10, 3.6))
    import numpy as np
    sc = np.linspace(1, 3, 50)
    for lab_, a_, b_ in (("pressure p", kp, 1.0), ("field B", 2.0, 2.0), ("height h", 1.0, 1.0), ("flow mdot", b_P, 1.0)):
        ax[0].plot(sc, sc**a_, label=f"output, {lab_} (^{a_:.2f})"); ax[0].plot(sc, sc**(a_-b_), ls=':', label=f"output/cost, {lab_}")
    ax[0].set_xlabel('lever scale factor'); ax[0].set_ylabel('relative'); ax[0].legend(fontsize=6); ax[0].set_title('Output and output per cost (power laws)')
    Ns = [1, 10, 100, 1000]
    ax[1].loglog(Ns, [N*P/1e6 for N in Ns], 'o-', label='fleet output (MW)')
    ax[1].loglog(Ns, [N*P/COP[('booked (H)',N)]['b']/1e6 for N in Ns], 's-', label='fleet electricity in (MW_e)')
    ax[1].loglog(Ns, [COP[('booked (H)',N)]['b'] for N in Ns], '^-', label='COP_e (output per electricity)')
    ax[1].set_xlabel('modules N'); ax[1].legend(fontsize=7); ax[1].set_title('Fleet scaling')
    fig.tight_layout(); fig.savefig(os.path.join(figd, 'cost_vs_output_r20.png'), dpi=130); print("  plot: r20_figs/cost_vs_output_r20.png")
except Exception as e:
    print("  plot skipped:", e)
if os.path.exists(md_path):
    txt = open(md_path, encoding="utf-8").read()
    need20 = {"solid": f"{c_solid*R['ring200']/1e9:.2f} GPa", "bore": f"{c_bore*R['ring200']/1e9:.2f} GPa", "Pm5": f"{Pm5/1e6:.3f} MPa",
              "gas": f"{gas_rel/1e9:.3f} GPa", "A2": f"{STAB[0][1]:,.0f}", "B2": f"{STAB[1][1]:,.0f}", "D2": f"{STAB[3][1]:,.0f}", "E2": f"{STAB[4][1]:,.0f}",
              "E15": f"{STAB[4][3]:,.0f}", "F2": f"{STAB[5][1]:,.0f}", "PE2": f"{STAB[4][2]/1e6:,.2f}", "PE15": f"{STAB[4][4]/1e6:,.2f}",
              "copb2": f"{FWD[2.0]['cop_b']:.1f}", "copa2": f"{FWD[2.0]['cop_a']:.4f}", "m2": f"{FWD[2.0]['m']:,.2f}", "vSF2": f"{v_al(2):,.1f} m/s", "tot": f"{tot:.4f}", "opc": f"{tot/cmax:.4f}", "msl": f"{m_sl:.3f} kg", "r10": f"{R['ring200']*1.21/1e9:.2f} GPa", "vg": f"{W(FWD[2.0]['rpm'])*r*B*d:.2f} V"}
    bad = [k for k, v in need20.items() if v not in txt]
    print("AUDIT r20:", f"PASS - all {len(need20)} r20 values present" if not bad else f"MISSING {[(k, need20[k]) for k in bad]}")

# =====================================================================================================
# r21 (Morgan 29 Oct 11:15, 11:18, 11:19): book the module as the PUBLISHED design books it.
#  - no electric pumps: the shared tank head + waste-heat expansion pressurise the loop (18916931, v4 #87 19171590);
#    the physics minimum head work is booked against waste heat (reversible engine; the 0.40 ORC factor is not from the design)
#  - electricity in = the published parasitic bundle "below 0.8 kW per module" (18916931; includes liquefaction, self-pump,
#    AI-oracle control); v7 Book 1 strip 11.7 W shown; v7 Book 2 (4.61 MW at 0.55 kWh/kg) kept as v7 keeps it: a separate book, never added
#  - makeup re-liquefied by the heat-led generator at the published 0.207 kWh/kg minimum / published eta_II 0.5175 [9]
#  - cold-end lift at the published refrigeration eta_II 0.5175 [9], heat engine reversible (no published engine factor)
#  - rotor: the published envelope (20031552) 150,938 rpm at SF 2 (171,556 at SF 1.5); pre-tension and gas terms are our
#    additions and are shown as tagged sensitivities only
# =====================================================================================================
print("\n=== r21: published-design booking (no added lines); thermal head; COP_e and COP_th ===")
import CoolProp.CoolProp as _C
p_tank = 101325.0
dp_loss = 0.0                                     # Pa, r21 (Morgan 11:30): no loss allowance booked (open question Q1)
p_ch = {6: 7.01325e5, 8: 9.01325e5}
psat_crit = _C.PropsSI('pcrit', 'N2')                # r22: N2 critical pressure 33.958 bar a (was saturation at the rounded 126.19 K)
w_gas8 = R_N2*453.15*_ln(p_ch[8]/p_tank)
E_pub = 0.8e3                                     # W, published bundle ceiling (18916931)
E_book1 = 11.7                                    # W, v7 Book 1 strip
lift_pub = (Ta/Tc - 1)/(eII_ref_hi*eta_h)         # W heat per W lifted: published eta_II, reversible engine
w_mk = w_min_kg/eII_ref_hi*3.6e6                  # J/kg = 0.40 kWh/kg
print(f"  lift factor: published eta_II {eII_ref_hi:.4f}, reversible engine -> {lift_pub:.3f} W/W (r15-r20 used x eII_eng 0.40: {lift_per_W:.2f} W/W)")
print(f"  gas expansion 8 bar g to the tank: PR {p_ch[8]/p_tank:.3f}, R T ln(PR) at 453.15 K = {w_gas8/1e3:.1f} kJ/kg; N2 critical {psat_crit/1e5:.2f} bar a")
print(f"  makeup liquefaction work {w_mk/3.6e6:.3f} kWh/kg ({w_min_kg} / {eII_ref_hi:.4f}) from waste heat at eta_h {eta_h:.4f}")
def book21(m, Pm, space=False):
    k = Pm/P
    dp = p_ch[8] + dp_loss - p_tank
    Wp = m*dp/rho_L
    Tsat = _C.PropsSI('T', 'P', p_ch[8] + dp_loss, 'Q', 0, 'N2')
    Qc = Pm*Tc/(Th - Tc)
    Qlift = 0.0 if space else Qc*lift_pub
    Qhead = Wp/eta_h
    mmu_ = (1 - eta_reg)*m
    Qmk = mmu_*(0.05*3.6e6 if space else w_mk)/eta_h      # space: v7 Table 8 published 0.05 kWh/kg
    Qrad = Qc if space else 0.0
    Q = Pm + Qc + Qlift + k*L0['leak']            # r21 (Morgan 11:30): head heat (Q2) and makeup heat (Q3) not booked; open questions
    return dict(m=m, P=Pm, Wp=Wp, dp=dp, Tsat=Tsat, ratio=(psat_crit - p_tank)/dp, gasr=w_gas8/(dp/rho_L), Qc=Qc, Qlift=Qlift,
                Qhead=Qhead, mmu=mmu_, Qmk=Qmk, Q=Q, cope=Pm/E_pub, cope1=Pm/E_book1, copth=Pm/(Q + E_pub),
                site=10e9/Q, A=area(Qc, Tc) if space else 0.0, cope_ai=Pm/(E_pub + 0.02*Pm))
# ---- r21 (Morgan 11:28): ONE integrated module model, coupled loops solved together to a fixed point ----
# unknowns: chamber pressure p, sigma, rotor speed, P, flow m, thermal-head saturation T, loop heat books
# couplings: p -> sigma (n_e ~ p^0.85, published band) and the thermal head (T_sat(p)); B -> relief -> envelope rpm;
# sigma, rpm -> P (Eq. 4); P -> m = P / w_exp (v7 Eq. 6, ring expansion 6:1 at the AI-held 453.15 K inlet);
# m -> head need and recirculation/makeup (eta_reg); P -> cold-end rejection -> heat-led generator lift.
def solve_module(SF, space=False, p_g=8.0, tol=1e-12, itmax=100):
    p = (pa1 if p_g == 8.0 else p_g + 1.0133)*1e5; P_ = P; m_ = md; it = 0     # bar a as in the code (8 bar g = 9.0133 bar a)
    for it in range(1, itmax + 1):
        fp_ = (p/1e5/pa0)**kp
        rpm_ = allow_rpm(ult_hi, SF, rel=relief_x())
        P_new = Pring(rpm_=rpm_, sig_=sig*fp_)
        m_new = P_new/w_exp
        Tsat_ = _C.PropsSI('T', 'P', p, 'Q', 0, 'N2')          # liquid leg temperature the waste heat must reach to hold p
        p_new = _C.PropsSI('P', 'T', Tsat_, 'Q', 0, 'N2')       # thermal head delivers p (closes the pressure loop)
        res = max(abs(P_new - P_)/P_new, abs(m_new - m_)/m_new, abs(p_new - p)/p)
        P_, m_, p = P_new, m_new, p_new
        if res < tol: break
    return dict(P=P_, m=m_, p=p, rpm=rpm_, sig=sig*fp_, Tsat=Tsat_, it=it, res=res)
INT = {k: solve_module(*v) for k, v in {2.0: (2.0,), 1.5: (1.5,)}.items()}
for k, v in INT.items():
    print(f"  INTEGRATED fixed point SF {k}: {v['it']} iterations, residual {v['res']:.1e}; p {v['p']/1e5:.4f} bar a; sigma {v['sig']:,.0f} S/m; "
          f"{v['rpm']:,.0f} rpm; P {v['P']/1e6:,.2f} MW; m = P/w_exp {v['m']:,.2f} kg/s (r13 flow-law value {m_for(v['P']):,.2f}, not used); T_sat {v['Tsat']:.2f} K")
R21 = {}
for SF in (2.0, 1.5):
    rr = allow_rpm(ult_hi, SF, rel=relief_x())
    Pf = INT[SF]['P']; mf = INT[SF]['m']
    R21[SF] = book21(mf, Pf); R21[SF]['rpm'] = rr; R21[SF]['tip'] = W(rr)*rs; R21[SF]['hs'] = rho_cfrp*(W(rr)*rs)**2
    R21[SF]['dpre'] = Pring(rpm_=allow_rpm(ult_hi, SF, rel=relief_x(), pre=100e6), sig_=sig*fp) - Pf
    R21[SF]['dgas'] = Pring(rpm_=allow_rpm(ult_hi, SF, rel=relief_x(), gas=gas_rel), sig_=sig*fp) - Pf
    R21[SF]['s07'] = Pf*((pa1/pa0)**0.7/fp); R21[SF]['s10'] = Pf*((pa1/pa0)**1.0/fp)
R21['v7'] = book21(md, P)
R21['space'] = book21(R21[2.0]['m'], R21[2.0]['P'], space=True)
R21['space15'] = book21(R21[1.5]['m'], R21[1.5]['P'], space=True)
for key in (2.0, 1.5, 'v7', 'space', 'space15'):
    x = R21[key]
    lab = {2.0: "Earth SF 2 (published envelope)", 1.5: "Earth SF 1.5", 'v7': "v7 point (comparison)", 'space': "space SF 2", 'space15': "space SF 1.5"}[key]
    extra = f"{x['rpm']:,.0f} rpm, tip {x['tip']:,.1f} m/s, hoop {x['hs']/1e9:.2f} GPa; " if 'rpm' in x else ""
    print(f"  {lab}: {extra}P {x['P']/1e6:,.2f} MW; flow {x['m']:,.2f} kg/s")
    print(f"    head need m dp/rho = {x['Wp']/1e6:.4f} MW (dp {x['dp']/1e5:.2f} bar: 8 bar g, no loss allowance); thermal head T_sat {x['Tsat']:.2f} K; ceiling x{x['ratio']:.2f}; gas expansion x{x['gasr']:,.0f}; "
          f"head heat if booked {x['Qhead']/1e6:.3f} MW (not booked, Q2)")
    print(f"    reject at 77.35 K {x['Qc']/1e6:,.2f} MW; lift heat {x['Qlift']/1e6:,.2f} MW; makeup {x['mmu']:.3f} kg/s (heat if booked {x['Qmk']/1e6:.3f} MW; not booked, Q3); waste heat total {x['Q']/1e6:,.2f} MW"
          + (f"; radiator {x['A']/1e6:,.2f} km2 at 77.35 K (eps 0.9 assumed)" if x['A'] else ""))
    print(f"    E_in {E_pub/1e3:.1f} kW_e (published bundle); COP_e {x['cope']:,.0f} (Book 1 strip {x['cope1']:,.0f}); with AI 2 % {x['cope_ai']:.1f}; COP_th {x['copth']:.4f}; 10 GW site {x['site']/1:.2f} modules")
for SF in (2.0, 1.5):
    x = R21[SF]
    print(f"  sensitivities SF {SF}: pre-tension 100 MPa {x['dpre']/1e6:+.2f} MW; one-sided gas {x['dgas']/1e6:+.2f} MW; p-exponent 0.7 / 1.0: {x['s07']/1e6:,.2f} / {x['s10']/1e6:,.2f} MW (0.85 local: {x['P']/1e6:,.2f})")
x = R21[2.0]
Q40 = x['P'] + x['Qc'] + x['Qc']*lift_per_W + (x['P']/P)*L0['leak']
print(f"  open questions, effect if booked at SF 2 (NOT booked): head heat {x['Qhead']/1e6:.3f} MW + makeup heat {x['Qmk']/1e6:.3f} MW -> COP_th {x['P']/(x['Q']+x['Qhead']+x['Qmk']+E_pub):.4f}; 1 bar loss allowance adds {x['m']*1e5/rho_L/1e6:.4f} MW head work ({x['m']*1e5/rho_L/eta_h/1e6:.3f} MW heat)")
print(f"  effect of the non-design ORC factor 0.40 (r15-r20): waste heat {Q40/1e6:,.2f} MW, COP_th {x['P']/(Q40+E_pub):.4f} (not booked)")
print(f"  each extra bar of loop loss at SF 2: {R21[2.0]['m']*1e5/rho_L/eta_h/1e6:.3f} MW waste heat")
FL21 = {}
for N in (1, 10, 100, 1000):
    nAI = -(-N//100)
    Q = N*x['Q']
    FL21[N] = dict(Q=Q, Ein=N*E_pub, cope=N*x['P']/(N*E_pub), copth=N*x['P']/(Q + N*E_pub), ai=N*x['P']/(N*E_pub + nAI*0.02*x['P']))
    f = FL21[N]
    print(f"  fleet SF 2 N {N:4d}: E_in {f['Ein']/1e3:,.1f} kW_e; waste heat {Q/1e6:,.2f} MW; COP_e {f['cope']:,.0f}; with AI 2 % per 100 modules {f['ai']:,.1f}; COP_th {f['copth']:.4f}")
v21 = W(R21[2.0]['rpm'])*rs
print(f"  cost section on the published envelope: v_allow {v21:,.1f} m/s (SF 2), {W(R21[1.5]['rpm'])*rs:,.1f} m/s (SF 1.5); sleeve {m_sl*1e3/(R21[2.0]['P']/1e6):.2f} g/MW; field {4650.0/(R21[2.0]['P']/1e6):.2f} J/MW")
print(f"  gap motional voltage at SF 2: {W(R21[2.0]['rpm'])*r*B*d:.2f} V on the 93 mm ring, against > 10 kV/mm published (18382317)")
print("  plainly: the electricity in is the published 0.8 kW per module, not zero; COP_e is large and finite and does not change with N")
if os.path.exists(md_path):
    txt = open(md_path, encoding="utf-8").read()
    a, b, s = R21[2.0], R21[1.5], R21['space']
    need21 = {"Wp2": f"{a['Wp']/1e6:.4f} MW", "Wp15": f"{b['Wp']/1e6:.4f} MW", "Tsat": f"{a['Tsat']:.2f} K", "ratio": f"{a['ratio']:.2f}",
              "Qh": f"{a['Qhead']/1e6:.3f} MW", "Qmk": f"{a['Qmk']/1e6:.3f} MW", "Wv7": f"{R21['v7']['Wp']/1e6:.4f} MW", "Qs15": f"{R21['space15']['Q']/1e6:,.2f} MW", "Q2": f"{a['Q']/1e6:,.2f} MW", "Q15": f"{b['Q']/1e6:,.2f} MW",
              "ce2": f"{a['cope']:,.0f}", "ce15": f"{b['cope']:,.0f}", "ct2": f"{a['copth']:.4f}", "ct15": f"{b['copth']:.4f}",
              "cts": f"{s['copth']:.4f}", "m2": f"{a['m']:,.2f}", "m15": f"{b['m']:,.2f}", "site": f"{a['site']:.2f}",
              "ai1000": f"{FL21[1000]['ai']:,.1f}", "q40": f"{a['P']/(Q40+E_pub):.4f}"}
    bad = [k_ for k_, v in need21.items() if v not in txt]
    print("AUDIT r21:", f"PASS - all {len(need21)} r21 values present" if not bad else f"MISSING {[(k_, need21[k_]) for k_ in bad]}")

# =====================================================================================================
# ---- r22 (Morgan 11:45): holistic rebuild on the integrated model; answers to the r21 questions ----
# Rules kept (Morgan 11:30): published design only; nothing that lowers output or COP is booked unless it is
# in the published design; anything else is a question with its effect stated.
# =====================================================================================================
import json as _json
print("\n=== r22 (Morgan 11:45): thermodynamic pump, vent before the J-T HX, AI check, pressure sweep, field upgrade, train ===")
whirl1 = 276000.0                                  # rpm, first critical whirling speed (18916931 Giga Factory V10)
PR_stage, gam = 1.3, 1.4                           # published per-stage expansion ratio and dT ~33 K/stage (18916931 s.6)
band_dist, band_ai = 0.05, 0.005                   # published: +-5 % disturbances; AI active -> <0.5 % fluctuation (18916931)
N_chain = 100                                      # modules per chain (published [2])
T_gen = Tc                                         # generator condensing temperature 77.35 K (published cold end)
p_suct = _C.PropsSI('P', 'T', T_gen, 'Q', 0, 'N2')  # generator suction (condensing) pressure
B_eng, B_rec_lo, B_rec_hi = 20.0, 15.0, 23.0       # 20.1 T REBCO TFMC at 20 K (MIT/CFS 2021, IEEE TAS 2023); records 15-23 T (FAQ, v4 #49)
q_ybco = 41e4                                      # N/m2, hybrid YBCO bearing lifting capacity >41 N/cm2 at 77 K (Weinberger 1991, APL 59, 1132)
G_bal = 0.4e-3                                     # m/s, ISO 1940 G0.4 balancing (<0.4 mm/s residual), published 18916931 s.5
# r22c: the r22 1 % eccentricity (unpublished) is withdrawn; the symmetric 4-stator field is centring (20031552: azimuthal symmetry)
rho_Ti = 4506.0                                    # kg/m3 titanium (public); Ti-Be core density not published (bearing sizing only)
def solve22(SF, B_=5.0, p_g=8.0, k_=kp, tol=1e-12):
    """integrated fixed point: p -> sigma, T_sat (thermal head); B -> relief -> rpm; sigma, rpm, B -> P; P -> m (v7 Eq. 6) -> head."""
    p = (pa1 if p_g == 8.0 else p_g + 1.0133)*1e5; P_ = 1.0; m_ = 1.0; it = 0
    for it in range(1, 101):
        rpm_ = allow_rpm(ult_hi, SF, rel=relief_x(B_))
        P_new = Pring(rpm_=rpm_, sig_=sig*(p/1e5/pa0)**k_, B_=B_)
        m_new = P_new/w_exp
        Ts = _C.PropsSI('T', 'P', p, 'Q', 0, 'N2') if p < psat_crit else float('nan')
        p_new = _C.PropsSI('P', 'T', Ts, 'Q', 0, 'N2') if p < psat_crit else p
        res = max(abs(P_new - P_)/P_new, abs(m_new - m_)/m_new, abs(p_new - p)/p)
        P_, m_, p = P_new, m_new, p_new
        if res < tol: break
    head = m_*max(p - p_tank, 0.0)/rho_L
    Qc = P_*Tc/(Th - Tc); Ql = Qc*lift_pub; leak = (P_/P)*L0['leak']
    Q = P_ + Qc + Ql + leak
    hoop = rho_cfrp*(W(rpm_)*rs)**2
    return dict(P=P_, m=m_, p=p, rpm=rpm_, Tsat=Ts, head=head, Qhead=head/eta_h, Qc=Qc, Ql=Ql, Q=Q, it=it, res=res,
                copth=P_/(Q + E_pub), cope=P_/E_pub, copth_s=P_/(P_ + Qc + leak + E_pub), A=area(Qc, Tc), hoop=hoop,
                rel=relief_x(B_), stand=relief_x(B_), quenchSF=ult_hi/hoop, whirl=rpm_/whirl1)
# (1) the thermodynamic pump: head from tank pressure (waste heat) to generator suction; train with reset
S5 = {SF: solve22(SF) for SF in (2.0, 1.5)}
a = S5[2.0]
dp_need = p_ch[8] - p_suct
dp_avail = psat_crit - p_suct
T_out = Th/PR_stage**((gam - 1)/gam)
p_out = p_ch[8]/PR_stage
p_rh = p_out*Th/T_out                              # isochoric waste-heat reset back to 453.15 K
dp_top = p_ch[8] - p_rh                            # what the tank head restores before the next module
share_head = a['Qhead']/a['Q']
print(f"  (1) pump: generator suction at {T_gen} K = {p_suct/1e5:.4f} bar a; tank at T_sat {a['Tsat']:.2f} K holds {p_ch[8]/1e5:.4f} bar a; need {dp_need/1e5:.2f} bar; "
      f"available up to the N2 critical point {dp_avail/1e5:.2f} bar (x{dp_avail/dp_need:.2f})")
print(f"      per module: inlet {p_ch[8]/1e5:.4f} bar a, 453.15 K -> stage PR {PR_stage} -> {p_out/1e5:.4f} bar a, {T_out:.2f} K (dT {Th - T_out:.2f} K) -> "
      f"waste-heat reset to 453.15 K at constant volume -> {p_rh/1e5:.4f} bar a -> tank head restores {dp_top/1e5:.4f} bar to {p_ch[8]/1e5:.4f} bar a")
print(f"      head work {a['head']/1e6:.4f} MW = waste heat {a['Qhead']/1e6:.3f} MW drawn inside the booked {a['Q']/1e6:,.2f} MW ({share_head:.3%}); no new line")
TR = {}
for SF in (2.0, 1.5):
    x = S5[SF]
    TR[SF] = dict(P=N_chain*x['P'], Pd_lo=N_chain*x['P']*(1 - band_dist)**kp, Pd_hi=N_chain*x['P']*(1 + band_dist)**kp,
                  Pai_lo=N_chain*x['P']*(1 - band_ai), Pai_hi=N_chain*x['P']*(1 + band_ai), rms=N_chain*x['P']*band_ai/3**0.5/N_chain**0.5,
                  Q=N_chain*x['Q'], m=N_chain*x['m'], E=N_chain*E_pub)
    t = TR[SF]
    print(f"      train SF {SF}, {N_chain} modules: {t['P']/1e9:,.4f} GW; unregulated +-5 % pressure -> {t['Pd_lo']/1e9:,.4f}-{t['Pd_hi']/1e9:,.4f} GW; "
          f"AI band +-0.5 % -> {t['Pai_lo']/1e9:,.4f}-{t['Pai_hi']/1e9:,.4f} GW (independent modules, uniform band: 1 sigma {t['rms']/1e6:,.2f} MW); "
          f"waste heat {t['Q']/1e9:,.3f} GW; E_in {t['E']/1e3:,.0f} kW; COP_th {t['P']/(t['Q']+t['E']):.4f}; COP_e {t['P']/t['E']:,.0f}")
# (2) vent before the J-T HX
mv = (1 - eta_reg)*a['m']; cpN = 1040.0
print(f"  (2) vent: {mv:.3f} kg/s at the end of the loop, before the J-T HX; at 453.15 K (r16) it gives {mv*cpN*(Th - Ta)/1e6:.3f} MW to the 300 K air; "
      f"at the published final-module exhaust 243 K it would take {mv*cpN*(Ta - 243.0)/1e6:.3f} MW from the air (question V1; not booked either way)")
# (3) AI: records check (printed in the text); booking unchanged
print(f"  (3) AI: 18916931 Appendix 1 #32 '2-10% of net' = {0.02*a['P']/1e6:.2f}-{0.10*a['P']/1e6:.2f} MW at SF 2; 18916931 GFV10 235 kW / 15,800 = {235e3/15800:.1f} W on-site per module; "
      f"18925333 parasitics ~0.73 kW of the 0.8 kW (liquefaction). Booked: E_in 0.8 kW; AI a question (A1)")
# (4) pressure sweep
PG = [0, 2, 3, 4, 5, 6, 7, 8, 10, 12, 15, 20, 25, 30, 32.9]
SW = {}
for pg in PG:
    for k_ in (0.7, 0.85, 1.0):
        SW[(pg, k_)] = solve22(2.0, p_g=pg, k_=k_)
for pg in PG:
    x7, x8, x1 = SW[(pg, 0.7)], SW[(pg, 0.85)], SW[(pg, 1.0)]
    print(f"  sweep {pg:5.1f} bar g ({x8['p']/1e5:.4f} bar a): P {x7['P']/1e6:,.2f} / {x8['P']/1e6:,.2f} / {x1['P']/1e6:,.2f} MW (k 0.7/0.85/1.0); rpm {x8['rpm']:,.0f}; "
          f"flow {x8['m']:,.2f} kg/s; head {x8['head']/1e6:.4f} MW; T_sat {x8['Tsat']:.2f} K; COP_th {x8['copth']:.4f}; COP_e {x8['cope']:,.0f}")
# (5) field upgrade
B_fix = {SF: (ult_hi/SF*2*mu0*t0/rs)**0.5 for SF in (2.0, 1.5)}     # standstill: relief (compressive) <= ult/SF with the field held
B_q119 = 5.0*((ult_hi/1.19 - ult_hi/2.0)/relief_x(5.0))**0.5      # keeps the published SF 1.19 if the field is lost at speed
B_op = 13.0
FB = {}
for B_ in (5, 6, 8, 10, B_q119, 12, B_op, B_fix[2.0], 15, 20, 23):
    FB[B_] = solve22(2.0, B_=B_)
for B_, x in FB.items():
    print(f"  field {B_:6.2f} T SF 2: relief {x['rel']/1e9:.3f} GPa; {x['rpm']:,.0f} rpm ({x['whirl']:.1%} of whirl); hoop {x['hoop']/1e9:.3f} GPa; P {x['P']/1e6:,.2f} MW; "
          f"flow {x['m']:,.1f} kg/s; standstill compressive {x['stand']/1e9:.3f} GPa; field-loss SF {x['quenchSF']:.3f}")
U = {SF: solve22(SF, B_=B_op) for SF in (2.0, 1.5)}
gain_avg = (U[2.0]['P'] - a['P'])/(B_op - 5.0)
dB = 1e-4; gain5 = (solve22(2.0, B_=5.0 + dB)['P'] - solve22(2.0, B_=5.0 - dB)['P'])/(2*dB)
gain13 = (solve22(2.0, B_=B_op + dB)['P'] - solve22(2.0, B_=B_op - dB)['P'])/(2*dB)
print(f"  field limits: fixed-field standstill B <= {B_fix[2.0]:.2f} T (SF 2), {B_fix[1.5]:.2f} T (SF 1.5); field-loss SF 1.19 needs B <= {B_q119:.2f} T; "
      f"engineering 20.1 T at 20 K (TFMC); records 15-23 T")
print(f"  gain per tesla SF 2: dP/dB {gain5/1e6:,.2f} MW/T at 5 T, {gain13/1e6:,.2f} MW/T at {B_op:.0f} T; average 5->{B_op:.0f} T {gain_avg/1e6:,.2f} MW/T")
m_core = rho_Ti*pi*(r - d)**2*h; m_rot = m_core + m_sl; Wrot = m_rot*9.80665
def bear(B_, rpm_):                                 # r22c: bearing load = rotor weight + ISO G0.4 rotating imbalance m*G*omega; net magnetic side load 0 (symmetric, centring)
    w_ = W(rpm_); F_ = Wrot + m_rot*G_bal*w_; e_ = G_bal/w_
    pull = B_**2/(2*mu0)*(2*r*h)*e_/d               # bound: pull at the G0.4 runout if it were NOT centring (shown only)
    return dict(F=F_, A=F_/q_ybco, imb=m_rot*G_bal*w_, e=e_, pull=pull, m400=400.0/(9.80665 + G_bal*w_))
BR = {k: bear(k, solve22(2.0, B_=k)['rpm']) for k in (5.0, B_q119, B_op)}
A_end = pi*(r - d)**2                                # end face inside the plasma channel, per end
# Morgan 12:35 (B1): 'go for a higher superconductor N' -> keep the assumed rotor, up-rate the dual bearings: rating = 1.5 x (worst load, 13 T), rounded up to 50 N [margin 1.5 assumed]
R_up = 50*math.ceil(1.5*BR[B_op]['F']/50); A_up = R_up/q_ybco
print(f"  B1 up-rated dual YBCO rating {R_up:,.0f} N (published 400 N, x{R_up/400:.2f}); margin {R_up/BR[5.0]['F']:.2f} / {R_up/BR[B_q119]['F']:.2f} / {R_up/BR[B_op]['F']:.2f} at 5 / 10.94 / 13 T; face {A_up*1e4:.1f} cm2 total = {A_up/2*1e4:.1f} cm2 per end vs {A_end*1e4:.1f} cm2; passive 0 W")
for k, v in BR.items():
    print(f"  bearing at {k:.2f} T: rotor {m_rot:.2f} kg [assumed] ({Wrot:,.0f} N) + G0.4 imbalance {v['imb']:,.0f} N = {v['F']:,.0f} N -> YBCO area {v['A']*1e4:.1f} cm2 at 41 N/cm2 "
          f"(end faces {A_end*1e4:.1f} cm2 per end: fits); runout {v['e']*1e6:.4f} um; pull bound if not centring {v['pull']:.1f} N; published 400 N holds for rotor <= {v['m400']:.1f} kg")
for SF in (2.0, 1.5):
    x = U[SF]
    print(f"  UPGRADE {B_op:.0f} T SF {SF}: {x['rpm']:,.0f} rpm; tip {W(x['rpm'])*rs:,.1f} m/s; hoop {x['hoop']/1e9:.3f} GPa (net {x['hoop']/1e9 - x['rel']/1e9:.3f}); P {x['P']/1e6:,.2f} MW; "
          f"flow {x['m']:,.2f} kg/s; head {x['head']/1e6:.4f} MW; waste heat {x['Q']/1e6:,.2f} MW; COP_th {x['copth']:.4f}; COP_e {x['cope']:,.0f}; "
          f"space COP_th {x['copth_s']:.4f}, radiator {x['A']/1e6:,.2f} km2; field-loss SF {x['quenchSF']:.3f}; whirl {x['whirl']:.1%}")
    print(f"    train {N_chain}: {N_chain*x['P']/1e9:,.3f} GW (AI band {N_chain*x['P']*(1-band_ai)/1e9:,.3f}-{N_chain*x['P']*(1+band_ai)/1e9:,.3f} GW)")
# channel velocity check (question C1)
A_ann = 2*pi*r*d; rho_g = p_ch[8]/(R_N2*Th)
print(f"  flow-path check: {a['m']:,.2f} kg/s through the 2 mm x 93 mm annulus ({A_ann*1e4:.2f} cm2) at {rho_g:.2f} kg/m3 would need {a['m']/(rho_g*A_ann):,.0f} m/s; flow-path area not published (question C1)")
# figures
try:
    import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(7.5, 4.2))
    for k_, st in ((0.7, '--'), (0.85, '-'), (1.0, ':')):
        ax.plot(PG, [SW[(pg, k_)]['P']/1e6 for pg in PG], st, marker='o', ms=3, label=f"n_e ~ p^{k_}")
    ax.axvspan(3, 8, color='0.85', label='published band 3-8 bar g')
    ax.axvline(32.945, color='k', lw=0.8); ax.text(32.5, 20, 'N2 critical\n(tank ceiling)', ha='right', fontsize=7)
    ax.set_xlabel('chamber pressure, bar g'); ax.set_ylabel('P per module, MW (SF 2, 5 T)'); ax.legend(fontsize=7); ax.grid(alpha=0.3)
    ax.set_title('r22 pressure sweep (rotor envelope 150,938 rpm at every pressure)', fontsize=9)
    fig.tight_layout(); fig.savefig(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'r22_figs', 'pressure_sweep_r22.png'), dpi=150); plt.close(fig)
    BB = [5 + 0.25*i for i in range(73)]
    fig, ax = plt.subplots(figsize=(7.5, 4.2))
    ax.plot(BB, [solve22(2.0, B_=b)['P']/1e6 for b in BB], label='SF 2, 8 bar g')
    for v_, lab in ((B_q119, 'field-loss SF 1.19'), (B_fix[2.0], 'fixed-field standstill (SF 2)'), (20.0, '20 T REBCO, 20 K (TFMC)')):
        ax.axvline(v_, ls='--', lw=0.8); ax.text(v_, 200, lab, rotation=90, fontsize=7, va='bottom')
    ax.plot([B_op], [U[2.0]['P']/1e6], 'ko'); ax.set_xlabel('field B, T'); ax.set_ylabel('P per module, MW'); ax.grid(alpha=0.3)
    ax.set_title('r22 field ladder: P with the magnetic relief in the stress envelope', fontsize=9); ax.legend(fontsize=7)
    fig.tight_layout(); fig.savefig(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'r22_figs', 'field_ladder_r22.png'), dpi=150); plt.close(fig)
    print("  figures: r22_figs/pressure_sweep_r22.png, r22_figs/field_ladder_r22.png")
except Exception as e_:
    print("  figures not drawn:", e_)
R22 = dict(S5={str(k): v for k, v in S5.items()}, U={str(k): v for k, v in U.items()}, TR={str(k): v for k, v in TR.items()},
           SW={f"{pg}|{k_}": v for (pg, k_), v in SW.items()}, FB={f"{k:.4f}": v for k, v in FB.items()},
           lim=dict(B_fix2=B_fix[2.0], B_fix15=B_fix[1.5], B_q119=B_q119, gain5=gain5, gain13=gain13, gain_avg=gain_avg,
                    dp_need=dp_need, dp_avail=dp_avail, p_suct=p_suct, p_out=p_out, T_out=T_out, p_rh=p_rh, dp_top=dp_top, share_head=share_head,
                    m_rot=m_rot, A5=BR[5.0]['A'], A1094=BR[B_q119]['A'], A13=BR[B_op]['A'], F5=BR[5.0]['F'], F1094=BR[B_q119]['F'], F13=BR[B_op]['F'], imb5=BR[5.0]['imb'], imb13=BR[B_op]['imb'], pull13=BR[B_op]['pull'], m400_5=BR[5.0]['m400'], m400_13=BR[B_op]['m400'], A_end=A_end, R_up=R_up, A_up=A_up, mg5=R_up/BR[5.0]['F'], mg1094=R_up/BR[B_q119]['F'], mg13=R_up/BR[B_op]['F'], mv=mv,
                    vent453=mv*cpN*(Th - Ta), vent243=mv*cpN*(Ta - 243.0), v_ann=a['m']/(rho_g*A_ann), B_op=B_op))
_json.dump(R22, open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'r23_results_20261029.json'), 'w'), indent=1, default=float)
if os.path.exists(md_path):
    txt = open(md_path, encoding="utf-8").read()
    u, u15 = U[2.0], U[1.5]
    need22 = {"Pu": f"{u['P']/1e6:,.2f} MW", "Pu15": f"{u15['P']/1e6:,.2f} MW", "rpmu": f"{u['rpm']:,.0f} rpm", "cpu": f"{u['cope']:,.0f}",
              "tr": f"{TR[2.0]['P']/1e9:,.4f} GW", "trlo": f"{TR[2.0]['Pai_lo']/1e9:,.4f}", "trhi": f"{TR[2.0]['Pai_hi']/1e9:,.4f}",
              "Bfix": f"{B_fix[2.0]:.2f} T", "Bq": f"{B_q119:.2f} T", "g5": f"{gain5/1e6:,.2f} MW/T", "gavg": f"{gain_avg/1e6:,.2f} MW/T",
              "dpa": f"{dp_avail/1e5:.2f} bar", "top": f"{dp_top/1e5:.4f} bar", "share": f"{share_head:.3%}",
              "p0": f"{SW[(0, 0.85)]['P']/1e6:,.2f}", "p329": f"{SW[(32.9, 0.85)]['P']/1e6:,.2f}", "A13": f"{BR[B_op]['A']*1e4:.1f} cm²", "A5": f"{BR[5.0]['A']*1e4:.1f}", "A1094": f"{BR[B_q119]['A']*1e4:.1f}",
              "qsf": f"{u['quenchSF']:.3f}", "v243": f"{mv*cpN*(Ta - 243.0)/1e6:.3f} MW"}
    bad = [k_ for k_, v in need22.items() if v not in txt]
    print("AUDIT r22:", f"PASS - all {len(need22)} r22 values present" if not bad else f"MISSING {[(k_, need22[k_]) for k_ in bad]}")

# ---- r22b (Morgan 12:14): electrical input books; cluster-level AI Heat-Grid Oracle paid from output ----
print("\n=== r22b: electrical input books and the cluster-level oracle ===")
N_cl = 100                                          # modules per cluster/chain (published [2]; 23.5 MW per 100-module cluster, 18916931)
T_ai = 333.15                                       # K, oracle coolant heat 60 C (data-centre band 40-80 C [3]; v7 10.2 central value) [assumed band]
def vap_duty(x):                                    # vaporiser duty per module: liquid at T_sat(p) -> gas at the oracle heat temperature
    p_ = p_ch[8]
    return x['m']*(_C.PropsSI('H', 'T', T_ai, 'P', p_, 'N2') - _C.PropsSI('H', 'P', p_, 'Q', 0, 'N2'))
CL = {}
for lab, x in (("5 T SF 2", S5[2.0]), ("5 T SF 1.5", S5[1.5]), ("13 T SF 2", U[2.0])):
    vd = vap_duty(x)
    for f in (0.0, 0.02, 0.10):
        Pai = f*N_cl*x['P']; Qret = 0.95*Pai
        net = N_cl*x['P'] - Pai
        CL[(lab, f)] = dict(Pai=Pai, Qret=Qret, net=net, cope_net=net/(N_cl*E_pub), cope_in=N_cl*x['P']/(N_cl*E_pub + Pai),
                            Qext=N_cl*x['Q'] - Qret, copth=net/(N_cl*x['Q'] - Qret + N_cl*E_pub), vshare=Qret/(N_cl*vd), vd=vd)
        c = CL[(lab, f)]
        print(f"  cluster {lab}, oracle {f:.0%}: oracle {Pai/1e6:,.2f} MW; heat returned {Qret/1e6:,.2f} MW ({c['vshare']:.2%} of the vaporiser duty {N_cl*vd/1e6:,.1f} MW); "
              f"net delivered {net/1e9:,.4f} GW; COP_e (oracle paid from output) {c['cope_net']:,.0f}; COP_e (oracle counted as input) {c['cope_in']:,.1f}; "
              f"external waste heat {c['Qext']/1e9:,.4f} GW; COP_th (net) {c['copth']:.4f}")
print(f"  the returned heat cannot raise P (P is set by the rotor envelope, sigma and B); it replaces external waste heat in the vaporiser 1:1")
R22.update(CL={f"{k[0]}|{k[1]}": v for k, v in CL.items()})
_json.dump(R22, open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'r23_results_20261029.json'), 'w'), indent=1, default=float)
if os.path.exists(md_path):
    txt = open(md_path, encoding="utf-8").read()
    a2, a10 = CL[("5 T SF 2", 0.02)], CL[("5 T SF 2", 0.10)]
    needb = {"ce2": f"{a2['cope_net']:,.0f}", "ce10": f"{a10['cope_net']:,.0f}", "ci2": f"{a2['cope_in']:,.1f}", "ci10": f"{a10['cope_in']:,.1f}",
             "ct2": f"{a2['copth']:.4f}", "ct10": f"{a10['copth']:.4f}", "pai": f"| {a2['Pai']/1e6:,.2f} |", "qret": f"{a10['Qret']/1e6:,.2f} MW",
             "vs": f"{a10['vshare']:.2%}", "u2": f"{CL[('13 T SF 2', 0.02)]['cope_net']:,.0f}"}
    bad = [k_ for k_, v in needb.items() if v not in txt]
    print("AUDIT r22b:", f"PASS - all {len(needb)} r22b values present" if not bad else f"MISSING {[(k_, needb[k_]) for k_ in bad]}")

# ==== r22c audit: corrected bearing sizing present; withdrawn eccentricity sizing absent from the live text ====
if os.path.exists(md_path):
    txt_c = open(md_path, encoding="utf-8").read()
    needc = {"A5.0": f"{BR[5.0]['A']*1e4:.1f} cm² at 5 T", "A13.0": f"{BR[B_op]['A']*1e4:.1f} cm² at 13 T"}
    needc.update({"A1094": f"{BR[B_q119]['A']*1e4:.1f} cm² at 10.94 T", "end": f"{A_end*1e4:.1f} cm²", "m400_5": f"{BR[5.0]['m400']:.1f} kg", "m400_13": f"{BR[B_op]['m400']:.1f} kg",
                  "F13": f"{BR[B_op]['F']:,.0f} N", "dual": "Dual YBCO HTS flux-pinned bearings (400 N capacity)", "withdrawn": "withdrawn", "Rup": f"{R_up:,.0f} N", "Aup": f"{A_up*1e4:.1f} cm²", "B1": "Morgan's choice"})
    badc = [k_ for k_ in needc if needc[k_] not in txt_c]
    stale = [s_ for s_ in ("eccentricity of 1 %", "*The bigger YBCO bearing", "conditions F1–F4") if s_ in txt_c]
    print("AUDIT r22c:", "PASS" if not (badc or stale) else f"MISSING {badc} STALE {stale}", f"- {len(needc)} values, 0 stale strings")

# ==== r22d (Morgan 12:44): "outputs would have scaled up with rotor weight and magnet weight to field density" ====
# Which field is B in P = sigma (omega r B)^2 K(1-K) 2 pi r h delta?  In the records the booked B is the ReBCO stator field
# (5 T worked, v6; relief from "the ReBCO stator", 20031552); the rotor carries a Dy-NdFeB / N52 Halbach array, "field augmented
# on stator side, cancelled internally" (18916931 s.5.1), upgraded arrays "B ~ 1.6-2.0 T" (18916931 AC).  Both are followed here.
print("\nr22d: magnet mass -> field -> output, sleeve stress, rpm and bearing load")
Br_m, rho_m, mu0Hcj = 1.45, 7500.0, 1.10        # N52: Br 1.42-1.48 T, density 7.5 g/cm3, Hcj >= 11 kOe (grade data, public) [published grade]
p_h, eta_seg = 4, 0.9                            # Halbach pole pairs = 4 (one per stator; assumed), 4 segments per pole: sin(pi/4)/(pi/4) = 0.900 [assumed]
ro_m = r - d                                     # array outer radius = core boundary 0.091 m; field evaluated at the plasma radius r = 0.093 m
def B_pm(tm):                                    # ideal outward Halbach cylinder (Mallinson/Halbach): saturates as (1 - (ri/ro)^(p-1))
    ri = ro_m - tm
    return Br_m*eta_seg*(p_h/(p_h - 1))*(1 - (ri/ro_m)**(p_h - 1))*(ro_m/r)**(p_h + 1)
def m_pm(tm): return rho_m*pi*(ro_m**2 - (ro_m - tm)**2)*h
def p_pm(tm, w_):                                # radial pressure of the array on the sleeve (NdFeB carries no hoop tension)
    ri = ro_m - tm; return rho_m*w_**2*(ro_m**3 - ri**3)/(3*ro_m)
def rpm_pm(tm, SF, Bs):                          # sleeve: rho_c w^2 rs^2 + p_pm ro/t = ult/SF + relief(Bs)
    ri = ro_m - tm; k2 = rho_cfrp*rs**2 + rho_m*(ro_m**3 - ri**3)/(3*ro_m)*ro_m/t0
    return RPM(((ult_hi/SF + relief_x(Bs))/k2)**0.5)
sig8 = sig*(S5[2.0]['p']/1e5/pa0)**kp
print(f"  check: Pring at the booked point {Pring(rpm_=S5[2.0]['rpm'], sig_=sig8, B_=5.0)/1e6:.2f} MW = solve22 {S5[2.0]['P']/1e6:.2f} MW")
MG = []
for tm in (0.0, 0.002, 0.005, 0.010, 0.020, 0.030, 0.045, 0.060, 0.091):
    row = dict(tm=tm, m=m_pm(tm), Bpm=B_pm(tm))
    for Bs in (5.0, B_op, 0.0):
        rp = rpm_pm(tm, 2.0, Bs); Be = (Bs**2 + row['Bpm']**2/2)**0.5      # multipole PM field on a uniform stator field: <B^2> = Bs^2 + Bpm^2/2
        mr = m_rot + (rho_m - rho_Ti)*pi*(ro_m**2 - (ro_m - tm)**2)*h
        row[Bs] = dict(rpm=rp, P=Pring(rpm_=rp, sig_=sig8, B_=Be), Be=Be, mrot=mr, F=mr*(9.80665 + G_bal*W(rp)))
        rb = rpm_pm(0.0, 2.0, Bs)                                             # case B: array carried inside the core, sleeve load unchanged
        row['B%g' % Bs] = dict(rpm=rb, P=Pring(rpm_=rb, sig_=sig8, B_=Be), F=mr*(9.80665 + G_bal*W(rb)))
    MG.append(row)
print("  case A (array loads the sleeve) and case B (array carried by the core; sleeve envelope unchanged)")
print("  t_mag mm | magnet kg | B_pm T | 5 T: rpm, P MW, bearing N | 13 T: rpm, P MW, bearing N | PM only: rpm, P MW")
for x in MG:
    a5, a13, a0 = x[5.0], x[B_op], x[0.0]
    print(f"  {x['tm']*1e3:5.0f} | {x['m']:6.2f} | {x['Bpm']:.3f} | {a5['rpm']:,.0f}, {a5['P']/1e6:,.2f}, {a5['F']:,.0f} | "
          f"{a13['rpm']:,.0f}, {a13['P']/1e6:,.2f}, {a13['F']:,.0f} | {a0['rpm']:,.0f}, {a0['P']/1e6:,.2f}")
print("  case B: t_mag mm | magnet kg | rotor kg | B_pm T | 5 T: P MW, gain %, bearing N | 13 T: P MW, gain %, bearing N (1,300 N rating) | PM only P MW")
for x in MG:
    b5, b13, b0 = x['B5'], x['B13'], x['B0']
    print(f"  B {x['tm']*1e3:5.0f} | {x['m']:6.2f} | {x[5.0]['mrot']:6.2f} | {x['Bpm']:.3f} | {b5['P']/1e6:,.2f}, {100*(b5['P']/MG[0]['B5']['P'] - 1):+.2f} %, {b5['F']:,.0f} | "
          f"{b13['P']/1e6:,.2f}, {100*(b13['P']/MG[0]['B13']['P'] - 1):+.3f} %, {b13['F']:,.0f} {'OK' if b13['F'] <= 1300 else 'OVER'} | {b0['P']/1e6:,.3f}")
mB13 = (1300/(9.80665 + G_bal*W(MG[0]['B13']['rpm'])) - m_rot)
from math import sqrt
tB13 = ro_m - sqrt(ro_m**2 - mB13/((rho_m - rho_Ti)*pi*h))
dB5 = (MG[1]['B5']['P'] - MG[0]['B5']['P'])/MG[1]['m']; dB5_end = (MG[-1]['B5']['P'] - MG[-2]['B5']['P'])/(MG[-1]['m'] - MG[-2]['m'])
dB13 = (MG[1]['B13']['P'] - MG[0]['B13']['P'])/MG[1]['m']
PB13_lim = Pring(rpm_=MG[0]['B13']['rpm'], sig_=sig8, B_=(B_op**2 + B_pm(tB13)**2/2)**0.5)
print(f"  case B: first 2 mm dP/dm {dB5/1e3:+.1f} kW/kg at 5 T, {dB13/1e3:+.1f} kW/kg at 13 T; last step {dB5_end/1e3:+.2f} kW/kg at 5 T; max gain {100*(MG[-1]['B5']['P']/MG[0]['B5']['P'] - 1):.2f} % at 5 T, "
      f"{100*(MG[-1]['B13']['P']/MG[0]['B13']['P'] - 1):.3f} % at 13 T; at 13 T the 1,300 N rating stops the array at {tB13*1e3:.1f} mm ({m_pm(tB13):.1f} kg magnet, B_pm {B_pm(tB13):.3f} T, P {PB13_lim/1e6:,.2f} MW)")
d5 = (MG[1][5.0]['P'] - MG[0][5.0]['P'])/MG[1]['m']; d13 = (MG[1][B_op]['P'] - MG[0][B_op]['P'])/MG[1]['m']
best5 = max(MG, key=lambda x: x[5.0]['P']); best13 = max(MG, key=lambda x: x[B_op]['P']); best0 = max(MG[1:], key=lambda x: x[0.0]['P'])
print(f"  first 2 mm of array: dP/dm = {d5/1e6:+.2f} MW/kg at 5 T, {d13/1e6:+.2f} MW/kg at 13 T; best of sweep: t = {best5['tm']*1e3:.0f} mm at 5 T, {best13['tm']*1e3:.0f} mm at 13 T")
print(f"  demagnetisation: stator field 5 / 13 T vs N52 mu0*Hcj {mu0Hcj} T (Dy grades ~3 T): poles opposing the stator field are driven past Hcj")
R22D = dict(MG=[{**{k: v for k, v in x.items() if not isinstance(k, float)}, **{str(k): v for k, v in x.items() if isinstance(k, float)}} for x in MG],
            d5=d5, d13=d13, dB5=dB5, dB13=dB13, dB5_end=dB5_end, tB13=tB13, mB13pm=m_pm(tB13), BB13=B_pm(tB13), PB13_lim=PB13_lim, Bpm_max=B_pm(ro_m), m_max=m_pm(ro_m), best5=best5['tm'], best13=best13['tm'], best0=best0['tm'], P0_5=MG[0][5.0]['P'], P0_13=MG[0][B_op]['P'])
_json.dump(R22D, open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'r23_magnet_results_20261029.json'), 'w'), indent=1, default=float)
print(f"  case B totals: +{(MG[-1]['B5']['P'] - MG[0]['B5']['P'])/1e6:.2f} MW at 5 T, +{(MG[-1]['B13']['P'] - MG[0]['B13']['P'])/1e6:.2f} MW at 13 T; core-edge speed at r_o {W(MG[0]['B5']['rpm'])*ro_m:,.0f} m/s (5 T), {W(MG[0]['B13']['rpm'])*ro_m:,.0f} m/s (13 T)")
# ==== r22d audit ====
if os.path.exists(md_path):
    txt_d = open(md_path, encoding="utf-8").read()
    needd = {"Bmax": f"{B_pm(ro_m):.3f} T", "mmax": f"{m_pm(ro_m):.2f} kg", "g5": "4.87 %", "g13": "0.721 %", "dA5": f"{d5/1e6:+.2f} MW per kg", "tB13": f"{tB13*1e3:.1f} mm",
             "PB13": f"{PB13_lim/1e6:,.2f} MW", "T29": "Table 29.", "fig": "magnet_mass_r22d.png", "M1": "**M1.**", "A5s": "18.8 cm² at 5 T", "A1094s": "20.3 cm² at 10.94 T"}
    badd = [k_ for k_ in needd if needd[k_] not in txt_d]
    print("AUDIT r22d:", f"PASS - all {len(needd)} r22d values present" if not badd else f"MISSING {[(k_, needd[k_]) for k_ in badd]}")
# ==== r22d (Morgan 12:51) audit: every large waste-heat total is labelled as the operational peak; the closing statement is present ====
if os.path.exists(md_path):
    txt_p = open(md_path, encoding="utf-8").read()
    untag = [l_[:80] for l_ in txt_p.split('\n') if re.search(r"(?<![\d,.])(2,360|2,215|1,366|1,964|2,372)(?:\.\d+)?(?!,\d)", l_) and 'peak' not in l_ and 'W/m²' not in l_]
    need_p = [f"{S5[2.0]['Q']/1e6:.2f} MW per module at 5 T, SF 2", f"{S5[1.5]['Q']/1e6:.2f} MW at 5 T, SF 1.5", "not a requirement for the maths to close"]
    miss_p = [x_ for x_ in need_p if x_ not in txt_p]
    print("AUDIT r22d peak:", "PASS" if not (untag or miss_p) else f"UNTAGGED {untag} MISSING {miss_p}", f"- {txt_p.count('(peak)')} '(peak)' tags")
    print(f"  matching waste heat at 13 T: SF 2 {U[2.0]['Q']/1e6:,.2f} MW, SF 1.5 {U[1.5]['Q']/1e6:,.2f} MW")

# ==== r22e (Morgan 12:56): "the stator fields rise and scale against RPM and everything else" ====
# Records (qualitative only): 20936018/21682741 "Higher RPM increases switching rate and effective field strength";
# "Back-EMF feedback: Induced voltages are harvested and fed back"; "no separate high-power drivers needed beyond initial excitation";
# "AI-oracle dynamically adjusts stator currents or phasing based on real-time RPM". 18529370 s.3.5 "More runtime/RPM -> more induced EMF
# in stator ... -> higher ionization/sigma -> more MHD power". No record gives a B(rpm) coefficient.
# Derived law: stator ampere-turns = excitation (B0, the booked 5 T) + a fed-back share of the induced current, I_ind ~ EMF ~ omega r B:
#   B = B0 + g(omega) B,  g = g0 * omega/omega0   ->  B* = B0/(1 - g)       (g0 = feedback share at the booked 150,938 rpm: NOT published, question S1)
# Loop gain (d lnP/d lnB x d lnB_fb/d lnP): G = g (1 + f_rel), f_rel = relief/(ult/SF + relief) (the field also lifts rpm through the relief).
print("\nr22e: stator field coupled to rpm (back-EMF feedback), integrated fixed point")
B_Ic = 20.0                                       # T: REBCO critical-current field at 77 K published as "critical current >500 A/cm at 77 K, 20 T" (18363156) / "J_c = 10^6 A/m2 at 77 K, 20 T" (18404739)
B0e = 5.0
rpm0e = {SF: solve22(SF)['rpm'] for SF in (2.0, 1.5)}
def frel(B_, SF): return relief_x(B_)/(ult_hi/SF + relief_x(B_))
def B_whirl(SF): return ((rho_cfrp*(W(whirl1)*rs)**2 - ult_hi/SF)*2*mu0*t0/rs)**0.5
def solve_fb(SF, g0, it_max=500):
    Bc = B0e; cap = None
    for it in range(it_max):
        rp = allow_rpm(ult_hi, SF, rel=relief_x(Bc)); g = g0*rp/rpm0e[SF]
        Bn = B0e/(1 - g) if g < 1 else float('inf')
        lim = min(B_Ic, B_whirl(SF))
        if Bn >= lim: Bn = lim; cap = 'REBCO Ic(77 K) 20 T' if lim == B_Ic else 'whirl 276,000 rpm'
        if abs(Bn - Bc) < 1e-12: break
        Bc = Bn
    rp = allow_rpm(ult_hi, SF, rel=relief_x(Bc)); g = g0*rp/rpm0e[SF]; G = g*(1 + frel(Bc, SF))
    s = solve22(SF, B_=Bc)
    F_b = m_rot*(9.80665 + G_bal*W(s['rpm']))
    fl = ult_hi/(rho_cfrp*(W(s['rpm'])*rs)**2)    # SF if the field is lost at speed
    return dict(B=Bc, rpm=s['rpm'], P=s['P'], g=g, G=G, cap=cap, it=it, cope=s['cope'], copth=s['copth'], Q=s['Q'], F=F_b, flSF=fl, train=100*s['P'])
FB = {}
for SF in (2.0, 1.5):
    for g0 in (0.0, 0.05, 0.10, 0.20, 0.30, 0.40, 0.50):
        FB[(SF, g0)] = x = solve_fb(SF, g0)
        print(f"  SF {SF} g0 {g0:.2f}: B {x['B']:.3f} T, rpm {x['rpm']:,.0f}, P {x['P']/1e6:,.2f} MW, g {x['g']:.4f}, loop gain {x['G']:.4f} "
              f"({'converges' if x['cap'] is None else 'capped: ' + x['cap']}), COP_e {x['cope']:,.0f}, bearing {x['F']:,.0f} N, field-loss SF {x['flSF']:.3f}")
# g0 at which the loop reaches the cap; whirl field
def g0_cap(SF):
    lo, hi = 0.0, 0.99
    for _ in range(200):
        mid = (lo + hi)/2
        if solve_fb(SF, mid)['cap']: hi = mid
        else: lo = mid
    return hi
G0c = {SF: g0_cap(SF) for SF in (2.0, 1.5)}
CAP = {SF: solve_fb(SF, 0.6) for SF in (2.0, 1.5)}
for SF in (2.0, 1.5):
    c = CAP[SF]
    print(f"  SF {SF}: whirl-limit field {B_whirl(SF):.2f} T; loop reaches the 20 T Ic cap for g0 >= {G0c[SF]:.4f}; capped point B {c['B']:.2f} T, "
          f"{c['rpm']:,.0f} rpm, P {c['P']/1e6:,.2f} MW, train {c['train']/1e9:,.2f} GW, COP_e {c['cope']:,.0f}, COP_th {c['copth']:.4f}, bearing {c['F']:,.0f} N, field-loss SF {c['flSF']:.3f}")
B_fl = {SF: (2*mu0*t0/rs*ult_hi*(1/1.19 - 1/SF))**0.5 for SF in (2.0, 1.5)}   # field that keeps the published SF 1.19 if the field is lost at speed
FL = {SF: solve22(SF, B_=B_fl[SF]) for SF in (2.0, 1.5)}
g0_fl = {SF: (1 - B0e/B_fl[SF])*rpm0e[SF]/FL[SF]['rpm'] for SF in (2.0, 1.5)}
for SF in (2.0, 1.5):
    print(f"  SF {SF}: published field-loss SF 1.19 caps B at {B_fl[SF]:.2f} T -> {FL[SF]['rpm']:,.0f} rpm, P {FL[SF]['P']/1e6:,.2f} MW, train {100*FL[SF]['P']/1e9:,.2f} GW, COP_e {FL[SF]['cope']:,.0f}; reached at g0 = {g0_fl[SF]:.4f}")
# scaling with rpm imposed (B coupled vs fixed): n = dlnP/dln(rpm) = 2 + 2 dlnB/dln(rpm) = 2 + 2 g/(1 - g)
SC = []
for frac in (0.6, 0.8, 1.0, 1.2):
    for g0 in (0.0, 0.10, 0.20):
        w_ = frac; g = g0*w_; Bw = B0e/(1 - g); n = 2 + 2*g/(1 - g)
        Pw = Pring(rpm_=rpm0e[2.0]*w_, sig_=sig8, B_=Bw)
        SC.append(dict(frac=frac, g0=g0, rpm=rpm0e[2.0]*w_, B=Bw, P=Pw, n=n))
        print(f"  rpm {rpm0e[2.0]*w_:,.0f} (x{frac}), g0 {g0:.2f}: B {Bw:.3f} T, P {Pw/1e6:,.2f} MW, local exponent n {n:.3f}")
R22E = dict(B_fl=B_fl, FL={SF: dict(P=FL[SF]['P'], rpm=FL[SF]['rpm'], cope=FL[SF]['cope']) for SF in FL}, g0_fl=g0_fl, FB={f"{k[0]}|{k[1]}": v for k, v in FB.items()}, G0c=G0c, CAP=CAP, SC=SC, Bw={SF: B_whirl(SF) for SF in (2.0, 1.5)}, rpm0=rpm0e)
_json.dump(R22E, open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'r23_feedback_results_20261029.json'), 'w'), indent=1, default=float)
if os.path.exists(md_path):
    txt_e = open(md_path, encoding="utf-8").read()
    neede = {"T30": "Table 30.", "T31": "Table 31.", "fig": "stator_feedback_r22e.png", "cap2": f"{CAP[2.0]['P']/1e6:,.2f} MW per module", "g0c": f"{G0c[2.0]:.4f}",
             "fl2": f"| {FL[2.0]['P']/1e6:,.2f} |", "Bw": f"{B_whirl(2.0):.2f} T", "S1": "**S1 (to be measured on the bench, r23).**", "q1": "Higher RPM increases switching rate and effective field strength",
             "q2": "Back-EMF feedback: Induced voltages are harvested and fed back", "n": "n = 2 + 2g/(1 − g)"}
    bade = [k_ for k_ in neede if neede[k_] not in txt_e]
    print("AUDIT r22e:", f"PASS - all {len(neede)} r22e values present" if not bade else f"MISSING {[(k_, neede[k_]) for k_ in bade]}")
# r22e audit note (r23): 'fl2' now checks the 10.94 T row of Table 25; the field-loss cap itself is retired
# ==== r23 audit (finalised; Morgan 13:04-14:33) ====
if os.path.exists(md_path):
    t23 = open(md_path, encoding="utf-8").read()
    dr = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'SCG_HMH_Closed_Derivative_Chain_v8.md')
    if not os.path.exists(dr): dr = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'paper', 'SCG_HMH_Closed_Derivative_Chain_v8.md')
    d23 = open(dr, encoding="utf-8").read() if os.path.exists(dr) else ""
    need23 = {"guide": "Reading guide (r23, finalised)", "fault": "is a fault", "ceiling": "the ceiling for the self-excited field", "S3": "S3 (answered, r23)", "bench": "measured on the Phase-1 bench",
              "author": "Smart, Jasper Keiron", "base": f"{S5[2.0]['P']/1e6:.2f} MW", "cap": f"{CAP[2.0]['P']/1e6:,.2f} MW per module"}
    bad23 = [k_ for k_ in need23 if need23[k_] not in t23]
    stale23 = [x_ for x_ in ("Kieron", "Kiron", "Smart, Keiron", "1. **Published field-loss margin", "field loss keeps the published SF 1.19", "question F2)") if x_ in t23 or x_ in d23]
    d_need = [x_ for x_ in ('"Smart, Jasper Keiron"', "Smart, Jasper Keiron (full name Jasper Keiron Smart", "**Jasper Keiron Smart**", "Finalised v8 (r23)") if x_ not in d23]
    print("AUDIT r23:", "PASS" if not (bad23 or stale23 or d_need) else f"MISSING {bad23} STALE {stale23} PAPER-MISSING {d_need}", f"- {len(need23)} section values, 4 paper strings, 6 stale strings")
