"""r22c independent cross-check (Morgan 11:45, 12:14). Recomputes the r22 rows from scratch, with no import from the main calc.
Standard library only; N2 saturation from the Span et al. (2000) vapour-pressure ancillary equation (no CoolProp).
Compares with r23_results_20261029.json written by the main calc, at 4 significant figures."""
import math, json, sys
mu0 = 4e-7*math.pi
sig_hi, pa0, kp0 = 14000.0, 7.0133, 0.85
r, h, d, K = 0.093, 0.4, 0.002, 0.65
rs, t, rho, ult = 0.1, 0.002, 1600.0, 7.0e9
Th, Tc, Ta = 453.15, 77.35, 300.0
w_exp, eta_reg, etaII, E_in = 242.5e3, 0.996, 0.207/0.40, 800.0
sb, eps = 5.670374419e-8, 0.9
rhoL, p_tank = 806.6, 1.01325e5
TcN, pcN = 126.192, 3.3958e6
nW = (-6.12445284, 1.26327220, -0.765910082, -1.77570564)
def psat(T):
    th = 1 - T/TcN
    return pcN*math.exp(TcN/T*(nW[0]*th + nW[1]*th**1.5 + nW[2]*th**2.5 + nW[3]*th**5))
def tsat(p):
    lo, hi = 63.2, TcN
    for _ in range(200):
        mid = (lo + hi)/2
        lo, hi = (mid, hi) if psat(mid) < p else (lo, mid)
    return (lo + hi)/2
def point(SF, B=5.0, pg=8.0, k=kp0):
    pa = 9.0133 if pg == 8.0 else pg + 1.0133
    rel = B**2/(2*mu0)*rs/t
    v = math.sqrt((ult/SF + rel)/rho); w = v/rs; rpm = w*60/(2*math.pi)
    P = sig_hi*(pa/pa0)**k*(w*r*B)**2*K*(1 - K)*2*math.pi*r*h*d
    m = P/w_exp
    head = m*max(pa*1e5 - p_tank, 0)/rhoL
    Qc = P*Tc/(Th - Tc); lift = Qc*(Ta/Tc - 1)/(etaII*(1 - Ta/Th)); leak = (1 - eta_reg)*P
    Q = P + Qc + lift + leak
    return dict(P=P, rpm=rpm, m=m, head=head, Q=Q, copth=P/(Q + E_in), cope=P/E_in, copth_s=P/(P + Qc + leak + E_in),
                A=Qc/(eps*sb*(Tc**4 - 2.7**4)), hoop=rho*v**2, rel=rel, quenchSF=ult/(rho*v**2), whirl=rpm/276000, Tsat=tsat(pa*1e5) if pa*1e5 < pcN else float('nan'))
ref = json.load(open(sys.argv[1] if len(sys.argv) > 1 else "r23_results_20261029.json"))
rows, bad = 0, 0
def cmp(label, a, b):
    global rows, bad
    rows += 1
    if b == 0 or (isinstance(b, float) and math.isnan(b)):
        ok = (a == b) or (abs(a) < 1e-9 and abs(b) < 1e-9) or (math.isnan(a) and math.isnan(b))
    else:
        ok = float(f"{a:.4g}") == float(f"{b:.4g}") or abs(a - b)/abs(b) < 5e-5
    bad += not ok
    if not ok or label.startswith('*'):
        print(f"{label}: cross-check {a:.6g} | main {b:.6g} | {'AGREE' if ok else 'DIFFER'}")
keys = ('P', 'rpm', 'm', 'head', 'Q', 'copth', 'cope', 'copth_s', 'A', 'hoop', 'quenchSF', 'whirl')
for SF in ('2.0', '1.5'):
    x = point(float(SF)); u = point(float(SF), B=13.0)
    for k in keys + ('Tsat',): cmp(f"5 T SF {SF} {k}", x[k], ref['S5'][SF][k])
    for k in keys: cmp(f"13 T SF {SF} {k}", u[k], ref['U'][SF][k])
for key, v in ref['SW'].items():
    pg, k = key.split('|'); x = point(2.0, pg=float(pg), k=float(k))
    for kk in ('P', 'rpm', 'm', 'head', 'copth', 'cope'): cmp(f"sweep {pg} bar g k {k} {kk}", x[kk], v[kk])
    if float(pg) < 32.0: cmp(f"sweep {pg} bar g T_sat", x['Tsat'], v['Tsat'])
for key, v in ref['FB'].items():
    x = point(2.0, B=float(key))
    for kk in ('P', 'rpm', 'hoop', 'rel', 'quenchSF', 'whirl', 'm'): cmp(f"field {key} T {kk}", x[kk], v[kk])
L = ref['lim']
B_fix2 = math.sqrt(ult/2*2*mu0*t/rs); B_fix15 = math.sqrt(ult/1.5*2*mu0*t/rs)
B_q = math.sqrt((ult/1.19 - ult/2)*2*mu0*t/rs)
cmp("*B fixed-field limit SF 2", B_fix2, L['B_fix2']); cmp("*B fixed-field limit SF 1.5", B_fix15, L['B_fix15']); cmp("*B for field-loss SF 1.19", B_q, L['B_q119'])
g = lambda B: (point(2.0, B=B + 1e-4)['P'] - point(2.0, B=B - 1e-4)['P'])/2e-4
cmp("*gain MW/T at 5 T", g(5.0), L['gain5']); cmp("*gain MW/T at 13 T", g(13.0), L['gain13'])
cmp("*average gain 5-13 T", (point(2.0, B=13.0)['P'] - point(2.0)['P'])/8, L['gain_avg'])
ps = psat(Tc); cmp("*generator suction Pa", ps, L['p_suct'])
cmp("*dp need", 9.0133e5 - ps, L['dp_need']); cmp("*dp available", pcN - ps, L['dp_avail'])
Tout = Th/1.3**(0.4/1.4); prh = 9.0133e5/1.3*Th/Tout
cmp("*stage outlet T", Tout, L['T_out']); cmp("*reset pressure", prh, L['p_rh']); cmp("*tank top-up", 9.0133e5 - prh, L['dp_top'])
x2 = point(2.0); cmp("*head heat share", x2['head']/(1 - Ta/Th)/x2['Q'], L['share_head'])
for SF in ('2.0', '1.5'):
    x = point(float(SF)); T = ref['TR'][SF]
    cmp(f"*train {SF} GW", 100*x['P'], T['P']); cmp(f"*train {SF} AI low", 100*x['P']*0.995, T['Pai_lo']); cmp(f"*train {SF} AI high", 100*x['P']*1.005, T['Pai_hi'])
    cmp(f"*train {SF} unregulated low", 100*x['P']*0.95**0.85, T['Pd_lo']); cmp(f"*train {SF} unregulated high", 100*x['P']*1.05**0.85, T['Pd_hi'])
m_rot = 4506*math.pi*(r - d)**2*h + rho*2*math.pi*rs*t*h
# r22 eccentricity (UMP) rows withdrawn in r22c; bearing rows recomputed below
mv = 0.004*x2['m']; cmp("*vent kg/s", mv, L['mv']); cmp("*vent 243 K MW", mv*1040*(Ta - 243), L['vent243'])
# r22c: cluster oracle rows (vaporiser-duty share needs real-gas enthalpy and is not cross-checked here)
for key, v in ref['CL'].items():
    lab, f = key.split('|'); f = float(f)
    x = point(2.0 if 'SF 2' in lab else 1.5, B=13.0 if lab.startswith('13') else 5.0)
    Pai = f*100*x['P']; net = 100*x['P'] - Pai
    cmp(f"cluster {key} oracle", Pai, v['Pai']); cmp(f"cluster {key} heat returned", 0.95*Pai, v['Qret']); cmp(f"*cluster {key} net", net, v['net'])
    cmp(f"*cluster {key} COP_e paid from output", net/(100*E_in), v['cope_net']); cmp(f"*cluster {key} COP_e as input", 100*x['P']/(100*E_in + Pai), v['cope_in'])
    cmp(f"*cluster {key} COP_th net", net/(100*x['Q'] - 0.95*Pai + 100*E_in), v['copth'])
# r22c bearing rows (Morgan 12:31-12:35): weight + ISO G0.4 imbalance, centring field; up-rated dual rating
L = ref['lim']; mr = 4506.0*math.pi*(r - d)**2*h + rho*2*math.pi*rs*t*h
cmp("*bearing rotor mass [assumed]", mr, L['m_rot'])
for tag, B in (('5', 5.0), ('1094', L['B_q119']), ('13', 13.0)):
    w = point(2.0, B=B)['rpm']*2*math.pi/60; F = mr*9.80665 + mr*0.4e-3*w
    cmp(f"*bearing load {tag}", F, L['F'+tag]); cmp(f"*bearing area {tag}", F/41e4, L['A'+tag])
    if tag != '1094': cmp(f"*400 N rotor limit {tag}", 400/(9.80665 + 0.4e-3*w), L['m400_'+tag])
    cmp(f"*up-rated margin {tag}", 50*math.ceil(1.5*L['F13']/50)/F, L['mg'+tag])
cmp("*end face per end", math.pi*(r - d)**2, L['A_end']); cmp("*up-rated face", 1300/41e4, L['A_up'])
assert L['A_up']/2 < L['A_end'] and L['A13']/2 < L['A_end']
# r22d magnet rows (Morgan 12:44): independent - sleeve pressure by numerical integration (midpoint, 4,000 slices), P from the point() formula
MJ = json.load(open("r23_magnet_results_20261029.json"))
ro = r - d; Br, rm, pp, eta = 1.45, 7500.0, 4, 0.900   # eta as stated in the text (sin(pi/4)/(pi/4) = 0.9003 rounds to 0.900)
G = 0.4e-3; mr0 = 4506.0*math.pi*(r - d)**2*h + rho*2*math.pi*rs*t*h
for x in MJ['MG']:
    tm = x['tm']; ri = ro - tm
    Bp = Br*eta*pp/(pp - 1)*(1 - (ri/ro)**(pp - 1))*(ro/r)**(pp + 1)
    cmp(f"*Bpm t={tm*1e3:.0f} mm", Bp, x['Bpm']); cmp(f"*magnet kg t={tm*1e3:.0f}", rm*math.pi*(ro**2 - ri**2)*h, x['m'])
    n = 4000; integ = sum(rm*((ri + (i + .5)*tm/n))*tm/n for i in range(n)) if tm > 0 else 0.0   # integral rho_m r dr; times w^2 r/ro below
    integ = sum(rm*(ri + (i + .5)*tm/n)**2*tm/n for i in range(n))/ro if tm > 0 else 0.0
    for Bs, key, keyB in ((5.0, '5.0', 'B5'), (13.0, '13.0', 'B13')):
        w2 = (ult/2.0 + Bs**2/(2*mu0)*rs/t)/(rho*rs**2 + integ*ro/t); rpmA = math.sqrt(w2)*60/(2*math.pi)
        Be = math.sqrt(Bs**2 + Bp**2/2); PA = sig_hi*(9.0133/pa0)**kp0*(math.sqrt(w2)*r*Be)**2*K*(1 - K)*2*math.pi*r*h*d
        cmp(f"*caseA rpm {Bs} t={tm*1e3:.0f}", rpmA, x[key]['rpm']); cmp(f"*caseA P {Bs} t={tm*1e3:.0f}", PA, x[key]['P'])
        pB = point(2.0, B=Bs); PB = pB['P']*Be**2/Bs**2
        mrot = mr0 + (rm - 4506.0)*math.pi*(ro**2 - ri**2)*h
        cmp(f"*caseB P {Bs} t={tm*1e3:.0f}", PB, x[keyB]['P']); cmp(f"*caseB bearing {Bs} t={tm*1e3:.0f}", mrot*(9.80665 + G*pB['rpm']*2*math.pi/60), x[keyB]['F'])
# r22e feedback rows: independent - fixed point found by bisection on B (root of B - B0/(1 - g0*rpm(B)/rpm0)), P from point()
FJ = json.load(open("r23_feedback_results_20261029.json"))
for SF in (2.0, 1.5):
    rpm0 = point(SF)['rpm']
    for g0 in (0.0, 0.05, 0.10, 0.20, 0.30, 0.40):
        f = lambda B: B - 5.0/(1 - g0*point(SF, B=B)['rpm']/rpm0)
        lo, hi = 5.0, 19.99
        for _ in range(200):
            mid = (lo + hi)/2
            if f(mid) > 0: hi = mid
            else: lo = mid
        B = lo if g0 > 0 else 5.0; x = point(SF, B=B); ref_ = FJ['FB'][f"{SF}|{g0}"]
        cmp(f"*fb B SF{SF} g0{g0}", B, ref_['B']); cmp(f"*fb P SF{SF} g0{g0}", x['P'], ref_['P']); cmp(f"*fb rpm SF{SF} g0{g0}", x['rpm'], ref_['rpm'])
        g = g0*x['rpm']/rpm0; rel = B**2/(2*mu0)*rs/t; cmp(f"*fb loop gain SF{SF} g0{g0}", g*(1 + rel/(ult/SF + rel)), ref_['G'])
    Bfl = math.sqrt(2*mu0*t/rs*ult*(1/1.19 - 1/SF)); cmp(f"*field-loss cap B SF{SF}", Bfl, FJ['B_fl'][str(SF)]); cmp(f"*field-loss cap P SF{SF}", point(SF, B=Bfl)['P'], FJ['FL'][str(SF)]['P'])
    vw = 276000*2*math.pi/60*rs; cmp(f"*whirl field SF{SF}", math.sqrt((rho*vw**2 - ult/SF)*2*mu0*t/rs), FJ['Bw'][str(SF)])
    cmp(f"*Ic cap P SF{SF}", point(SF, B=20.0)['P'], FJ['CAP'][str(SF)]['P'])
for x in FJ['SC']:
    g = x['g0']*x['frac']; cmp(f"*scaling n {x['frac']} {x['g0']}", 2 + 2*g/(1 - g), x['n'])
print(f"CROSS-CHECK r23: {rows - bad}/{rows} agree to 4 significant figures" + ("" if not bad else f" - {bad} DIFFER"))
