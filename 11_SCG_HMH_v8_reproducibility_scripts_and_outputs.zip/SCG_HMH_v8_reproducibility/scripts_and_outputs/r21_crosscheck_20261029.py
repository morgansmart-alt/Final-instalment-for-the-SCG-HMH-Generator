"""r21 independent cross-check (Morgan 11:28). Recomputes the r21 headline figures from scratch from published inputs,
with no import from the main calc script, and compares them to the main script's printed output at 4 significant figures.
Standard library only; N2 critical pressure and saturation pressure use NIST values (no CoolProp)."""
import math, re, sys
mu0 = 4e-7*math.pi*(1 + 5.5e-10)          # CODATA-2018 mu0 = 1.25663706212e-6 (close to 4 pi e-7)
mu0 = 1.25663706212e-6
sig_hi, pa0, pa1, kp = 14000.0, 7.0133, 9.0133, 0.85      # S/m at 6 bar g (published); bar a; code exponent in published 0.7-1.0
r, h, d, B, K = 0.093, 0.4, 0.002, 5.0, 0.65              # v7 ring
rs, t, rho, ult = 0.1, 0.002, 1600.0, 7.0e9               # 20031552 sleeve
Th, Tc, Ta = 453.15, 77.35, 300.0
eta_reg, w_exp, etaII = 0.996, 242.5e3, 0.207/0.40       # v7; [9]
E_in = 800.0                                              # W, 18916931
sb = 5.670374419e-8; eps = 0.9
rhoL = 806.6; p_tank = 1.01325e5; p_crit = 33.958e5        # NIST N2 critical 3.3958 MPa
def ring(rpm, s): w = 2*math.pi*rpm/60; return s*(w*r*B)**2*K*(1-K)*2*math.pi*r*h*d
relief = B**2/(2*mu0)*rs/t
def rpm_allow(SF): return math.sqrt((ult/SF + relief)/rho)/rs*60/(2*math.pi)
s8 = sig_hi*(pa1/pa0)**kp
out = {}
for SF in (2.0, 1.5):
    n = rpm_allow(SF); P = ring(n, s8); m = P/w_exp
    Qc = P*Tc/(Th - Tc); lift = Qc*(Ta/Tc - 1)/(etaII*(1 - Ta/Th)); leak = (1 - eta_reg)*P
    Q = P + Qc + lift + leak
    out[SF] = dict(rpm=n, hoop=rho*(2*math.pi*n/60*rs)**2, P=P, m=m, Q=Q, copth=P/(Q + E_in), cope=P/E_in,
                   head=m*(pa1*1e5 - p_tank)/rhoL, ratio=(p_crit - p_tank)/(pa1*1e5 - p_tank),
                   Qs=P + Qc + leak, copth_s=P/(P + Qc + leak + E_in), A=Qc/(eps*sb*(Tc**4 - 2.7**4)))
main = open(sys.argv[1] if len(sys.argv) > 1 else "cold_side_calc_v8_20261029_r21_output.txt", encoding="utf-8").read()
def grab(pat):
    mm = re.search(pat, main); return float(mm.group(1).replace(",", ""))
ref = {}
for SF, tag in ((2.0, r"Earth SF 2 \(published envelope\)"), (1.5, r"Earth SF 1\.5")):
    blk = re.search(tag + r".*?10 GW site", main, re.S).group(0)
    g = lambda p: float(re.search(p, blk).group(1).replace(",", ""))
    ref[SF] = dict(rpm=g(r"([\d,]+) rpm"), hoop=g(r"hoop ([\d.]+) GPa")*1e9, P=g(r"P ([\d,.]+) MW")*1e6, m=g(r"flow ([\d,.]+) kg/s"),
                   Q=g(r"waste heat total ([\d,.]+) MW")*1e6, copth=g(r"COP_th ([\d.]+)"), cope=g(r"COP_e ([\d,]+)"),
                   head=g(r"m dp/rho = ([\d.]+) MW")*1e6, ratio=g(r"ceiling x([\d.]+)"))
sp = re.search(r"space SF 2:.*?10 GW site", main, re.S).group(0)
ref[2.0].update(Qs=float(re.search(r"waste heat total ([\d,.]+) MW", sp).group(1))*1e6, copth_s=float(re.search(r"COP_th ([\d.]+)", sp).group(1)),
                A=float(re.search(r"radiator ([\d.]+) km2", sp).group(1))*1e6)
def sig4(x): return float(f"{x:.4g}")
bad = 0; rows = 0
for SF in (2.0, 1.5):
    for k, v in ref[SF].items():
        a = out[SF][k]; rows += 1
        # the main output prints fewer digits for some fields; compare at the printed precision, and at 4 s.f.
        rel = abs(a - v)/abs(v)
        if k == 'hoop':   # the main output prints the sleeve stress to 3 s.f. (e.g. 4.00 GPa); compare at that precision
            ok = f"{a/1e9:.2f}" == f"{v/1e9:.2f}"; note = f"agree at the printed 3 s.f. ({a/1e9:.4g} GPa at 4 s.f.)"
        else:
            ok = sig4(a) == sig4(v) or rel < 5e-4; note = "AGREE (4 s.f.)"
        bad += not ok
        print(f"SF {SF} {k:8s}: cross-check {a:.6g} | main {v:.6g} | rel diff {rel:.1e} | {note if ok else 'DIFFER'}")
print(f"CROSS-CHECK: {rows - bad}/{rows} agree: 4 s.f. where the main output prints >= 4 s.f.; sleeve stress (4.00, 5.16 GPa) and head ratio (4.12) are printed at 3 s.f. and agree there" + ("" if not bad else " - SEE DIFFERENCES"))
